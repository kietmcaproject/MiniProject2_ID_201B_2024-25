import { Link } from 'react-router-dom';
import { Briefcase as BriefcaseBusiness, Github, Twitter, Linkedin } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="container mx-auto px-4 md:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-1">
            <Link to="/" className="flex items-center space-x-2 mb-4">
              <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-primary-600">
                <BriefcaseBusiness className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold text-white">ResuMatch</span>
            </Link>
            <p className="text-sm text-gray-400 mb-4">
              AI-powered resume and job matching platform that connects job seekers with their perfect opportunities.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Linkedin className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Github className="w-5 h-5" />
              </a>
            </div>
          </div>

          <div className="col-span-1">
            <h3 className="text-sm font-semibold text-white uppercase tracking-wider mb-4">For Job Seekers</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/job-seeker/dashboard" className="text-sm text-gray-400 hover:text-white transition-colors">
                  Dashboard
                </Link>
              </li>
              <li>
                <Link to="/job-seeker/resume" className="text-sm text-gray-400 hover:text-white transition-colors">
                  Upload Resume
                </Link>
              </li>
              <li>
                <Link to="/job-seeker/matches" className="text-sm text-gray-400 hover:text-white transition-colors">
                  View Matches
                </Link>
              </li>
              <li>
                <Link to="/resources/career-advice" className="text-sm text-gray-400 hover:text-white transition-colors">
                  Career Advice
                </Link>
              </li>
            </ul>
          </div>

          <div className="col-span-1">
            <h3 className="text-sm font-semibold text-white uppercase tracking-wider mb-4">For Recruiters</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/recruiter/dashboard" className="text-sm text-gray-400 hover:text-white transition-colors">
                  Dashboard
                </Link>
              </li>
              <li>
                <Link to="/recruiter/job-posting" className="text-sm text-gray-400 hover:text-white transition-colors">
                  Post a Job
                </Link>
              </li>
              <li>
                <Link to="/recruiter/applications" className="text-sm text-gray-400 hover:text-white transition-colors">
                  View Applications
                </Link>
              </li>
              <li>
                <Link to="/resources/hiring-guide" className="text-sm text-gray-400 hover:text-white transition-colors">
                  Hiring Guide
                </Link>
              </li>
            </ul>
          </div>

          <div className="col-span-1">
            <h3 className="text-sm font-semibold text-white uppercase tracking-wider mb-4">Company</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/about" className="text-sm text-gray-400 hover:text-white transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link to="/pricing" className="text-sm text-gray-400 hover:text-white transition-colors">
                  Pricing
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-sm text-gray-400 hover:text-white transition-colors">
                  Contact
                </Link>
              </li>
              <li>
                <Link to="/privacy" className="text-sm text-gray-400 hover:text-white transition-colors">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link to="/terms" className="text-sm text-gray-400 hover:text-white transition-colors">
                  Terms of Service
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8">
          <p className="text-sm text-gray-400 text-center">
            &copy; {currentYear} ResuMatch. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;