import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, User, Briefcase as BriefcaseBusiness, LogOut } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import Button from './Button';

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, logout, isAuthenticated } = useAuth();
  const location = useLocation();

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  const handleLogout = () => {
    logout();
    closeMenu();
  };

  const isJobSeeker = user?.role === 'jobSeeker';

  return (
    <nav className="bg-white shadow-sm py-4 sticky top-0 z-50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex justify-between items-center">
          <Link to="/" className="flex items-center space-x-2" onClick={closeMenu}>
            <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-primary-600">
              <BriefcaseBusiness className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold text-gray-900">Career KIET</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <div className="flex space-x-6">
              <Link
                to="/"
                className={`text-sm font-medium ${
                  location.pathname === '/' ? 'text-primary-600' : 'text-gray-700 hover:text-primary-600 transition-colors'
                }`}
              >
                Home
              </Link>

              {isAuthenticated ? (
                <>
                  <Link
                    to={isJobSeeker ? '/job-seeker/dashboard' : '/recruiter/dashboard'}
                    className={`text-sm font-medium ${
                      location.pathname.includes('dashboard') ? 'text-primary-600' : 'text-gray-700 hover:text-primary-600 transition-colors'
                    }`}
                  >
                    Dashboard
                  </Link>
                  <Link
                    to={isJobSeeker ? '/job-seeker/matches' : '/recruiter/applications'}
                    className={`text-sm font-medium ${
                      location.pathname.includes(isJobSeeker ? 'matches' : 'applications') ? 'text-primary-600' : 'text-gray-700 hover:text-primary-600 transition-colors'
                    }`}
                  >
                    {isJobSeeker ? 'Matches' : 'Applications'}
                  </Link>
                </>
              ) : (
                <>
                  <Link
                    to="/features"
                    className={`text-sm font-medium ${
                      location.pathname === '/features' ? 'text-primary-600' : 'text-gray-700 hover:text-primary-600 transition-colors'
                    }`}
                  >
                    Features
                  </Link>
                  <Link
                    to="/pricing"
                    className={`text-sm font-medium ${
                      location.pathname === '/pricing' ? 'text-primary-600' : 'text-gray-700 hover:text-primary-600 transition-colors'
                    }`}
                  >
                    Pricing
                  </Link>
                </>
              )}
            </div>

            <div className="flex items-center space-x-4">
              {isAuthenticated ? (
                <div className="flex items-center space-x-4">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-primary-100 flex items-center justify-center">
                      <User className="w-4 h-4 text-primary-600" />
                    </div>
                    <span className="text-sm font-medium text-gray-700">{user?.name}</span>
                  </div>
                  <Button
                    onClick={handleLogout}
                    variant="outline"
                    size="sm"
                    className="flex items-center gap-1"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Logout</span>
                  </Button>
                </div>
              ) : (
                <>
                  <Link to="/login">
                    <Button variant="outline" size="sm">
                      Login
                    </Button>
                  </Link>
                  <Link to="/register">
                    <Button variant="primary" size="sm">
                      Register
                    </Button>
                  </Link>
                </>
              )}
            </div>
          </div>

          {/* Mobile menu button */}
          <button
            type="button"
            className="md:hidden text-gray-500 hover:text-gray-600 focus:outline-none"
            onClick={toggleMenu}
          >
            {isMenuOpen ? (
              <X className="w-6 h-6" />
            ) : (
              <Menu className="w-6 h-6" />
            )}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 bg-white animate-slide-down">
            <div className="flex flex-col space-y-4 py-4">
              <Link
                to="/"
                className={`text-sm font-medium px-4 py-2 ${
                  location.pathname === '/' ? 'text-primary-600 bg-primary-50' : 'text-gray-700 hover:bg-gray-50'
                }`}
                onClick={closeMenu}
              >
                Home
              </Link>

              {isAuthenticated ? (
                <>
                  <Link
                    to={isJobSeeker ? '/job-seeker/dashboard' : '/recruiter/dashboard'}
                    className={`text-sm font-medium px-4 py-2 ${
                      location.pathname.includes('dashboard') ? 'text-primary-600 bg-primary-50' : 'text-gray-700 hover:bg-gray-50'
                    }`}
                    onClick={closeMenu}
                  >
                    Dashboard
                  </Link>
                  <Link
                    to={isJobSeeker ? '/job-seeker/matches' : '/recruiter/applications'}
                    className={`text-sm font-medium px-4 py-2 ${
                      location.pathname.includes(isJobSeeker ? 'matches' : 'applications') ? 'text-primary-600 bg-primary-50' : 'text-gray-700 hover:bg-gray-50'
                    }`}
                    onClick={closeMenu}
                  >
                    {isJobSeeker ? 'Matches' : 'Applications'}
                  </Link>
                </>
              ) : (
                <>
                  <Link
                    to="/features"
                    className={`text-sm font-medium px-4 py-2 ${
                      location.pathname === '/features' ? 'text-primary-600 bg-primary-50' : 'text-gray-700 hover:bg-gray-50'
                    }`}
                    onClick={closeMenu}
                  >
                    Features
                  </Link>
                  <Link
                    to="/pricing"
                    className={`text-sm font-medium px-4 py-2 ${
                      location.pathname === '/pricing' ? 'text-primary-600 bg-primary-50' : 'text-gray-700 hover:bg-gray-50'
                    }`}
                    onClick={closeMenu}
                  >
                    Pricing
                  </Link>
                </>
              )}

              <div className="border-t border-gray-200 pt-4 pb-2">
                {isAuthenticated ? (
                  <>
                    <div className="flex items-center gap-2 px-4 py-2">
                      <div className="w-8 h-8 rounded-full bg-primary-100 flex items-center justify-center">
                        <User className="w-4 h-4 text-primary-600" />
                      </div>
                      <span className="text-sm font-medium text-gray-700">{user?.name}</span>
                    </div>
                    <button
                      onClick={handleLogout}
                      className="w-full text-left text-sm font-medium text-gray-700 hover:bg-gray-50 px-4 py-2 mt-2 flex items-center gap-2"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>Logout</span>
                    </button>
                  </>
                ) : (
                  <div className="flex flex-col space-y-2 px-4">
                    <Link to="/login" onClick={closeMenu}>
                      <Button variant="outline" size="sm" className="w-full">
                        Login
                      </Button>
                    </Link>
                    <Link to="/register" onClick={closeMenu}>
                      <Button variant="primary" size="sm" className="w-full">
                        Register
                      </Button>
                    </Link>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;