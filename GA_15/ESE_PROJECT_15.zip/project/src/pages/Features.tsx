import { motion } from 'framer-motion';
import { Card, CardBody } from '../components/common/Card';
import Button from '../components/common/Button';
import { Link } from 'react-router-dom';
import { 
  Zap, 
  FileText, 
  Briefcase, 
  BarChart4, 
  Users, 
  Bell, 
  Mail, 
  Calendar,
  Shield,
  Search,
  Target,
  MessageSquare
} from 'lucide-react';

const Features = () => {
  const features = [
    {
      icon: <Zap className="w-6 h-6 text-primary-500" />,
      title: 'AI-Powered Matching',
      description: 'Our advanced algorithms analyze resumes and job descriptions to create perfect matches based on skills, experience, and preferences.',
    },
    {
      icon: <FileText className="w-6 h-6 text-primary-500" />,
      title: 'Smart Resume Parsing',
      description: 'Automatically extract key information from resumes including skills, experience, and qualifications.',
    },
    {
      icon: <Briefcase className="w-6 h-6 text-primary-500" />,
      title: 'Job Posting Management',
      description: 'Create, edit, and manage job postings with ease. Track applications and candidate status in real-time.',
    },
    {
      icon: <BarChart4 className="w-6 h-6 text-primary-500" />,
      title: 'Analytics Dashboard',
      description: 'Get detailed insights into your job postings, application rates, and matching statistics.',
    },
    {
      icon: <Users className="w-6 h-6 text-primary-500" />,
      title: 'Talent Pool',
      description: 'Build and manage your talent pool with advanced filtering and search capabilities.',
    },
    {
      icon: <Bell className="w-6 h-6 text-primary-500" />,
      title: 'Real-time Notifications',
      description: 'Stay updated with instant notifications for new matches, applications, and messages.',
    },
    {
      icon: <Mail className="w-6 h-6 text-primary-500" />,
      title: 'In-app Messaging',
      description: 'Communicate directly with candidates or recruiters through our secure messaging system.',
    },
    {
      icon: <Calendar className="w-6 h-6 text-primary-500" />,
      title: 'Interview Scheduling',
      description: 'Schedule and manage interviews with integrated calendar functionality.',
    },
    {
      icon: <Shield className="w-6 h-6 text-primary-500" />,
      title: 'Data Security',
      description: 'Enterprise-grade security to protect sensitive resume and company information.',
    },
    {
      icon: <Search className="w-6 h-6 text-primary-500" />,
      title: 'Advanced Search',
      description: 'Powerful search capabilities with filters for skills, location, experience, and more.',
    },
    {
      icon: <Target className="w-6 h-6 text-primary-500" />,
      title: 'Custom Matching Criteria',
      description: 'Set custom matching parameters to find candidates that perfectly fit your requirements.',
    },
    {
      icon: <MessageSquare className="w-6 h-6 text-primary-500" />,
      title: 'Feedback System',
      description: 'Collect and manage feedback from interviews and applications to improve hiring decisions.',
    },
  ];

  return (
    <div className="bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary-900 to-primary-700 text-white py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <motion.h1 
              className="text-4xl md:text-5xl font-bold mb-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              Powerful Features for Modern Recruitment
            </motion.h1>
            <motion.p 
              className="text-xl text-primary-100 mb-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              Everything you need to streamline your hiring process and find the perfect match.
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <Link to="/register">
                <Button variant="secondary" size="lg">
                  Get Started
                </Button>
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="h-full">
                  <CardBody className="p-6">
                    <div className="flex items-center mb-4">
                      {feature.icon}
                      <h3 className="text-lg font-semibold ml-3">{feature.title}</h3>
                    </div>
                    <p className="text-gray-600">{feature.description}</p>
                  </CardBody>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary-800 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Transform Your Hiring Process?</h2>
          <p className="text-xl mb-10 max-w-3xl mx-auto text-primary-100">
            Join thousands of companies using ResuMatch to find and hire the best talent.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/register">
              <Button variant="secondary" size="lg">
                Start Free Trial
              </Button>
            </Link>
            <Link to="/pricing">
              <Button 
                variant="outline" 
                size="lg" 
                className="border-white text-white hover:bg-white hover:text-primary-800"
              >
                View Pricing
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Features;