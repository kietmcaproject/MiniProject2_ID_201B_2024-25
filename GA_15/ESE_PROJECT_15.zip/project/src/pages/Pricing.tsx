import { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Card, CardBody, CardHeader } from '../components/common/Card';
import Button from '../components/common/Button';
import { CheckCircle } from 'lucide-react';

const Pricing = () => {
  const [billingPeriod, setBillingPeriod] = useState<'monthly' | 'annual'>('monthly');

  const plans = [
    {
      name: 'Starter',
      description: 'Perfect for small businesses just getting started',
      monthlyPrice: 49,
      annualPrice: 39,
      features: [
        'Up to 5 active job postings',
        'Basic resume parsing',
        'Standard job matching',
        'Email support',
        '1 user account',
        'Basic analytics',
      ],
    },
    {
      name: 'Professional',
      description: 'Ideal for growing companies with active hiring needs',
      monthlyPrice: 99,
      annualPrice: 79,
      popular: true,
      features: [
        'Up to 15 active job postings',
        'Advanced resume parsing',
        'AI-powered job matching',
        'Priority email support',
        '3 user accounts',
        'Advanced analytics',
        'Custom matching criteria',
        'Candidate messaging',
      ],
    },
    {
      name: 'Enterprise',
      description: 'For large organizations with complex hiring requirements',
      monthlyPrice: 199,
      annualPrice: 159,
      features: [
        'Unlimited job postings',
        'Enterprise resume parsing',
        'Advanced AI matching',
        '24/7 priority support',
        'Unlimited user accounts',
        'Custom analytics',
        'API access',
        'Custom integrations',
        'Dedicated account manager',
        'Custom branding',
      ],
    },
  ];

  return (
    <div className="bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary-900 to-primary-700 text-white py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <motion.h1 
              className="text-4xl md:text-5xl font-bold mb-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              Simple, Transparent Pricing
            </motion.h1>
            <motion.p 
              className="text-xl text-primary-100 mb-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              Choose the perfect plan for your hiring needs. Save up to 20% with annual billing.
            </motion.p>

            {/* Billing Toggle */}
            <motion.div 
              className="flex items-center justify-center space-x-4 mb-12"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <span className={billingPeriod === 'monthly' ? 'text-white' : 'text-primary-200'}>
                Monthly
              </span>
              <button
                className="relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none"
                style={{ backgroundColor: billingPeriod === 'annual' ? '#22C55E' : '#6B7280' }}
                onClick={() => setBillingPeriod(billingPeriod === 'monthly' ? 'annual' : 'monthly')}
              >
                <span
                  className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                    billingPeriod === 'annual' ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
              <span className={billingPeriod === 'annual' ? 'text-white' : 'text-primary-200'}>
                Annual
                <span className="ml-2 inline-flex items-center rounded-full bg-success-500 px-2 py-0.5 text-xs font-medium">
                  Save 20%
                </span>
              </span>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Pricing Cards */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-7xl mx-auto">
            {plans.map((plan, index) => (
              <motion.div
                key={plan.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className={`h-full ${plan.popular ? 'border-2 border-primary-500 shadow-xl' : ''}`}>
                  {plan.popular && (
                    <div className="absolute top-0 right-0 -translate-y-1/2 translate-x-1/2">
                      <span className="inline-flex items-center rounded-full bg-primary-500 px-3 py-1 text-sm font-medium text-white">
                        Most Popular
                      </span>
                    </div>
                  )}
                  <CardHeader className="text-center p-6">
                    <h3 className="text-2xl font-bold text-gray-900">{plan.name}</h3>
                    <p className="text-gray-500 mt-2">{plan.description}</p>
                    <div className="mt-4">
                      <span className="text-4xl font-bold text-gray-900">
                        ${billingPeriod === 'monthly' ? plan.monthlyPrice : plan.annualPrice}
                      </span>
                      <span className="text-gray-500">/month</span>
                    </div>
                    {billingPeriod === 'annual' && (
                      <p className="text-sm text-success-600 mt-2">
                        Save ${(plan.monthlyPrice - plan.annualPrice) * 12} per year
                      </p>
                    )}
                  </CardHeader>
                  <CardBody className="p-6">
                    <ul className="space-y-4">
                      {plan.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-start">
                          <CheckCircle className="h-5 w-5 text-success-500 flex-shrink-0 mr-2" />
                          <span className="text-gray-600">{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <div className="mt-8">
                      <Link to="/register">
                        <Button
                          variant={plan.popular ? 'primary' : 'outline'}
                          size="lg"
                          className="w-full"
                        >
                          Get Started
                        </Button>
                      </Link>
                    </div>
                  </CardBody>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl font-bold text-center mb-12">Frequently Asked Questions</h2>
            <div className="space-y-8">
              <div>
                <h3 className="text-lg font-semibold mb-2">Can I change my plan later?</h3>
                <p className="text-gray-600">
                  Yes, you can upgrade or downgrade your plan at any time. Changes will be reflected in your next billing cycle.
                </p>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-2">What payment methods do you accept?</h3>
                <p className="text-gray-600">
                  We accept all major credit cards (Visa, MasterCard, American Express) and PayPal.
                </p>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-2">Is there a free trial?</h3>
                <p className="text-gray-600">
                  Yes, all plans come with a 14-day free trial. No credit card required.
                </p>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-2">Can I cancel my subscription?</h3>
                <p className="text-gray-600">
                  You can cancel your subscription at any time. No long-term contracts or cancellation fees.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary-800 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Get Started?</h2>
          <p className="text-xl mb-10 max-w-3xl mx-auto text-primary-100">
            Join thousands of companies using ResuMatch to find and hire the best talent.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/register">
              <Button variant="secondary" size="lg">
                Start Free Trial
              </Button>
            </Link>
            <Link to="/contact">
              <Button 
                variant="outline" 
                size="lg" 
                className="border-white text-white hover:bg-white hover:text-primary-800"
              >
                Contact Sales
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Pricing;