// import { useState } from 'react';
// import { Link } from 'react-router-dom';
// import { Card, CardBody, CardHeader } from '../../components/common/Card';
// import Button from '../../components/common/Button';
// import { BarChart4, FileUp, Briefcase, User, BookOpen, Settings, Clock, Filter } from 'lucide-react';
// import { useAuth } from '../../context/AuthContext';

// // Mock data for demonstration
// const matchStats = {
//   totalMatches: 32,
//   highMatches: 12,
//   newMatches: 8,
//   appliedJobs: 6,
//   interviewsScheduled: 2,
// };

// const recentMatches = [
//   {
//     id: 1,
//     company: 'Tech Innovators',
//     position: 'Senior Frontend Developer',
//     location: 'San Francisco, CA',
//     matchScore: 92,
//     postedDate: '2 days ago',
//     logo: 'https://images.pexels.com/photos/5212351/pexels-photo-5212351.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
//   },
//   {
//     id: 2,
//     company: 'Growth Marketing Inc',
//     position: 'Digital Marketing Specialist',
//     location: 'Remote',
//     matchScore: 88,
//     postedDate: '3 days ago',
//     logo: 'https://images.pexels.com/photos/5212317/pexels-photo-5212317.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
//   },
//   {
//     id: 3,
//     company: 'Data Insights Co',
//     position: 'Data Analyst',
//     location: 'Boston, MA',
//     matchScore: 85,
//     postedDate: '1 week ago',
//     logo: 'https://images.pexels.com/photos/5212339/pexels-photo-5212339.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
//   },
// ];

// const JobSeekerDashboard = () => {
//   const { user } = useAuth();
//   const [hasResume, setHasResume] = useState(false);

//   // This would be determined by checking if the user has uploaded a resume
//   // For demo purposes, we'll use a state variable

//   return (
//     <div className="container mx-auto px-4 py-8">
//       <div className="flex flex-col md:flex-row items-start gap-6">
//         {/* Sidebar */}
//         <aside className="w-full md:w-64 lg:w-72 mb-6 md:mb-0 sticky top-24">
//           <Card className="mb-6">
//             <CardBody>
//               <div className="flex flex-col items-center text-center">
//                 <div className="w-20 h-20 rounded-full bg-primary-100 flex items-center justify-center mb-4">
//                   <User className="w-10 h-10 text-primary-600" />
//                 </div>
//                 <h2 className="text-xl font-semibold text-gray-900">{user?.name}</h2>
//                 <p className="text-gray-500 mb-4">Software Developer</p>
//                 <Link to="/job-seeker/profile">
//                   <Button variant="outline" size="sm" className="w-full">
//                     Edit Profile
//                   </Button>
//                 </Link>
//               </div>
//             </CardBody>
//           </Card>

//           <Card>
//             <CardBody className="p-0">
//               <nav className="flex flex-col">
//                 <Link
//                   to="/job-seeker/dashboard"
//                   className="flex items-center space-x-3 px-4 py-3 text-primary-600 bg-primary-50 border-l-4 border-primary-600"
//                 >
//                   <BarChart4 className="w-5 h-5" />
//                   <span className="font-medium">Dashboard</span>
//                 </Link>
//                 <Link
//                   to="/job-seeker/resume"
//                   className="flex items-center space-x-3 px-4 py-3 text-gray-700 hover:bg-gray-50 border-l-4 border-transparent hover:border-primary-300"
//                 >
//                   <FileUp className="w-5 h-5" />
//                   <span className="font-medium">Resume</span>
//                 </Link>
//                 <Link
//                   to="/job-seeker/matches"
//                   className="flex items-center space-x-3 px-4 py-3 text-gray-700 hover:bg-gray-50 border-l-4 border-transparent hover:border-primary-300"
//                 >
//                   <Briefcase className="w-5 h-5" />
//                   <span className="font-medium">Job Matches</span>
//                 </Link>
//                 <Link
//                   to="/job-seeker/learning"
//                   className="flex items-center space-x-3 px-4 py-3 text-gray-700 hover:bg-gray-50 border-l-4 border-transparent hover:border-primary-300"
//                 >
//                   <BookOpen className="w-5 h-5" />
//                   <span className="font-medium">Learning</span>
//                 </Link>
//                 <Link
//                   to="/job-seeker/settings"
//                   className="flex items-center space-x-3 px-4 py-3 text-gray-700 hover:bg-gray-50 border-l-4 border-transparent hover:border-primary-300"
//                 >
//                   <Settings className="w-5 h-5" />
//                   <span className="font-medium">Settings</span>
//                 </Link>
//               </nav>
//             </CardBody>
//           </Card>
//         </aside>

//         {/* Main Content */}
//         <div className="flex-1">
//           {/* Welcome Banner */}
//           <Card className="mb-6 bg-gradient-to-r from-primary-700 to-primary-800 text-white overflow-hidden">
//             <CardBody className="p-6 md:p-8">
//               <div className="flex flex-col md:flex-row items-center justify-between">
//                 <div>
//                   <h1 className="text-2xl md:text-3xl font-bold mb-3">Welcome back, {user?.name?.split(' ')[0]}!</h1>
//                   {hasResume ? (
//                     <p className="text-primary-50 max-w-lg">
//                       You have {matchStats.newMatches} new job matches and {matchStats.totalMatches} total matches based on your profile.
//                     </p>
//                   ) : (
//                     <p className="text-primary-50 max-w-lg">
//                       Upload your resume to start matching with job opportunities tailored to your skills and experience.
//                     </p>
//                   )}
//                 </div>
//                 {!hasResume && (
//                   <Link to="/job-seeker/resume" className="mt-4 md:mt-0">
//                     <Button 
//                       variant="secondary" 
//                       size="md" 
//                       className="whitespace-nowrap"
//                     >
//                       Upload Resume
//                     </Button>
//                   </Link>
//                 )}
//               </div>
//             </CardBody>
//           </Card>

//           {/* Stats Row */}
//           {hasResume ? (
//             <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
//               <Card>
//                 <CardBody className="p-4">
//                   <div className="flex items-center">
//                     <div className="p-3 rounded-full bg-primary-100 text-primary-600 mr-4">
//                       <Briefcase className="w-6 h-6" />
//                     </div>
//                     <div>
//                       <p className="text-sm text-gray-500">Job Matches</p>
//                       <p className="text-2xl font-semibold text-gray-900">{matchStats.totalMatches}</p>
//                     </div>
//                   </div>
//                 </CardBody>
//               </Card>
//               <Card>
//                 <CardBody className="p-4">
//                   <div className="flex items-center">
//                     <div className="p-3 rounded-full bg-success-100 text-success-600 mr-4">
//                       <Filter className="w-6 h-6" />
//                     </div>
//                     <div>
//                       <p className="text-sm text-gray-500">High Matches (85%)</p>
//                       <p className="text-2xl font-semibold text-gray-900">{matchStats.highMatches}</p>
//                     </div>
//                   </div>
//                 </CardBody>
//               </Card>
//               <Card>
//                 <CardBody className="p-4">
//                   <div className="flex items-center">
//                     <div className="p-3 rounded-full bg-secondary-100 text-secondary-600 mr-4">
//                       <Clock className="w-6 h-6" />
//                     </div>
//                     <div>
//                       <p className="text-sm text-gray-500">Applications</p>
//                       <p className="text-2xl font-semibold text-gray-900">{matchStats.appliedJobs}</p>
//                     </div>
//                   </div>
//                 </CardBody>
//               </Card>
//             </div>
//           ) : (
//             <Card className="mb-6 bg-accent-50 border border-accent-100">
//               <CardBody className="p-6">
//                 <div className="flex flex-col sm:flex-row items-center">
//                   <div className="flex-shrink-0 mb-4 sm:mb-0 sm:mr-4">
//                     <FileUp className="w-12 h-12 text-accent-500" />
//                   </div>
//                   <div>
//                     <h3 className="text-lg font-medium text-accent-800 mb-1">Upload your resume to get started</h3>
//                     <p className="text-accent-700 mb-4">
//                       Our AI will analyze your resume and match you with relevant job opportunities.
//                     </p>
//                     <Link to="/job-seeker/resume">
//                       <Button variant="accent" size="sm">
//                         Upload Resume
//                       </Button>
//                     </Link>
//                   </div>
//                 </div>
//               </CardBody>
//             </Card>
//           )}

//           {/* Recent Matches */}
//           <Card>
//             <CardHeader>
//               <div className="flex items-center justify-between">
//                 <h2 className="text-xl font-semibold text-gray-900">Recent Job Matches</h2>
//                 <Link to="/job-seeker/matches">
//                   <Button variant="outline" size="sm">
//                     View All
//                   </Button>
//                 </Link>
//               </div>
//             </CardHeader>
//             <CardBody>
//               {hasResume ? (
//                 <div className="space-y-6">
//                   {recentMatches.map((job) => (
//                     <div key={job.id} className="flex flex-col sm:flex-row border-b border-gray-100 pb-6 last:border-b-0 last:pb-0">
//                       <div className="sm:w-16 flex-shrink-0 mb-4 sm:mb-0">
//                         <img 
//                           src={job.logo} 
//                           alt={job.company} 
//                           className="w-16 h-16 rounded-lg object-cover"
//                         />
//                       </div>
//                       <div className="sm:ml-4 flex-1">
//                         <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-2">
//                           <h3 className="text-lg font-medium text-gray-900">{job.position}</h3>
//                           <div className="mt-2 sm:mt-0">
//                             <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-100 text-primary-800">
//                               {job.matchScore}% Match
//                             </span>
//                           </div>
//                         </div>
//                         <div className="flex flex-col sm:flex-row sm:items-center text-sm text-gray-500 mb-3">
//                           <span className="mb-1 sm:mb-0">{job.company}</span>
//                           <span className="hidden sm:inline mx-2">•</span>
//                           <span>{job.location}</span>
//                         </div>
//                         <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between">
//                           <span className="text-xs text-gray-500 mb-2 sm:mb-0">Posted {job.postedDate}</span>
//                           <div className="flex space-x-2">
//                             <Button variant="outline" size="sm">
//                               View Details
//                             </Button>
//                             <Button variant="primary" size="sm">
//                               Apply
//                             </Button>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                   ))}
//                 </div>
//               ) : (
//                 <div className="text-center py-6">
//                   <p className="text-gray-500 mb-4">
//                     Upload your resume to see job matches here.
//                   </p>
//                   <Link to="/job-seeker/resume">
//                     <Button variant="primary" size="sm">
//                       Upload Resume
//                     </Button>
//                   </Link>
//                 </div>
//               )}
//             </CardBody>
//           </Card>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default JobSeekerDashboard;










import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardBody, CardHeader } from '../../components/common/Card';
import Button from '../../components/common/Button';
import { BarChart4, FileUp, Briefcase, User, BookOpen, Settings, Clock, Filter } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

// Mock data for demonstration with Indian data
const matchStats = {
  totalMatches: 32,
  highMatches: 12,
  newMatches: 8,
  appliedJobs: 6,
  interviewsScheduled: 2,
};

const recentMatches = [
  {
    id: 1,
    company: 'Tata Consultancy Services',
    position: 'Senior Frontend Developer',
    location: 'Bangalore, Karnataka',
    matchScore: 92,
    postedDate: '2 days ago',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/7/7a/Tata_Consultancy_Services_Logo.svg',
  },
  {
    id: 2,
    company: 'Infosys',
    position: 'Digital Marketing Specialist',
    location: 'Hyderabad, Telangana',
    matchScore: 88,
    postedDate: '3 days ago',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/0/04/Infosys_Logo.svg',
  },
  {
    id: 3,
    company: 'Reliance Industries',
    position: 'Data Analyst',
    location: 'Mumbai, Maharashtra',
    matchScore: 85,
    postedDate: '1 week ago',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/5/5a/Reliance_Industries_Logo.svg',
  },
];

const JobSeekerDashboard = () => {
  const { user } = useAuth();
  const [hasResume, setHasResume] = useState(false);

  // This would be determined by checking if the user has uploaded a resume
  // For demo purposes, we'll use a state variable

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row items-start gap-6">
        {/* Sidebar */}
        <aside className="w-full md:w-64 lg:w-72 mb-6 md:mb-0 sticky top-24">
          <Card className="mb-6">
            <CardBody>
              <div className="flex flex-col items-center text-center">
                <div className="w-20 h-20 rounded-full bg-primary-100 flex items-center justify-center mb-4">
                  <User className="w-10 h-10 text-primary-600" />
                </div>
                <h2 className="text-xl font-semibold text-gray-900">{user?.name}</h2>
                <p className="text-gray-500 mb-4">Software Developer</p>
                <Link to="/job-seeker/profile">
                  <Button variant="outline" size="sm" className="w-full">
                    Edit Profile
                  </Button>
                </Link>
              </div>
            </CardBody>
          </Card>

          <Card>
            <CardBody className="p-0">
              <nav className="flex flex-col">
                <Link
                  to="/job-seeker/dashboard"
                  className="flex items-center space-x-3 px-4 py-3 text-primary-600 bg-primary-50 border-l-4 border-primary-600"
                >
                  <BarChart4 className="w-5 h-5" />
                  <span className="font-medium">Dashboard</span>
                </Link>
                <Link
                  to="/job-seeker/resume"
                  className="flex items-center space-x-3 px-4 py-3 text-gray-700 hover:bg-gray-50 border-l-4 border-transparent hover:border-primary-300"
                >
                  <FileUp className="w-5 h-5" />
                  <span className="font-medium">Resume</span>
                </Link>
                <Link
                  to="/job-seeker/matches"
                  className="flex items-center space-x-3 px-4 py-3 text-gray-700 hover:bg-gray-50 border-l-4 border-transparent hover:border-primary-300"
                >
                  <Briefcase className="w-5 h-5" />
                  <span className="font-medium">Job Matches</span>
                </Link>
                <Link
                  to="/job-seeker/learning"
                  className="flex items-center space-x-3 px-4 py-3 text-gray-700 hover:bg-gray-50 border-l-4 border-transparent hover:border-primary-300"
                >
                  <BookOpen className="w-5 h-5" />
                  <span className="font-medium">Learning</span>
                </Link>
                <Link
                  to="/job-seeker/settings"
                  className="flex items-center space-x-3 px-4 py-3 text-gray-700 hover:bg-gray-50 border-l-4 border-transparent hover:border-primary-300"
                >
                  <Settings className="w-5 h-5" />
                  <span className="font-medium">Settings</span>
                </Link>
              </nav>
            </CardBody>
          </Card>
        </aside>

        {/* Main Content */}
        <div className="flex-1">
          {/* Welcome Banner */}
          <Card className="mb-6 bg-gradient-to-r from-primary-700 to-primary-800 text-white overflow-hidden">
            <CardBody className="p-6 md:p-8">
              <div className="flex flex-col md:flex-row items-center justify-between">
                <div>
                  <h1 className="text-2xl md:text-3xl font-bold mb-3">Welcome back, {user?.name?.split(' ')[0]}!</h1>
                  {hasResume ? (
                    <p className="text-primary-50 max-w-lg">
                      You have {matchStats.newMatches} new job matches and {matchStats.totalMatches} total matches based on your profile.
                    </p>
                  ) : (
                    <p className="text-primary-50 max-w-lg">
                      Upload your resume to start matching with job opportunities tailored to your skills and experience.
                    </p>
                  )}
                </div>
                {!hasResume && (
                  <Link to="/job-seeker/resume" className="mt-4 md:mt-0">
                    <Button 
                      variant="secondary" 
                      size="md" 
                      className="whitespace-nowrap"
                    >
                      Upload Resume
                    </Button>
                  </Link>
                )}
              </div>
            </CardBody>
          </Card>

          {/* Stats Row */}
          {hasResume ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <Card>
                <CardBody className="p-4">
                  <div className="flex items-center">
                    <div className="p-3 rounded-full bg-primary-100 text-primary-600 mr-4">
                      <Briefcase className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Job Matches</p>
                      <p className="text-2xl font-semibold text-gray-900">{matchStats.totalMatches}</p>
                    </div>
                  </div>
                </CardBody>
              </Card>
              <Card>
                <CardBody className="p-4">
                  <div className="flex items-center">
                    <div className="p-3 rounded-full bg-success-100 text-success-600 mr-4">
                      <Filter className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">High Matches (85%)</p>
                      <p className="text-2xl font-semibold text-gray-900">{matchStats.highMatches}</p>
                    </div>
                  </div>
                </CardBody>
              </Card>
              <Card>
                <CardBody className="p-4">
                  <div className="flex items-center">
                    <div className="p-3 rounded-full bg-secondary-100 text-secondary-600 mr-4">
                      <Clock className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Applications</p>
                      <p className="text-2xl font-semibold text-gray-900">{matchStats.appliedJobs}</p>
                    </div>
                  </div>
                </CardBody>
              </Card>
            </div>
          ) : (
            <Card className="mb-6 bg-accent-50 border border-accent-100">
              <CardBody className="p-6">
                <div className="flex flex-col sm:flex-row items-center">
                  <div className="flex-shrink-0 mb-4 sm:mb-0 sm:mr-4">
                    <FileUp className="w-12 h-12 text-accent-500" />
                  </div>
                  <div>
                    <h3 className="text-lg font-medium text-accent-800 mb-1">Upload your resume to get started</h3>
                    <p className="text-accent-700 mb-4">
                      Our AI will analyze your resume and match you with relevant job opportunities.
                    </p>
                    <Link to="/job-seeker/resume">
                      <Button variant="accent" size="sm">
                        Upload Resume
                      </Button>
                    </Link>
                  </div>
                </div>
              </CardBody>
            </Card>
          )}

          {/* Recent Matches */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold text-gray-900">Recent Job Matches</h2>
                <Link to="/job-seeker/matches">
                  <Button variant="outline" size="sm">
                    View All
                  </Button>
                </Link>
              </div>
            </CardHeader>
            <CardBody>
              {hasResume ? (
                <div className="space-y-6">
                  {recentMatches.map((job) => (
                    <div key={job.id} className="flex flex-col sm:flex-row border-b border-gray-100 pb-6 last:border-b-0 last:pb-0">
                      <div className="sm:w-16 flex-shrink-0 mb-4 sm:mb-0">
                        <img 
                          src={job.logo} 
                          alt={job.company} 
                          className="w-16 h-16 rounded-lg object-cover"
                        />
                      </div>
                      <div className="sm:ml-4 flex-1">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-2">
                          <h3 className="text-lg font-medium text-gray-900">{job.position}</h3>
                          <div className="mt-2 sm:mt-0">
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-100 text-primary-800">
                              {job.matchScore}% Match
                            </span>
                          </div>
                        </div>
                        <div className="flex flex-col sm:flex-row sm:items-center text-sm text-gray-500 mb-3">
                          <span className="mb-1 sm:mb-0">{job.company}</span>
                          <span className="hidden sm:inline mx-2">•</span>
                          <span>{job.location}</span>
                        </div>
                        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between">
                          <span className="text-xs text-gray-500 mb-2 sm:mb-0">Posted {job.postedDate}</span>
                          <div className="flex space-x-2">
                            <Button variant="outline" size="sm">
                              View Details
                            </Button>
                            <Button variant="primary" size="sm">
                              Apply
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-6">
                  <p className="text-gray-500 mb-4">
                    Upload your resume to see job matches here.
                  </p>
                  <Link to="/job-seeker/resume">
                    <Button variant="primary" size="sm">
                      Upload Resume
                    </Button>
                  </Link>
                </div>
              )}
            </CardBody>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default JobSeekerDashboard;
