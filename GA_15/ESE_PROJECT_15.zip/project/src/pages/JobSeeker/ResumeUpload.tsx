import { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { FileUp, FilePlus, FileText, AlertCircle, CheckCircle, XCircle } from 'lucide-react';
import { Card, CardBody, CardHeader, CardFooter } from '../../components/common/Card';
import Button from '../../components/common/Button';
import { useToast } from '../../context/ToastContext';

const ResumeUpload = () => {
  const [file, setFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadComplete, setUploadComplete] = useState(false);
  const [processingStatus, setProcessingStatus] = useState<'idle' | 'processing' | 'complete' | 'error'>('idle');
  const [resumeData, setResumeData] = useState<any>(null);
  const { showToast } = useToast();

  const onDrop = useCallback((acceptedFiles: File[]) => {
    // Check if the file is PDF or Word
    const selectedFile = acceptedFiles[0];
    const fileType = selectedFile.type;
    
    if (
      fileType === 'application/pdf' || 
      fileType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' || 
      fileType === 'application/msword'
    ) {
      setFile(selectedFile);
      setUploadComplete(false);
      setProcessingStatus('idle');
      setResumeData(null);
    } else {
      showToast('Please upload a PDF or Word document', 'error');
    }
  }, [showToast]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ 
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'application/msword': ['.doc'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx']
    },
    maxFiles: 1
  });

  const handleUpload = async () => {
    if (!file) return;

    try {
      setIsUploading(true);
      
      // Simulate upload delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      setUploadComplete(true);
      setIsUploading(false);
      setProcessingStatus('processing');
      
      // Simulate processing delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Mock parsed resume data
      const mockResumeData = {
        name: 'Abhishek Sharma',
        email: 'abhiisheksharma147@gmail.com',
        phone: '+91 9876543210',
        skills: ['JavaScript', 'React', 'Node.js', 'TypeScript', 'HTML/CSS', 'UI/UX Design'],
        experience: [
          {
            title: 'Senior Frontend Developer',
            company: 'Tech Innovators',
            duration: 'Jan 2020 - Present',
            description: 'Lead developer for multiple client projects utilizing React, TypeScript, and modern frontend technologies.'
          },
          {
            title: 'Frontend Developer',
            company: 'Digital Solutions Inc',
            duration: 'Mar 2017 - Dec 2019',
            description: 'Developed responsive web applications and implemented UI components using React and Redux.'
          }
        ],
        education: [
          {
            degree: 'Master of computer applications',
            institution: 'Kiet Group of Institutions',
            year: '2026'
          }
        ]
      };
      
      setResumeData(mockResumeData);
      setProcessingStatus('complete');
      showToast('Resume processed successfully!', 'success');
      
    } catch (error) {
      setIsUploading(false);
      setProcessingStatus('error');
      showToast('Error processing resume. Please try again.', 'error');
    }
  };

  const removeFile = () => {
    setFile(null);
    setUploadComplete(false);
    setProcessingStatus('idle');
    setResumeData(null);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold text-gray-900 mb-6">Upload Your Resume</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2">
            <Card className="mb-6">
              <CardHeader>
                <h2 className="text-xl font-semibold text-gray-900">Resume Upload</h2>
              </CardHeader>
              <CardBody>
                {!file ? (
                  <div 
                    {...getRootProps()} 
                    className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
                      isDragActive ? 'border-primary-500 bg-primary-50' : 'border-gray-300 hover:border-primary-400 hover:bg-gray-50'
                    }`}
                  >
                    <input {...getInputProps()} />
                    <div className="flex flex-col items-center">
                      <FileUp className="w-12 h-12 text-gray-400 mb-4" />
                      <p className="text-lg font-medium text-gray-700 mb-1">
                        {isDragActive ? 'Drop your resume here' : 'Drag and drop your resume'}
                      </p>
                      <p className="text-gray-500 mb-4">or click to browse files</p>
                      <p className="text-sm text-gray-500">
                        Supported formats: PDF, DOC, DOCX
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="border rounded-lg p-6">
                    <div className="flex items-center justify-between mb-6">
                      <div className="flex items-center">
                        <div className="p-3 rounded-lg bg-primary-50">
                          <FileText className="w-8 h-8 text-primary-500" />
                        </div>
                        <div className="ml-4">
                          <p className="font-medium text-gray-900">{file.name}</p>
                          <p className="text-sm text-gray-500">
                            {(file.size / 1024 / 1024).toFixed(2)} MB
                          </p>
                        </div>
                      </div>
                      <button 
                        onClick={removeFile}
                        className="text-gray-400 hover:text-gray-500"
                      >
                        <XCircle className="w-5 h-5" />
                      </button>
                    </div>
                    
                    {processingStatus === 'idle' && !uploadComplete && (
                      <Button
                        onClick={handleUpload}
                        variant="primary"
                        size="md"
                        isLoading={isUploading}
                        className="w-full"
                      >
                        Upload and Process Resume
                      </Button>
                    )}
                    
                    {uploadComplete && (
                      <div className="space-y-4">
                        <div className="flex items-center">
                          <div className="w-8 h-8 flex-shrink-0">
                            <CheckCircle className="w-6 h-6 text-success-500" />
                          </div>
                          <div className="ml-3">
                            <p className="text-sm font-medium text-gray-900">Upload complete</p>
                          </div>
                        </div>
                        
                        <div className="flex items-center">
                          {processingStatus === 'processing' && (
                            <>
                              <div className="w-8 h-8 flex-shrink-0">
                                <svg className="animate-spin w-6 h-6 text-primary-500\" xmlns="http://www.w3.org/2000/svg\" fill="none\" viewBox="0 0 24 24">
                                  <circle className="opacity-25\" cx="12\" cy="12\" r="10\" stroke="currentColor\" strokeWidth="4"></circle>
                                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                </svg>
                              </div>
                              <div className="ml-3">
                                <p className="text-sm font-medium text-gray-900">Processing resume...</p>
                                <p className="text-xs text-gray-500">Extracting skills and experience</p>
                              </div>
                            </>
                          )}
                          
                          {processingStatus === 'complete' && (
                            <>
                              <div className="w-8 h-8 flex-shrink-0">
                                <CheckCircle className="w-6 h-6 text-success-500" />
                              </div>
                              <div className="ml-3">
                                <p className="text-sm font-medium text-gray-900">Processing complete</p>
                                <p className="text-xs text-gray-500">Resume data extracted successfully</p>
                              </div>
                            </>
                          )}
                          
                          {processingStatus === 'error' && (
                            <>
                              <div className="w-8 h-8 flex-shrink-0">
                                <AlertCircle className="w-6 h-6 text-error-500" />
                              </div>
                              <div className="ml-3">
                                <p className="text-sm font-medium text-gray-900">Processing failed</p>
                                <p className="text-xs text-gray-500">Please try uploading again</p>
                              </div>
                            </>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </CardBody>
              <CardFooter>
                <div className="flex items-center text-sm text-gray-500">
                  <AlertCircle className="w-4 h-4 mr-2" />
                  <p>Your resume will be used to match you with relevant job opportunities.</p>
                </div>
              </CardFooter>
            </Card>
            
            {resumeData && (
              <Card>
                <CardHeader>
                  <h2 className="text-xl font-semibold text-gray-900">Resume Preview</h2>
                </CardHeader>
                <CardBody>
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium text-gray-900 mb-2">Basic Information</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <p className="text-sm text-gray-500">Name</p>
                          <p className="font-medium text-gray-900">{resumeData.name}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-500">Email</p>
                          <p className="font-medium text-gray-900">{resumeData.email}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-500">Phone</p>
                          <p className="font-medium text-gray-900">{resumeData.phone}</p>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-medium text-gray-900 mb-2">Skills</h3>
                      <div className="flex flex-wrap gap-2">
                        {resumeData.skills.map((skill: string, index: number) => (
                          <span 
                            key={index}
                            className="px-3 py-1 rounded-full text-sm bg-primary-50 text-primary-700"
                          >
                            {skill}
                          </span>
                        ))}
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-medium text-gray-900 mb-2">Experience</h3>
                      <div className="space-y-4">
                        {resumeData.experience.map((exp: any, index: number) => (
                          <div key={index} className="border-b border-gray-100 pb-4 last:border-b-0 last:pb-0">
                            <p className="font-medium text-gray-900">{exp.title}</p>
                            <p className="text-gray-700">{exp.company}</p>
                            <p className="text-sm text-gray-500 mb-2">{exp.duration}</p>
                            <p className="text-gray-600 text-sm">{exp.description}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-medium text-gray-900 mb-2">Education</h3>
                      <div className="space-y-4">
                        {resumeData.education.map((edu: any, index: number) => (
                          <div key={index}>
                            <p className="font-medium text-gray-900">{edu.degree}</p>
                            <p className="text-gray-700">{edu.institution}</p>
                            <p className="text-sm text-gray-500">{edu.year}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardBody>
              </Card>
            )}
          </div>
          
          <div className="md:col-span-1">
            <Card className="sticky top-24">
              <CardHeader>
                <h2 className="text-lg font-semibold text-gray-900">Tips for Better Matching</h2>
              </CardHeader>
              <CardBody>
                <div className="space-y-4">
                  <div>
                    <h3 className="font-medium text-gray-900 mb-1">Use a professional format</h3>
                    <p className="text-sm text-gray-600">
                      Clean, well-structured resumes are easier to parse and analyze.
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="font-medium text-gray-900 mb-1">Include relevant skills</h3>
                    <p className="text-sm text-gray-600">
                      List technical skills and soft skills that match your target jobs.
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="font-medium text-gray-900 mb-1">Quantify achievements</h3>
                    <p className="text-sm text-gray-600">
                      Use numbers and metrics to demonstrate your impact.
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="font-medium text-gray-900 mb-1">Be specific about experience</h3>
                    <p className="text-sm text-gray-600">
                      Detail your roles, responsibilities, and projects.
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="font-medium text-gray-900 mb-1">Keep it current</h3>
                    <p className="text-sm text-gray-600">
                      Update your resume regularly with your latest experience.
                    </p>
                  </div>
                </div>
              </CardBody>
              <CardFooter>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full flex items-center justify-center"
                >
                  <FilePlus className="w-4 h-4 mr-2" />
                  Resume Templates
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResumeUpload;