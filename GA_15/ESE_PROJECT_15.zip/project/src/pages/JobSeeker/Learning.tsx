import React from 'react';

const resources = [
  {
    title: 'Resume Writing 101',
    description: 'Learn how to craft a professional and job-winning resume.',
    link: '#',
  },
  {
    title: 'Ace Your Interview',
    description: 'Top interview tips and mock questions to practice.',
    link: '#',
  },
  {
    title: 'LinkedIn Optimization',
    description: 'Boost your LinkedIn profile to attract recruiters.',
    link: '#',
  },
  {
    title: 'Career Roadmaps',
    description: 'Explore career paths in tech, design, and management.',
    link: '#',
  },
];

const Learning = () => {
  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      <h1 className="text-4xl font-bold text-center text-blue-700 mb-8">Learning Resources</h1>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
        {resources.map((resource, index) => (
          <div
            key={index}
            className="bg-white p-6 rounded-xl shadow-md hover:shadow-xl transition-shadow duration-300"
          >
            <h2 className="text-xl font-semibold text-gray-800 mb-2">{resource.title}</h2>
            <p className="text-gray-600 mb-4">{resource.description}</p>
            <a
              href={resource.link}
              className="text-blue-600 hover:underline font-medium"
            >
              Explore →
            </a>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Learning;
