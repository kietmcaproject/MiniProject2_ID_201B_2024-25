import React, { useState } from 'react';

const Settings = () => {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [location, setLocation] = useState('');
  const [linkedin, setLinkedin] = useState('');
  const [github, setGithub] = useState('');
  const [profilePic, setProfilePic] = useState(null);

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [emailNotifications, setEmailNotifications] = useState(false);

  const handleProfilePicChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setProfilePic(URL.createObjectURL(e.target.files[0]));
    }
  };

  const handleReset = () => {
    setFullName('');
    setEmail('');
    setPhone('');
    setLocation('');
    setLinkedin('');
    setGithub('');
    setProfilePic(null);
    setCurrentPassword('');
    setNewPassword('');
    setConfirmPassword('');
    setEmailNotifications(false);
  };

  const handleSave = () => {
    if (newPassword && newPassword !== confirmPassword) {
      alert('New password and confirm password do not match!');
      return;
    }
    alert('Profile saved!');
  };

  return (
    <div className="max-w-4xl mx-auto p-8 bg-white rounded-xl shadow-lg mt-12">
      <h1 className="text-4xl font-extrabold mb-8 text-gray-900">Job Seeker Profile Settings</h1>

      {/* Profile Picture */}
      <div className="flex items-center mb-8 space-x-6">
        <div className="w-24 h-24 rounded-full bg-gray-200 overflow-hidden flex items-center justify-center">
          {profilePic ? (
            <img src={profilePic} alt="Profile" className="w-full h-full object-cover" />
          ) : (
            <span className="text-gray-400 font-bold text-xl">?</span>
          )}
        </div>
        <div>
          <label htmlFor="profilePicUpload" className="cursor-pointer text-blue-600 font-semibold hover:underline">
            Upload Profile Picture
          </label>
          <input type="file" id="profilePicUpload" accept="image/*" onChange={handleProfilePicChange} className="hidden" />
        </div>
      </div>

      {/* Form Fields */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
        <div>
          <label className="block font-semibold mb-2 text-gray-700">Full Name</label>
          <input
            type="text"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            placeholder="Enter your full name"
            className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <div>
          <label className="block font-semibold mb-2 text-gray-700">Email Address</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Enter your email"
            className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <div>
          <label className="block font-semibold mb-2 text-gray-700">Phone Number</label>
          <input
            type="tel"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="+1 234 567 890"
            className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <div>
          <label className="block font-semibold mb-2 text-gray-700">Location</label>
          <input
            type="text"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            placeholder="City, Country"
            className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <div>
          <label className="block font-semibold mb-2 text-gray-700">LinkedIn Profile</label>
          <input
            type="url"
            value={linkedin}
            onChange={(e) => setLinkedin(e.target.value)}
            placeholder="https://linkedin.com/in/username"
            className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <div>
          <label className="block font-semibold mb-2 text-gray-700">GitHub Profile</label>
          <input
            type="url"
            value={github}
            onChange={(e) => setGithub(e.target.value)}
            placeholder="https://github.com/username"
            className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      {/* Password Section */}
      <div className="mb-10">
        <h2 className="text-2xl font-semibold mb-4 text-gray-800">Reset Password</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <input
            type="password"
            value={currentPassword}
            onChange={(e) => setCurrentPassword(e.target.value)}
            placeholder="Current password"
            className="w-full p-3 border border-gray-300 rounded-md"
          />
          <input
            type="password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            placeholder="New password"
            className="w-full p-3 border border-gray-300 rounded-md"
          />
          <input
            type="password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            placeholder="Confirm new password"
            className="w-full p-3 border border-gray-300 rounded-md"
          />
        </div>
      </div>

      {/* Notifications */}
      <div className="flex items-center mb-10">
        <input
          type="checkbox"
          checked={emailNotifications}
          onChange={() => setEmailNotifications(!emailNotifications)}
          className="mr-3 w-5 h-5"
        />
        <label className="font-semibold text-gray-700">Enable Email Notifications</label>
      </div>

      {/* Buttons */}
      <div className="flex space-x-4">
        <button onClick={handleSave} className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition">
          Save Changes
        </button>
        <button onClick={handleReset} className="bg-gray-300 text-gray-700 px-6 py-3 rounded-lg hover:bg-gray-400 transition">
          Reset Form
        </button>
      </div>
    </div>
  );
};

export default Settings;
