import { useState } from 'react';
import { Card, CardBody, CardHeader } from '../../components/common/Card';
import Button from '../../components/common/Button';
import { Search, Filter, MapPin, Briefcase, BookOpen, Zap, Star, ChevronRight, ExternalLink } from 'lucide-react';

// Mock data
const matchedJobs = [
  // {
  //   id: 1,
  //   title: 'Senior Frontend Developer',
  //   company: 'Tech Innovators',
  //   location: 'San Francisco, CA (Remote)',
  //   salary: '$120,000 - $150,000',
  //   matchScore: 95,
  //   keyMatches: ['React', 'TypeScript', 'UI/UX Design', '5+ years experience'],
  //   description: 'We are looking for a Senior Frontend Developer to join our team. You will be responsible for developing and implementing user interface components using React.js and other frontend technologies.',
  //   posted: '2 days ago',
  //   logo: 'https://images.pexels.com/photos/5212351/pexels-photo-5212351.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
  //   isBookmarked: false,
  // },
  // {
  //   id: 2,
  //   title: 'Full Stack Developer',
  //   company: 'WebSolutions Inc',
  //   location: 'New York, NY (Hybrid)',
  //   salary: '$110,000 - $140,000',
  //   matchScore: 92,
  //   keyMatches: ['JavaScript', 'Node.js', 'React', 'SQL'],
  //   description: 'We are seeking a Full Stack Developer to join our growing team. The ideal candidate will have experience with both frontend and backend technologies.',
  //   posted: '3 days ago',
  //   logo: 'https://images.pexels.com/photos/5212317/pexels-photo-5212317.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
  //   isBookmarked: true,
  // },
  // {
  //   id: 3,
  //   title: 'UI/UX Designer',
  //   company: 'Creative Labs',
  //   location: 'Austin, TX (On-site)',
  //   salary: '$90,000 - $120,000',
  //   matchScore: 88,
  //   keyMatches: ['UI/UX Design', 'Figma', 'User Research', 'Prototyping'],
  //   description: 'Creative Labs is looking for a talented UI/UX Designer to create amazing user experiences. The ideal candidate should have a strong portfolio demonstrating their design skills.',
  //   posted: '1 week ago',
  //   logo: 'https://images.pexels.com/photos/5212339/pexels-photo-5212339.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
  //   isBookmarked: false,
  // },
  // {
  //   id: 4,
  //   title: 'Frontend Developer',
  //   company: 'Digital Agency',
  //   location: 'Chicago, IL (Remote)',
  //   salary: '$85,000 - $110,000',
  //   matchScore: 85,
  //   keyMatches: ['JavaScript', 'React', 'CSS', 'Responsive Design'],
  //   description: 'We are looking for a talented Frontend Developer to join our team. You will be responsible for implementing visual elements and UI components that users interact with.',
  //   posted: '5 days ago',
  //   logo: 'https://images.pexels.com/photos/5212324/pexels-photo-5212324.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
  //   isBookmarked: false,
  // },
  // {
  //   id: 5,
  //   title: 'React Native Developer',
  //   company: 'MobileApp Studios',
  //   location: 'Seattle, WA (Remote)',
  //   salary: '$100,000 - $130,000',
  //   matchScore: 82,
  //   keyMatches: ['React Native', 'JavaScript', 'Mobile Development', 'API Integration'],
  //   description: 'MobileApp Studios is seeking a React Native Developer to build and maintain mobile applications. The ideal candidate will have experience with cross-platform mobile development.',
  //   posted: '1 week ago',
  //   logo: 'https://images.pexels.com/photos/5212307/pexels-photo-5212307.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
  //   isBookmarked: true,
  // },

    {
    id: 1,
    title: 'Senior Frontend Developer',
    company: 'Tech Innovators',
    location: 'San Francisco, CA (Remote)',
    salary: '$120,000 - $150,000',
    matchScore: 95,
    keyMatches: ['React', 'TypeScript', 'UI/UX Design', '5+ years experience'],
    description: 'We are looking for a Senior Frontend Developer to join our team. You will be responsible for developing and implementing user interface components using React.js and other frontend technologies.',
    posted: '2 days ago',
    logo: 'https://images.pexels.com/photos/5212351/pexels-photo-5212351.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    isBookmarked: false,
    jobType: 'fulltime',
    workLocation: 'remote'
  },
  {
    id: 2,
    title: 'Full Stack Developer',
    company: 'WebSolutions Inc',
    location: 'New York, NY (Hybrid)',
    salary: '$110,000 - $140,000',
    matchScore: 92,
    keyMatches: ['JavaScript', 'Node.js', 'React', 'SQL'],
    description: 'We are seeking a Full Stack Developer to join our growing team. The ideal candidate will have experience with both frontend and backend technologies.',
    posted: '3 days ago',
    logo: 'https://images.pexels.com/photos/5212317/pexels-photo-5212317.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    isBookmarked: true,
    jobType: 'fulltime',
    workLocation: 'hybrid'
  },
  {
    id: 3,
    title: 'UI/UX Designer',
    company: 'Creative Labs',
    location: 'Austin, TX (On-site)',
    salary: '$90,000 - $120,000',
    matchScore: 88,
    keyMatches: ['UI/UX Design', 'Figma', 'User Research', 'Prototyping'],
    description: 'Creative Labs is looking for a talented UI/UX Designer to create amazing user experiences. The ideal candidate should have a strong portfolio demonstrating their design skills.',
    posted: '1 week ago',
    logo: 'https://images.pexels.com/photos/5212339/pexels-photo-5212339.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    isBookmarked: false,
    jobType: 'fulltime',
    workLocation: 'onsite'
  },
  {
    id: 4,
    title: 'Frontend Developer',
    company: 'Digital Agency',
    location: 'Chicago, IL (Remote)',
    salary: '$85,000 - $110,000',
    matchScore: 85,
    keyMatches: ['JavaScript', 'React', 'CSS', 'Responsive Design'],
    description: 'We are looking for a talented Frontend Developer to join our team. You will be responsible for implementing visual elements and UI components that users interact with.',
    posted: '5 days ago',
    logo: 'https://images.pexels.com/photos/5212324/pexels-photo-5212324.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    isBookmarked: false,
    jobType: 'fulltime',
    workLocation: 'remote'
  },
  {
    id: 5,
    title: 'React Native Developer',
    company: 'MobileApp Studios',
    location: 'Seattle, WA (Remote)',
    salary: '$100,000 - $130,000',
    matchScore: 82,
    keyMatches: ['React Native', 'JavaScript', 'Mobile Development', 'API Integration'],
    description: 'MobileApp Studios is seeking a React Native Developer to build and maintain mobile applications. The ideal candidate will have experience with cross-platform mobile development.',
    posted: '1 week ago',
    logo: 'https://images.pexels.com/photos/5212307/pexels-photo-5212307.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    isBookmarked: true,
    jobType: 'fulltime',
    workLocation: 'remote'
  },
];

const Matches = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedJob, setSelectedJob] = useState<number | null>(1); // Default to first job
  const [bookmarkedJobs, setBookmarkedJobs] = useState<number[]>(
    matchedJobs.filter(job => job.isBookmarked).map(job => job.id)
  );
  const [appliedFilters, setAppliedFilters] = useState({
    minMatchScore: 80,
    location: 'all',
    jobType: 'all',
  });

  const toggleBookmark = (jobId: number) => {
    if (bookmarkedJobs.includes(jobId)) {
      setBookmarkedJobs(bookmarkedJobs.filter(id => id !== jobId));
    } else {
      setBookmarkedJobs([...bookmarkedJobs, jobId]);
    }
  };

  const filteredJobs = matchedJobs
    .filter(job => job.matchScore >= appliedFilters.minMatchScore)
    .filter(job => {
      if (!searchTerm) return true;
      return (
        job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        job.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
        job.location.toLowerCase().includes(searchTerm.toLowerCase())
      );
    });

  const selectedJobData = matchedJobs.find(job => job.id === selectedJob);

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Job Matches</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <Card className="mb-6">
            <CardBody className="p-4">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  placeholder="Search jobs, companies..."
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </CardBody>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold text-gray-900">Filters</h2>
                <Filter className="h-5 w-5 text-gray-500" />
              </div>
            </CardHeader>
            <CardBody>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Match Score
                  </label>
                  <div className="flex items-center">
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={appliedFilters.minMatchScore}
                      onChange={(e) => setAppliedFilters({
                        ...appliedFilters,
                        minMatchScore: parseInt(e.target.value)
                      })}
                      className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                    />
                    <span className="ml-2 text-sm font-medium text-gray-700">
                      {appliedFilters.minMatchScore}%+
                    </span>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Location
                  </label>
                  <select
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                    value={appliedFilters.location}
                    onChange={(e) => setAppliedFilters({
                      ...appliedFilters,
                      location: e.target.value
                    })}
                  >
                    <option value="all">All Locations</option>
                    <option value="remote">Remote Only</option>
                    <option value="hybrid">Hybrid</option>
                    <option value="onsite">On-site</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Job Type
                  </label>
                  <select
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                    value={appliedFilters.jobType}
                    onChange={(e) => setAppliedFilters({
                      ...appliedFilters,
                      jobType: e.target.value
                    })}
                  >
                    <option value="all">All Types</option>
                    <option value="fulltime">Full-time</option>
                    <option value="parttime">Part-time</option>
                    <option value="contract">Contract</option>
                    <option value="freelance">Freelance</option>
                  </select>
                </div>
              </div>
            </CardBody>
          </Card>

          <div className="space-y-4">
            {filteredJobs.map((job) => (
              <Card 
                key={job.id}
                className={`cursor-pointer border-l-4 transition-all ${
                  selectedJob === job.id 
                    ? 'border-l-primary-500 shadow-md' 
                    : 'border-l-transparent hover:border-l-primary-200'
                }`}
                onClick={() => setSelectedJob(job.id)}
              >
                <CardBody className="p-4">
                  <div className="flex items-start">
                    <img 
                      src={job.logo} 
                      alt={job.company}
                      className="w-12 h-12 rounded object-cover mr-4"
                    />
                    <div className="flex-1">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-medium text-gray-900">{job.title}</h3>
                          <p className="text-sm text-gray-600">{job.company}</p>
                        </div>
                        <div className="flex flex-col items-end">
                          <span 
                            className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                              job.matchScore >= 90
                                ? 'bg-success-100 text-success-800'
                                : job.matchScore >= 80
                                ? 'bg-primary-100 text-primary-800'
                                : 'bg-gray-100 text-gray-800'
                            }`}
                          >
                            {job.matchScore}% Match
                          </span>
                          <p className="text-xs text-gray-500 mt-1">{job.posted}</p>
                        </div>
                      </div>
                      <div className="flex items-center text-xs text-gray-500 mt-1">
                        <MapPin className="h-3 w-3 mr-1" />
                        <span>{job.location}</span>
                      </div>
                    </div>
                  </div>
                </CardBody>
              </Card>
            ))}

            {filteredJobs.length === 0 && (
              <Card>
                <CardBody className="p-6 text-center">
                  <p className="text-gray-500">No jobs match your current filters.</p>
                  <Button
                    variant="outline"
                    size="sm"
                    className="mt-2"
                    onClick={() => {
                      setAppliedFilters({
                        minMatchScore: 0,
                        location: 'all',
                        jobType: 'all',
                      });
                      setSearchTerm('');
                    }}
                  >
                    Reset Filters
                  </Button>
                </CardBody>
              </Card>
            )}
          </div>
        </div>

        <div className="lg:col-span-2">
          {selectedJobData && (
            <Card>
              <CardBody className="p-6">
                <div className="flex flex-col md:flex-row md:items-start justify-between mb-6">
                  <div className="flex items-start">
                    <img 
                      src={selectedJobData.logo} 
                      alt={selectedJobData.company}
                      className="w-16 h-16 rounded object-cover mr-4"
                    />
                    <div>
                      <h2 className="text-2xl font-bold text-gray-900">{selectedJobData.title}</h2>
                      <p className="text-lg text-gray-600">{selectedJobData.company}</p>
                      <div className="flex items-center text-sm text-gray-500 mt-1">
                        <MapPin className="h-4 w-4 mr-1" />
                        <span>{selectedJobData.location}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex mt-4 md:mt-0">
                    <Button
                      variant="outline"
                      size="sm"
                      className="mr-2"
                      onClick={() => toggleBookmark(selectedJobData.id)}
                    >
                      <Star 
                        className={`h-4 w-4 mr-1 ${
                          bookmarkedJobs.includes(selectedJobData.id) 
                            ? 'fill-warning-500 text-warning-500' 
                            : 'text-gray-400'
                        }`} 
                      />
                      {bookmarkedJobs.includes(selectedJobData.id) ? 'Saved' : 'Save'}
                    </Button>
                    <Button variant="primary" size="sm">
                      Apply Now
                    </Button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                  <div className="bg-primary-50 rounded-lg p-4">
                    <div className="flex items-center mb-2">
                      <Zap className="h-5 w-5 text-primary-500 mr-2" />
                      <h3 className="font-semibold text-gray-900">Match Score</h3>
                    </div>
                    <div className="flex items-center">
                      <div className="w-full bg-gray-200 rounded-full h-2.5 mr-2">
                        <div 
                          className="bg-primary-600 h-2.5 rounded-full" 
                          style={{ width: `${selectedJobData.matchScore}%` }}
                        ></div>
                      </div>
                      <span className="text-sm font-medium text-gray-700">
                        {selectedJobData.matchScore}%
                      </span>
                    </div>
                    <div className="mt-3">
                      <p className="text-sm text-gray-600 mb-2">Key Matches:</p>
                      <div className="flex flex-wrap gap-2">
                        {selectedJobData.keyMatches.map((match, index) => (
                          <span 
                            key={index}
                            className="px-2 py-1 rounded-full text-xs bg-primary-100 text-primary-700"
                          >
                            {match}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="flex items-center mb-2">
                      <Briefcase className="h-5 w-5 text-gray-500 mr-2" />
                      <h3 className="font-semibold text-gray-900">Job Details</h3>
                    </div>
                    <div className="space-y-2">
                      <div>
                        <p className="text-sm text-gray-500">Salary Range</p>
                        <p className="text-sm font-medium text-gray-900">{selectedJobData.salary}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Posted</p>
                        <p className="text-sm font-medium text-gray-900">{selectedJobData.posted}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Job Type</p>
                        <p className="text-sm font-medium text-gray-900">Full-time</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mb-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">Job Description</h3>
                  <p className="text-gray-700 mb-4">
                    {selectedJobData.description}
                  </p>
                  <p className="text-gray-700 mb-4">
                    As a {selectedJobData.title} at {selectedJobData.company}, you will be responsible for:
                  </p>
                  <ul className="list-disc pl-5 text-gray-700 space-y-2 mb-4">
                    <li>Developing and maintaining web applications using modern JavaScript frameworks</li>
                    <li>Collaborating with cross-functional teams to define, design, and ship new features</li>
                    <li>Ensuring the technical feasibility of UI/UX designs</li>
                    <li>Optimizing applications for maximum speed and scalability</li>
                    <li>Ensuring all user input is validated before submitting to back-end services</li>
                  </ul>
                  <p className="text-gray-700">
                    We're looking for someone who has:
                  </p>
                  <ul className="list-disc pl-5 text-gray-700 space-y-2">
                    <li>3+ years of experience with JavaScript and modern frameworks (React, Vue, Angular)</li>
                    <li>Strong understanding of web technologies and responsive design</li>
                    <li>Experience with RESTful APIs and modern frontend build pipelines</li>
                    <li>Passion for writing clean, maintainable code</li>
                    <li>Bachelor's degree in Computer Science or related field (or equivalent experience)</li>
                  </ul>
                </div>

                <div className="mb-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">About {selectedJobData.company}</h3>
                  <p className="text-gray-700 mb-4">
                    {selectedJobData.company} is a leading technology company specializing in innovative solutions for businesses. We are committed to creating a diverse and inclusive workplace where all employees can thrive.
                  </p>
                  <div className="flex items-center">
                    <a href="#" className="text-primary-600 hover:text-primary-700 text-sm flex items-center">
                      Learn more about {selectedJobData.company}
                      <ChevronRight className="w-4 h-4 ml-1" />
                    </a>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-3 mt-6">
                  <Button variant="primary" size="lg" className="flex-1">
                    Apply Now
                  </Button>
                  <Button variant="outline" size="lg" className="flex items-center justify-center">
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Apply on Company Site
                  </Button>
                  <Button
                    variant="outline"
                    size="lg"
                    className="sm:flex-initial"
                    onClick={() => toggleBookmark(selectedJobData.id)}
                  >
                    <Star 
                      className={`h-4 w-4 ${
                        bookmarkedJobs.includes(selectedJobData.id) 
                          ? 'fill-warning-500 text-warning-500' 
                          : 'text-gray-400'
                      }`} 
                    />
                  </Button>
                </div>
              </CardBody>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default Matches;