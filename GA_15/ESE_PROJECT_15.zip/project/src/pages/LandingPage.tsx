import { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CheckCircle, FileText, Briefcase, Zap, BarChart4, Users, Target, Shield } from 'lucide-react';
import Button from '../components/common/Button';
import { Card, CardBody } from '../components/common/Card';

const LandingPage = () => {
  const [activeTab, setActiveTab] = useState<'jobSeeker' | 'recruiter'>('jobSeeker');

  const features = [
    {
      icon: <FileText className="w-6 h-6 text-primary-500" />,
      title: 'Smart Resume Parsing',
      description: 'Our AI automatically extracts skills, experience, and qualifications from your resume.',
    },
    {
      icon: <Briefcase className="w-6 h-6 text-primary-500" />,
      title: 'Intelligent Job Matching',
      description: 'Advanced algorithms match your profile with the most relevant job opportunities.',
    },
    {
      icon: <Zap className="w-6 h-6 text-primary-500" />,
      title: 'Real-time Notifications',
      description: 'Get instant alerts when new matching jobs are posted or when recruiters view your profile.',
    },
    {
      icon: <BarChart4 className="w-6 h-6 text-primary-500" />,
      title: 'Detailed Analytics',
      description: 'Track your application performance and get insights to improve your job search strategy.',
    },
    {
      icon: <Users className="w-6 h-6 text-primary-500" />,
      title: 'Talent Pool Access',
      description: 'Recruiters get access to a curated pool of qualified candidates for their job openings.',
    },
    {
      icon: <Target className="w-6 h-6 text-primary-500" />,
      title: 'Precision Matching',
      description: 'Our AI identifies the most qualified candidates based on skills, experience, and cultural fit.',
    },
  ];

  const testimonials = [
    {
      quote: "ResuMatch completely transformed our hiring process. We've reduced time-to-hire by 40% and found better quality candidates.",
      author: "Sarah Johnson",
      role: "HR Director, TechCorp",
      type: "recruiter",
    },
    {
      quote: "After uploading my resume to ResuMatch, I received interview invitations from companies I'd actually want to work for. The matching is spot-on!",
      author: "Michael Chen",
      role: "Software Developer",
      type: "jobSeeker",
    },
    {
      quote: "The detailed match scoring helps us quickly identify the right candidates. We've improved our interview-to-hire ratio significantly.",
      author: "Emily Rodriguez",
      role: "Talent Acquisition, Finance Plus",
      type: "recruiter",
    },
    {
      quote: "I was stuck in my job search until I tried ResuMatch. Within a week, I had three interviews with companies that matched my skills and career goals.",
      author: "David Patel",
      role: "Marketing Specialist",
      type: "jobSeeker",
    },
  ];

  const filteredTestimonials = testimonials.filter(t => 
    activeTab === 'jobSeeker' ? t.type === 'jobSeeker' : t.type === 'recruiter'
  );

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary-900 to-primary-700 text-white">
        <div className="container mx-auto px-4 py-20 md:py-28">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-10 md:mb-0">
              <motion.h1 
                className="text-4xl md:text-5xl font-bold mb-6 leading-tight"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                Find Your Perfect Match with AI-Powered Job Matching
              </motion.h1>
              <motion.p 
                className="text-xl mb-8 text-gray-100 max-w-lg"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
              >
                Upload your resume or job description and let our AI match you with the perfect opportunity or candidate.
              </motion.p>
              <motion.div 
                className="flex flex-col sm:flex-row gap-4"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.4 }}
              >
                <Link to="/register">
                  <Button variant="secondary" size="lg">Get Started</Button>
                </Link>
                <Link to="/features">
                  <Button variant="outline" size="lg" className="border-white text-white hover:bg-white hover:text-primary-800">
                    Learn More
                  </Button>
                </Link>
              </motion.div>
            </div>
            <div className="md:w-1/2">
              <motion.img 
                src="https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Job matching platform" 
                className="rounded-lg shadow-xl w-full object-cover h-96"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: 0.2 }}
              />
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900">How It Works</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our AI-powered platform makes job matching simple and effective for both job seekers and recruiters.
            </p>
          </div>

          <div className="flex justify-center mb-10">
            <div className="inline-flex rounded-md shadow-sm bg-white p-1">
              <button
                type="button"
                className={`px-4 py-2 text-sm font-medium rounded-md ${
                  activeTab === 'jobSeeker'
                    ? 'bg-primary-50 text-primary-700'
                    : 'text-gray-700 hover:bg-gray-50'
                }`}
                onClick={() => setActiveTab('jobSeeker')}
              >
                For Job Seekers
              </button>
              <button
                type="button"
                className={`px-4 py-2 text-sm font-medium rounded-md ${
                  activeTab === 'recruiter'
                    ? 'bg-primary-50 text-primary-700'
                    : 'text-gray-700 hover:bg-gray-50'
                }`}
                onClick={() => setActiveTab('recruiter')}
              >
                For Recruiters
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {activeTab === 'jobSeeker' ? (
              <>
                <Card className="border-0 shadow-md">
                  <CardBody>
                    <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary-100 text-primary-600 mb-4">
                      1
                    </div>
                    <h3 className="text-xl font-semibold mb-2">Upload Your Resume</h3>
                    <p className="text-gray-600">
                      Simply upload your resume in PDF or Word format. Our AI will parse and analyze your skills and experience.
                    </p>
                  </CardBody>
                </Card>
                <Card className="border-0 shadow-md">
                  <CardBody>
                    <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary-100 text-primary-600 mb-4">
                      2
                    </div>
                    <h3 className="text-xl font-semibold mb-2">Get Matched with Jobs</h3>
                    <p className="text-gray-600">
                      Our algorithm matches your profile with available job opportunities based on skills, experience, and preferences.
                    </p>
                  </CardBody>
                </Card>
                <Card className="border-0 shadow-md">
                  <CardBody>
                    <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary-100 text-primary-600 mb-4">
                      3
                    </div>
                    <h3 className="text-xl font-semibold mb-2">Apply with Confidence</h3>
                    <p className="text-gray-600">
                      Review your match scores and apply to positions where you have the highest chance of success.
                    </p>
                  </CardBody>
                </Card>
              </>
            ) : (
              <>
                <Card className="border-0 shadow-md">
                  <CardBody>
                    <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary-100 text-primary-600 mb-4">
                      1
                    </div>
                    <h3 className="text-xl font-semibold mb-2">Post Job Description</h3>
                    <p className="text-gray-600">
                      Create detailed job postings with required skills, experience, and qualifications.
                    </p>
                  </CardBody>
                </Card>
                <Card className="border-0 shadow-md">
                  <CardBody>
                    <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary-100 text-primary-600 mb-4">
                      2
                    </div>
                    <h3 className="text-xl font-semibold mb-2">Get Matched Candidates</h3>
                    <p className="text-gray-600">
                      Our AI matches your job posting with qualified candidates and ranks them by compatibility.
                    </p>
                  </CardBody>
                </Card>
                <Card className="border-0 shadow-md">
                  <CardBody>
                    <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary-100 text-primary-600 mb-4">
                      3
                    </div>
                    <h3 className="text-xl font-semibold mb-2">Hire Efficiently</h3>
                    <p className="text-gray-600">
                      Review candidate matches, schedule interviews, and track applicants through the hiring process.
                    </p>
                  </CardBody>
                </Card>
              </>
            )}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900">Powerful Features</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our platform is designed to make the job matching process efficient and effective.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="h-full">
                  <CardBody>
                    <div className="flex items-center mb-4">
                      {feature.icon}
                      <h3 className="text-lg font-semibold ml-3">{feature.title}</h3>
                    </div>
                    <p className="text-gray-600">{feature.description}</p>
                  </CardBody>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900">What People Are Saying</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Hear from job seekers and recruiters who have found success with our platform.
            </p>
            
            <div className="flex justify-center mt-8 mb-12">
              <div className="inline-flex rounded-md shadow-sm bg-white p-1">
                <button
                  type="button"
                  className={`px-4 py-2 text-sm font-medium rounded-md ${
                    activeTab === 'jobSeeker'
                      ? 'bg-primary-50 text-primary-700'
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                  onClick={() => setActiveTab('jobSeeker')}
                >
                  Job Seekers
                </button>
                <button
                  type="button"
                  className={`px-4 py-2 text-sm font-medium rounded-md ${
                    activeTab === 'recruiter'
                      ? 'bg-primary-50 text-primary-700'
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                  onClick={() => setActiveTab('recruiter')}
                >
                  Recruiters
                </button>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {filteredTestimonials.map((testimonial, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="h-full border-0 shadow-md">
                  <CardBody>
                    <div className="flex items-start mb-4">
                      <div className="text-primary-500">
                        <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 32 32">
                          <path d="M9.352 4C4.456 7.456 1 13.12 1 19.36c0 5.088 3.072 8.064 6.624 8.064 3.36 0 5.856-2.688 5.856-5.856 0-3.168-2.208-5.472-5.088-5.472-.576 0-1.344.096-1.536.192.48-3.264 3.552-7.104 6.624-9.024L9.352 4zm16.512 0c-4.8 3.456-8.256 9.12-8.256 15.36 0 5.088 3.072 8.064 6.624 8.064 3.264 0 5.856-2.688 5.856-5.856 0-3.168-2.304-5.472-5.184-5.472-.576 0-1.248.096-1.44.192.48-3.264 3.456-7.104 6.528-9.024L25.864 4z" />
                        </svg>
                      </div>
                      <div className="ml-4">
                        <p className="text-gray-700 mb-4">{testimonial.quote}</p>
                        <div>
                          <p className="font-semibold text-gray-900">{testimonial.author}</p>
                          <p className="text-sm text-gray-500">{testimonial.role}</p>
                        </div>
                      </div>
                    </div>
                  </CardBody>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary-800 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Find Your Perfect Match?</h2>
          <p className="text-xl mb-10 max-w-3xl mx-auto text-primary-100">
            Join thousands of job seekers and recruiters who are using ResuMatch to connect with the right opportunities and talent.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/register">
              <Button 
                variant="secondary" 
                size="lg"
              >
                Create Free Account
              </Button>
            </Link>
            <Link to="/features">
              <Button 
                variant="outline" 
                size="lg" 
                className="border-white text-white hover:bg-white hover:text-primary-800"
              >
                Learn More
              </Button>
            </Link>
          </div>
          <div className="mt-8 flex items-center justify-center text-primary-200">
            <CheckCircle className="w-5 h-5 mr-2" />
            <span>No credit card required</span>
          </div>
        </div>
      </section>
    </div>
  );
};

export default LandingPage;