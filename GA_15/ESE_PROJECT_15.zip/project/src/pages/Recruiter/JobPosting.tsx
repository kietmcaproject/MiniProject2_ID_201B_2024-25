import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardBody, CardHeader, CardFooter } from '../../components/common/Card';
import Button from '../../components/common/Button';
import { Plus, Minus, AlertCircle, CheckCircle, Briefcase as BriefcaseBusiness } from 'lucide-react';
import { useToast } from '../../context/ToastContext';

const JobPosting = () => {
  const { showToast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    department: '',
    location: '',
    locationType: 'onsite',
    employmentType: 'fulltime',
    salary: {
      min: '',
      max: '',
      currency: 'USD',
      period: 'yearly',
    },
    description: '',
    requirements: ['', ''],
    responsibilities: ['', ''],
    benefits: ['', ''],
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    
    if (name.includes('.')) {
      const [parent, child] = name.split('.');
      setFormData({
        ...formData,
        [parent]: {
          ...formData[parent as keyof typeof formData] as any,
          [child]: value,
        },
      });
    } else {
      setFormData({
        ...formData,
        [name]: value,
      });
    }
  };

  const handleArrayChange = (type: 'requirements' | 'responsibilities' | 'benefits', index: number, value: string) => {
    const newArray = [...formData[type]];
    newArray[index] = value;
    setFormData({
      ...formData,
      [type]: newArray,
    });
  };

  const addArrayItem = (type: 'requirements' | 'responsibilities' | 'benefits') => {
    setFormData({
      ...formData,
      [type]: [...formData[type], ''],
    });
  };

  const removeArrayItem = (type: 'requirements' | 'responsibilities' | 'benefits', index: number) => {
    const newArray = [...formData[type]];
    newArray.splice(index, 1);
    setFormData({
      ...formData,
      [type]: newArray,
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Form validation
    if (!formData.title || !formData.description) {
      showToast('Please fill in all required fields', 'error');
      return;
    }
    
    try {
      setIsSubmitting(true);
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Success
      showToast('Job posting created successfully!', 'success');
      // In a real app, redirect to the job listings page or the newly created job
      
      // For demo purposes, we'll just reset the form
      setFormData({
        title: '',
        department: '',
        location: '',
        locationType: 'onsite',
        employmentType: 'fulltime',
        salary: {
          min: '',
          max: '',
          currency: 'USD',
          period: 'yearly',
        },
        description: '',
        requirements: ['', ''],
        responsibilities: ['', ''],
        benefits: ['', ''],
      });
      
    } catch (error) {
      showToast('Error creating job posting', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold text-gray-900 mb-6">Post a New Job</h1>
        
        <form onSubmit={handleSubmit}>
          <Card className="mb-6">
            <CardHeader>
              <h2 className="text-xl font-semibold text-gray-900">Basic Information</h2>
            </CardHeader>
            <CardBody>
              <div className="space-y-6">
                <div>
                  <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                    Job Title <span className="text-error-500">*</span>
                  </label>
                  <input
                    type="text"
                    id="title"
                    name="title"
                    value={formData.title}
                    onChange={handleInputChange}
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                    placeholder="e.g. Senior Frontend Developer"
                    required
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="department" className="block text-sm font-medium text-gray-700 mb-1">
                      Department
                    </label>
                    <input
                      type="text"
                      id="department"
                      name="department"
                      value={formData.department}
                      onChange={handleInputChange}
                      className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                      placeholder="e.g. Engineering"
                    />
                  </div>
                  <div>
                    <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-1">
                      Location
                    </label>
                    <input
                      type="text"
                      id="location"
                      name="location"
                      value={formData.location}
                      onChange={handleInputChange}
                      className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                      placeholder="e.g. San Francisco, CA"
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="locationType" className="block text-sm font-medium text-gray-700 mb-1">
                      Location Type
                    </label>
                    <select
                      id="locationType"
                      name="locationType"
                      value={formData.locationType}
                      onChange={handleInputChange}
                      className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                    >
                      <option value="onsite">On-site</option>
                      <option value="remote">Remote</option>
                      <option value="hybrid">Hybrid</option>
                    </select>
                  </div>
                  <div>
                    <label htmlFor="employmentType" className="block text-sm font-medium text-gray-700 mb-1">
                      Employment Type
                    </label>
                    <select
                      id="employmentType"
                      name="employmentType"
                      value={formData.employmentType}
                      onChange={handleInputChange}
                      className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                    >
                      <option value="fulltime">Full-time</option>
                      <option value="parttime">Part-time</option>
                      <option value="contract">Contract</option>
                      <option value="internship">Internship</option>
                      <option value="freelance">Freelance</option>
                    </select>
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Salary Range
                  </label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div>
                      <select
                        id="salaryCurrency"
                        name="salary.currency"
                        value={formData.salary.currency}
                        onChange={handleInputChange}
                        className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                      >
                        <option value="USD">USD</option>
                        <option value="EUR">EUR</option>
                        <option value="GBP">GBP</option>
                        <option value="CAD">CAD</option>
                        <option value="AUD">AUD</option>
                      </select>
                    </div>
                    <div>
                      <input
                        type="number"
                        id="salaryMin"
                        name="salary.min"
                        value={formData.salary.min}
                        onChange={handleInputChange}
                        className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                        placeholder="Min"
                      />
                    </div>
                    <div>
                      <input
                        type="number"
                        id="salaryMax"
                        name="salary.max"
                        value={formData.salary.max}
                        onChange={handleInputChange}
                        className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                        placeholder="Max"
                      />
                    </div>
                    <div>
                      <select
                        id="salaryPeriod"
                        name="salary.period"
                        value={formData.salary.period}
                        onChange={handleInputChange}
                        className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                      >
                        <option value="yearly">Yearly</option>
                        <option value="monthly">Monthly</option>
                        <option value="hourly">Hourly</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>
            </CardBody>
          </Card>
          
          <Card className="mb-6">
            <CardHeader>
              <h2 className="text-xl font-semibold text-gray-900">Job Description</h2>
            </CardHeader>
            <CardBody>
              <div className="space-y-6">
                <div>
                  <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                    Description <span className="text-error-500">*</span>
                  </label>
                  <textarea
                    id="description"
                    name="description"
                    rows={6}
                    value={formData.description}
                    onChange={handleInputChange}
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                    placeholder="Provide a detailed description of the job..."
                    required
                  />
                </div>
                
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="block text-sm font-medium text-gray-700">
                      Requirements
                    </label>
                    <button
                      type="button"
                      onClick={() => addArrayItem('requirements')}
                      className="inline-flex items-center p-1 border border-transparent rounded-full shadow-sm text-white bg-primary-600 hover:bg-primary-700 focus:outline-none"
                    >
                      <Plus className="h-4 w-4" />
                    </button>
                  </div>
                  <div className="space-y-2">
                    {formData.requirements.map((req, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <input
                          type="text"
                          value={req}
                          onChange={(e) => handleArrayChange('requirements', index, e.target.value)}
                          className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                          placeholder={`Requirement ${index + 1}`}
                        />
                        {formData.requirements.length > 1 && (
                          <button
                            type="button"
                            onClick={() => removeArrayItem('requirements', index)}
                            className="inline-flex items-center p-1 border border-transparent rounded-full shadow-sm text-white bg-error-600 hover:bg-error-700 focus:outline-none"
                          >
                            <Minus className="h-4 w-4" />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
                
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="block text-sm font-medium text-gray-700">
                      Responsibilities
                    </label>
                    <button
                      type="button"
                      onClick={() => addArrayItem('responsibilities')}
                      className="inline-flex items-center p-1 border border-transparent rounded-full shadow-sm text-white bg-primary-600 hover:bg-primary-700 focus:outline-none"
                    >
                      <Plus className="h-4 w-4" />
                    </button>
                  </div>
                  <div className="space-y-2">
                    {formData.responsibilities.map((resp, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <input
                          type="text"
                          value={resp}
                          onChange={(e) => handleArrayChange('responsibilities', index, e.target.value)}
                          className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                          placeholder={`Responsibility ${index + 1}`}
                        />
                        {formData.responsibilities.length > 1 && (
                          <button
                            type="button"
                            onClick={() => removeArrayItem('responsibilities', index)}
                            className="inline-flex items-center p-1 border border-transparent rounded-full shadow-sm text-white bg-error-600 hover:bg-error-700 focus:outline-none"
                          >
                            <Minus className="h-4 w-4" />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
                
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="block text-sm font-medium text-gray-700">
                      Benefits
                    </label>
                    <button
                      type="button"
                      onClick={() => addArrayItem('benefits')}
                      className="inline-flex items-center p-1 border border-transparent rounded-full shadow-sm text-white bg-primary-600 hover:bg-primary-700 focus:outline-none"
                    >
                      <Plus className="h-4 w-4" />
                    </button>
                  </div>
                  <div className="space-y-2">
                    {formData.benefits.map((benefit, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <input
                          type="text"
                          value={benefit}
                          onChange={(e) => handleArrayChange('benefits', index, e.target.value)}
                          className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                          placeholder={`Benefit ${index + 1}`}
                        />
                        {formData.benefits.length > 1 && (
                          <button
                            type="button"
                            onClick={() => removeArrayItem('benefits', index)}
                            className="inline-flex items-center p-1 border border-transparent rounded-full shadow-sm text-white bg-error-600 hover:bg-error-700 focus:outline-none"
                          >
                            <Minus className="h-4 w-4" />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </CardBody>
          </Card>
          
          <Card className="mb-6">
            <CardHeader>
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold text-gray-900">Matching Settings</h2>
                <div className="flex items-center">
                  <span className="text-sm text-primary-600 font-medium">AI-Powered Matching</span>
                  <div className="relative inline-block w-10 ml-2 align-middle select-none">
                    <input
                      type="checkbox"
                      id="enableMatching"
                      name="enableMatching"
                      defaultChecked
                      className="sr-only"
                    />
                    <label
                      htmlFor="enableMatching"
                      className="block h-6 overflow-hidden bg-gray-200 rounded-full cursor-pointer"
                    >
                      <span className="block h-6 w-6 bg-white rounded-full transform transition-transform duration-200 ease-in-out" />
                    </label>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardBody>
              <div className="p-4 bg-primary-50 rounded-lg border border-primary-100">
                <div className="flex items-start">
                  <div className="flex-shrink-0">
                    <BriefcaseBusiness className="h-6 w-6 text-primary-600" />
                  </div>
                  <div className="ml-3">
                    <h3 className="text-sm font-medium text-primary-800">Intelligent Matching Enabled</h3>
                    <div className="mt-2 text-sm text-primary-700">
                      <p>
                        Our AI will automatically match this job posting with qualified candidates based on:
                      </p>
                      <ul className="list-disc pl-5 mt-1 space-y-1">
                        <li>Skills and experience from the job description</li>
                        <li>Required qualifications and expertise</li>
                        <li>Location preferences and work arrangements</li>
                        <li>Cultural fit indicators and career progression</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </CardBody>
          </Card>
          
          <div className="flex justify-end space-x-3">
            <Link to="/recruiter/dashboard">
              <Button variant="outline" size="lg">
                Cancel
              </Button>
            </Link>
            <Button 
              type="submit" 
              variant="primary" 
              size="lg"
              isLoading={isSubmitting}
            >
              Post Job
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default JobPosting;