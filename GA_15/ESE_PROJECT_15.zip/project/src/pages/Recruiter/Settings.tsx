import React, { useState } from 'react';

const RecruiterSettings = () => {
  const [companyName, setCompanyName] = useState('Tech Innovators');
  const [email, setEmail] = useState('recruiter@example.com');
  const [notifications, setNotifications] = useState(true);
  const [password, setPassword] = useState('');

  const handleSave = () => {
    alert('Settings saved successfully!');
  };

  return (
    <div className="max-w-4xl mx-auto p-8 bg-white shadow-lg rounded-lg mt-10">
      <h1 className="text-3xl font-bold text-blue-700 mb-8">Recruiter Settings</h1>

      {/* Company Info */}
      <div className="mb-6">
        <label className="block font-medium mb-1">Company Name</label>
        <input
          type="text"
          value={companyName}
          onChange={(e) => setCompanyName(e.target.value)}
          className="w-full border border-gray-300 p-3 rounded-md"
        />
      </div>

      {/* Email */}
      <div className="mb-6">
        <label className="block font-medium mb-1">Email</label>
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full border border-gray-300 p-3 rounded-md"
        />
      </div>

      {/* Password Change */}
      <div className="mb-6">
        <label className="block font-medium mb-1">Change Password</label>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full border border-gray-300 p-3 rounded-md"
          placeholder="New Password"
        />
      </div>

      {/* Notifications */}
      <div className="flex items-center mb-6">
        <input
          type="checkbox"
          checked={notifications}
          onChange={() => setNotifications(!notifications)}
          className="mr-2"
        />
        <label className="text-gray-700">Enable Email Notifications</label>
      </div>

      {/* Save Button */}
      <button
        onClick={handleSave}
        className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 transition"
      >
        Save Settings
      </button>
    </div>
  );
};

export default RecruiterSettings;
