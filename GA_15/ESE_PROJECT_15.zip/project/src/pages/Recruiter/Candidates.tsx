import React from 'react';

const candidates = [
  { name: 'Aman Verma', position: 'Backend Developer', match: '87%' },
  { name: 'Priya Sharma', position: 'Frontend Developer', match: '92%' },
  { name: 'Ravi Kumar', position: 'DevOps Engineer', match: '85%' },
];

const getMatchColor = (match) => {
  const value = parseInt(match);
  if (value >= 90) return 'bg-green-100 text-green-700';
  if (value >= 80) return 'bg-yellow-100 text-yellow-700';
  return 'bg-red-100 text-red-700';
};

const getInitials = (name) => {
  return name
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase();
};

const Candidates = () => {
  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-6 text-gray-800">Matched Candidates</h1>
      <div className="bg-white shadow-xl rounded-lg overflow-hidden">
        <table className="min-w-full table-auto text-left">
          <thead className="bg-gray-100">
            <tr>
              <th className="px-6 py-4 text-gray-700 font-medium">Name</th>
              <th className="px-6 py-4 text-gray-700 font-medium">Position</th>
              <th className="px-6 py-4 text-gray-700 font-medium">Match %</th>
            </tr>
          </thead>
          <tbody>
            {candidates.map((c, i) => (
              <tr key={i} className="border-t hover:bg-gray-50 transition">
                <td className="px-6 py-4 flex items-center space-x-4">
                  <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center font-bold">
                    {getInitials(c.name)}
                  </div>
                  <span>{c.name}</span>
                </td>
                <td className="px-6 py-4">{c.position}</td>
                <td className="px-6 py-4">
                  <span className={`px-3 py-1 rounded-full text-sm font-semibold ${getMatchColor(c.match)}`}>
                    {c.match}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Candidates;
