import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardBody, CardHeader } from '../../components/common/Card';
import Button from '../../components/common/Button';
import { BarChart4, FileUp, Briefcase, User, Settings, Users, PlusCircle } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

// Mock data for demonstration
const dashboardStats = {
  activeJobs: 5,
  totalApplications: 47,
  newApplications: 12,
  potentialMatches: 28,
  interviewsScheduled: 8,
};

const recentApplications = [
  {
    id: 1,
    name: 'Ankit',
    position: 'Senior Frontend Developer',
    matchScore: 95,
    appliedDate: '2 days ago',
    status: 'new',
    avatar: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
  },
  {
    id: 2,
    name: 'Sarah',
    position: 'UI/UX Designer',
    matchScore: 92,
    appliedDate: '3 days ago',
    status: 'reviewing',
    avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
  },
  {
    id: 3,
    name: 'Ashutosh',
    position: 'Full Stack Developer',
    matchScore: 88,
    appliedDate: '1 week ago',
    status: 'interviewing',
    avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
  },
];

const activeJobs = [
  {
    id: 1,
    title: 'Frontend Developer',
    location: 'Delhi (Remote)',
    applications: 18,
    views: 245,
    posted: '2 weeks ago',
  },
  {
    id: 2,
    title: 'UI/UX Designer',
    location: 'Gurugram (On-site)',
    applications: 12,
    views: 187,
    posted: '1 week ago',
  },
  {
    id: 3,
    title: 'Full Stack Developer',
    location: 'Hyderabad (Hybrid)',
    applications: 9,
    views: 156,
    posted: '5 days ago',
  },
  {
    id: 4,
    title: 'React Native Developer',
    location: 'Bengaluru (Remote)',
    applications: 8,
    views: 132,
    posted: '3 days ago',
  },
];

const RecruiterDashboard = () => {
  const { user } = useAuth();

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'new':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-100 text-primary-800">
            New
          </span>
        );
      case 'reviewing':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-warning-100 text-warning-800">
            Reviewing
          </span>
        );
      case 'interviewing':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-secondary-100 text-secondary-800">
            Interviewing
          </span>
        );
      case 'offered':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-success-100 text-success-800">
            Offered
          </span>
        );
      case 'rejected':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-error-100 text-error-800">
            Rejected
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row items-start gap-6">
        {/* Sidebar */}
        <aside className="w-full md:w-64 lg:w-72 mb-6 md:mb-0 sticky top-24">
          <Card className="mb-6">
            <CardBody>
              <div className="flex flex-col items-center text-center">
                <div className="w-20 h-20 rounded-full bg-primary-100 flex items-center justify-center mb-4">
                  <User className="w-10 h-10 text-primary-600" />
                </div>
                <h2 className="text-xl font-semibold text-gray-900">{user?.name}</h2>
                <p className="text-gray-500 mb-4">Tech Innovators</p>
                <Link to="/recruiter/profile">
                  <Button variant="outline" size="sm" className="w-full">
                    Edit Profile
                  </Button>
                </Link>
              </div>
            </CardBody>
          </Card>

          <Card>
            <CardBody className="p-0">
              <nav className="flex flex-col">
                <Link
                  to="/recruiter/dashboard"
                  className="flex items-center space-x-3 px-4 py-3 text-primary-600 bg-primary-50 border-l-4 border-primary-600"
                >
                  <BarChart4 className="w-5 h-5" />
                  <span className="font-medium">Dashboard</span>
                </Link>
                <Link
                  to="/recruiter/job-posting"
                  className="flex items-center space-x-3 px-4 py-3 text-gray-700 hover:bg-gray-50 border-l-4 border-transparent hover:border-primary-300"
                >
                  <FileUp className="w-5 h-5" />
                  <span className="font-medium">Job Postings</span>
                </Link>
                <Link
                  to="/recruiter/applications"
                  className="flex items-center space-x-3 px-4 py-3 text-gray-700 hover:bg-gray-50 border-l-4 border-transparent hover:border-primary-300"
                >
                  <Briefcase className="w-5 h-5" />
                  <span className="font-medium">Applications</span>
                </Link>
                <Link
                  to="/recruiter/candidates"
                  className="flex items-center space-x-3 px-4 py-3 text-gray-700 hover:bg-gray-50 border-l-4 border-transparent hover:border-primary-300"
                >
                  <Users className="w-5 h-5" />
                  <span className="font-medium">Candidates</span>
                </Link>
                <Link
                  to="/recruiter/settings"
                  className="flex items-center space-x-3 px-4 py-3 text-gray-700 hover:bg-gray-50 border-l-4 border-transparent hover:border-primary-300"
                >
                  <Settings className="w-5 h-5" />
                  <span className="font-medium">Settings</span>
                </Link>
              </nav>
            </CardBody>
          </Card>
        </aside>

        {/* Main Content */}
        <div className="flex-1">
          {/* Welcome Banner */}
          <Card className="mb-6 bg-gradient-to-r from-primary-700 to-primary-800 text-white overflow-hidden">
            <CardBody className="p-6 md:p-8">
              <div className="flex flex-col md:flex-row items-center justify-between">
                <div>
                  <h1 className="text-2xl md:text-3xl font-bold mb-3">Welcome back, {user?.name?.split(' ')[0]}!</h1>
                  <p className="text-primary-50 max-w-lg">
                    You have {dashboardStats.newApplications} new applications and {dashboardStats.potentialMatches} potential candidate matches.
                  </p>
                </div>
                <Link to="/recruiter/job-posting" className="mt-4 md:mt-0">
                  <Button 
                    variant="secondary" 
                    size="md" 
                    className="whitespace-nowrap"
                  >
                    Post a New Job
                  </Button>
                </Link>
              </div>
            </CardBody>
          </Card>

          {/* Stats Row */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <Card>
              <CardBody className="p-4">
                <div className="flex items-center">
                  <div className="p-3 rounded-full bg-primary-100 text-primary-600 mr-4">
                    <Briefcase className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Active Jobs</p>
                    <p className="text-2xl font-semibold text-gray-900">{dashboardStats.activeJobs}</p>
                  </div>
                </div>
              </CardBody>
            </Card>
            <Card>
              <CardBody className="p-4">
                <div className="flex items-center">
                  <div className="p-3 rounded-full bg-success-100 text-success-600 mr-4">
                    <Users className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Total Applications</p>
                    <p className="text-2xl font-semibold text-gray-900">{dashboardStats.totalApplications}</p>
                  </div>
                </div>
              </CardBody>
            </Card>
            <Card>
              <CardBody className="p-4">
                <div className="flex items-center">
                  <div className="p-3 rounded-full bg-secondary-100 text-secondary-600 mr-4">
                    <User className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Potential Matches</p>
                    <p className="text-2xl font-semibold text-gray-900">{dashboardStats.potentialMatches}</p>
                  </div>
                </div>
              </CardBody>
            </Card>
          </div>

          {/* Recent Applications */}
          <Card className="mb-6">
            <CardHeader>
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold text-gray-900">Recent Applications</h2>
                <Link to="/recruiter/applications">
                  <Button variant="outline" size="sm">
                    View All
                  </Button>
                </Link>
              </div>
            </CardHeader>
            <CardBody>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Candidate
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Position
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Match
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Applied
                      </th>
                      <th scope="col" className="relative px-6 py-3">
                        <span className="sr-only">Actions</span>
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {recentApplications.map((application) => (
                      <tr key={application.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="flex-shrink-0 h-10 w-10">
                              <img className="h-10 w-10 rounded-full object-cover" src={application.avatar} alt="" />
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-gray-900">{application.name}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{application.position}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900 font-medium">{application.matchScore}%</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {getStatusBadge(application.status)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {application.appliedDate}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          <Button variant="outline" size="sm">
                            Review
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardBody>
          </Card>

          {/* Active Job Postings */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold text-gray-900">Active Job Postings</h2>
                <Link to="/recruiter/job-posting">
                  <Button variant="primary" size="sm" className="flex items-center">
                    <PlusCircle className="w-4 h-4 mr-1" />
                    New Job
                  </Button>
                </Link>
              </div>
            </CardHeader>
            <CardBody>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Position
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Location
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Applications
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Views
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Posted
                      </th>
                      <th scope="col" className="relative px-6 py-3">
                        <span className="sr-only">Actions</span>
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {activeJobs.map((job) => (
                      <tr key={job.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-gray-900">{job.title}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-500">{job.location}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{job.applications}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-500">{job.views}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {job.posted}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          <div className="flex space-x-2 justify-end">
                            <Button variant="outline" size="sm">
                              Edit
                            </Button>
                            <Button variant="outline" size="sm">
                              View
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardBody>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default RecruiterDashboard;