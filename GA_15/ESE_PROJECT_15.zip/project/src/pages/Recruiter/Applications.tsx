import { useState } from 'react';
import { Card, CardBody, CardHeader } from '../../components/common/Card';
import Button from '../../components/common/Button';
import { Search, Filter, Download, Mail, Calendar, ChevronRight, Star } from 'lucide-react';
import { useToast } from '../../context/ToastContext';

// Mock data
const applications = [
  {
    id: 1,
    name: 'Ankit Kumar',
    email: 'Ankit@kiet.edu',
    position: 'Frontend Developer',
    appliedDate: '2023-05-15',
    matchScore: 95,
    status: 'new',
    resumeUrl: '#',
    avatar: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
  },
  {
    id: 2,
    name: 'Sarah',
    email: 'sarah@gmail..com',
    position: 'UI/UX Designer',
    appliedDate: '2023-05-14',
    matchScore: 92,
    status: 'reviewing',
    resumeUrl: '#',
    avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
  },
  {
    id: 3,
    name: 'Ashutosh Singh',
    email: 'ashutosh2426mca2507@kiet.edu',
    position: 'Full Stack Developer',
    appliedDate: '2023-05-10',
    matchScore: 88,
    status: 'interviewing',
    resumeUrl: '#',
    avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
  },
  {
    id: 4,
    name: 'Katreena',
    email: 'katreenakaif425@gmail.com',
    position: 'Frontend Developer',
    appliedDate: '2023-05-08',
    matchScore: 84,
    status: 'offered',
    resumeUrl: '#',
    avatar: 'https://images.pexels.com/photos/733872/pexels-photo-733872.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
  },
  {
    id: 5,
    name: 'Ansh Mishra',
    email: 'anshmishra07@kiet.edu',
    position: 'React Native Developer',
    appliedDate: '2023-05-05',
    matchScore: 79,
    status: 'rejected',
    resumeUrl: '#',
    avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
  },
];

// Mock candidate skills
const candidateSkills = {
  1: ['JavaScript', 'React', 'TypeScript', 'HTML/CSS', 'Node.js', 'Redux', 'GraphQL', 'Responsive Design'],
  2: ['UI/UX Design', 'Figma', 'Adobe XD', 'User Research', 'Wireframing', 'Prototyping', 'Design Systems'],
  3: ['JavaScript', 'React', 'Node.js', 'Express', 'MongoDB', 'RESTful APIs', 'Git', 'AWS'],
  4: ['HTML/CSS', 'JavaScript', 'React', 'SCSS', 'Bootstrap', 'Tailwind CSS', 'Webpack'],
  5: ['React Native', 'JavaScript', 'TypeScript', 'Mobile Development', 'Redux', 'API Integration'],
};

// Mock candidate experience
const candidateExperience = {
  1: [
    {
      title: 'Frontend Developer',
      company: 'Tech Solutions Inc.',
      duration: 'Jan 2019 - Present',
      description: 'Led the development of multiple web applications using React and TypeScript. Implemented responsive designs and improved performance.',
    },
    {
      title: 'Junior Web Developer',
      company: 'Digital Agency',
      duration: 'Mar 2017 - Dec 2018',
      description: 'Developed and maintained client websites. Worked with HTML, CSS, JavaScript, and jQuery.',
    },
  ],
  2: [
    {
      title: 'UI Designer',
      company: 'Creative Labs',
      duration: 'Jun 2018 - Present',
      description: 'Created user interfaces for web and mobile applications. Conducted user research and usability testing.',
    },
    {
      title: 'Graphic Designer',
      company: 'Design Studio',
      duration: 'Sep 2016 - May 2018',
      description: 'Designed marketing materials, logos, and brand identities for various clients.',
    },
  ],
  3: [
    {
      title: 'Full Stack Developer',
      company: 'WebSolutions',
      duration: 'Apr 2020 - Present',
      description: 'Developed and maintained web applications using the MERN stack. Implemented RESTful APIs and database structures.',
    },
    {
      title: 'Backend Developer',
      company: 'Data Systems',
      duration: 'Jul 2018 - Mar 2020',
      description: 'Built and maintained server-side applications using Node.js and Express. Worked with SQL and NoSQL databases.',
    },
  ],
  4: [
    {
      title: 'Frontend Developer',
      company: 'Interactive Media',
      duration: 'Feb 2019 - Present',
      description: 'Developed user interfaces for web applications using React. Implemented responsive designs and animations.',
    },
    {
      title: 'Web Developer Intern',
      company: 'Tech Startup',
      duration: 'Jun 2018 - Jan 2019',
      description: 'Assisted in developing and maintaining company website and client projects using HTML, CSS, and JavaScript.',
    },
  ],
  5: [
    {
      title: 'Mobile Developer',
      company: 'App Studio',
      duration: 'Sep 2019 - Present',
      description: 'Developed cross-platform mobile applications using React Native. Implemented features, fixed bugs, and optimized performance.',
    },
    {
      title: 'Frontend Developer',
      company: 'Web Agency',
      duration: 'Jan 2018 - Aug 2019',
      description: 'Created responsive web applications using React and Redux. Collaborated with designers to implement UI/UX designs.',
    },
  ],
};

// Status options
const statusOptions = [
  { value: 'new', label: 'New', color: 'bg-primary-100 text-primary-800' },
  { value: 'reviewing', label: 'Reviewing', color: 'bg-warning-100 text-warning-800' },
  { value: 'interviewing', label: 'Interviewing', color: 'bg-secondary-100 text-secondary-800' },
  { value: 'offered', label: 'Offered', color: 'bg-success-100 text-success-800' },
  { value: 'rejected', label: 'Rejected', color: 'bg-error-100 text-error-800' },
];

const Applications = () => {
  const { showToast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');
  const [filters, setFilters] = useState({
    position: 'all',
    status: 'all',
    matchScore: 0,
  });
  const [selectedCandidate, setSelectedCandidate] = useState<number | null>(null);
  const [starredCandidates, setStarredCandidates] = useState<number[]>([]);

  const toggleStarCandidate = (id: number) => {
    if (starredCandidates.includes(id)) {
      setStarredCandidates(starredCandidates.filter(candidateId => candidateId !== id));
    } else {
      setStarredCandidates([...starredCandidates, id]);
    }
  };

  const handleStatusChange = (id: number, newStatus: string) => {
    // In a real app, this would update the database
    // For this demo, we'll just show a toast
    const candidate = applications.find(app => app.id === id);
    const statusLabel = statusOptions.find(option => option.value === newStatus)?.label;
    
    showToast(`${candidate?.name}'s status updated to ${statusLabel}`, 'success');
  };

  const scheduleInterview = (id: number) => {
    // In a real app, this would open a calendar integration
    // For this demo, we'll just show a toast
    const candidate = applications.find(app => app.id === id);
    showToast(`Interview scheduling initiated for ${candidate?.name}`, 'info');
  };

  const sendEmail = (id: number) => {
    // In a real app, this would open an email composition modal
    // For this demo, we'll just show a toast
    const candidate = applications.find(app => app.id === id);
    showToast(`Email composition initiated for ${candidate?.name}`, 'info');
  };

  const filteredApplications = applications.filter(application => {
    // Filter by search term
    const searchMatch = 
      application.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      application.position.toLowerCase().includes(searchTerm.toLowerCase()) ||
      application.email.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Filter by position
    const positionMatch = filters.position === 'all' || application.position === filters.position;
    
    // Filter by status
    const statusMatch = filters.status === 'all' || application.status === filters.status;
    
    // Filter by match score
    const scoreMatch = application.matchScore >= filters.matchScore;
    
    return searchMatch && positionMatch && statusMatch && scoreMatch;
  });

  const getStatusBadge = (status: string) => {
    const statusOption = statusOptions.find(option => option.value === status);
    return statusOption ? (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${statusOption.color}`}>
        {statusOption.label}
      </span>
    ) : null;
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Applications</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <Card className="mb-6">
            <CardBody className="p-4">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  placeholder="Search candidates..."
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </CardBody>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold text-gray-900">Filters</h2>
                <Filter className="h-5 w-5 text-gray-500" />
              </div>
            </CardHeader>
            <CardBody>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Position
                  </label>
                  <select
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                    value={filters.position}
                    onChange={(e) => setFilters({...filters, position: e.target.value})}
                  >
                    <option value="all">All Positions</option>
                    <option value="Senior Frontend Developer">Senior Frontend Developer</option>
                    <option value="UI/UX Designer">UI/UX Designer</option>
                    <option value="Full Stack Developer">Full Stack Developer</option>
                    <option value="Frontend Developer">Frontend Developer</option>
                    <option value="React Native Developer">React Native Developer</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Status
                  </label>
                  <select
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                    value={filters.status}
                    onChange={(e) => setFilters({...filters, status: e.target.value})}
                  >
                    <option value="all">All Statuses</option>
                    {statusOptions.map(option => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Minimum Match Score
                  </label>
                  <div className="flex items-center">
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={filters.matchScore}
                      onChange={(e) => setFilters({...filters, matchScore: parseInt(e.target.value)})}
                      className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                    />
                    <span className="ml-2 text-sm font-medium text-gray-700">
                      {filters.matchScore}%+
                    </span>
                  </div>
                </div>
              </div>
            </CardBody>
          </Card>

          <div className="space-y-4">
            {filteredApplications.map((application) => (
              <Card 
                key={application.id}
                className={`cursor-pointer border-l-4 transition-all ${
                  selectedCandidate === application.id 
                    ? 'border-l-primary-500 shadow-md' 
                    : 'border-l-transparent hover:border-l-primary-200'
                }`}
                onClick={() => setSelectedCandidate(application.id)}
              >
                <CardBody className="p-4">
                  <div className="flex">
                    <img 
                      src={application.avatar} 
                      alt={application.name}
                      className="w-12 h-12 rounded-full object-cover mr-4"
                    />
                    <div className="flex-1">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-medium text-gray-900">{application.name}</h3>
                          <p className="text-sm text-gray-600">{application.position}</p>
                        </div>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleStarCandidate(application.id);
                          }}
                          className="text-gray-400 hover:text-warning-500 transition-colors"
                        >
                          <Star 
                            className={`h-5 w-5 ${
                              starredCandidates.includes(application.id) 
                                ? 'fill-warning-500 text-warning-500' 
                                : ''
                            }`}
                          />
                        </button>
                      </div>
                      <div className="flex flex-wrap items-center justify-between mt-2">
                        <div>
                          {getStatusBadge(application.status)}
                        </div>
                        <span 
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            application.matchScore >= 90
                              ? 'bg-success-100 text-success-800'
                              : application.matchScore >= 80
                              ? 'bg-primary-100 text-primary-800'
                              : 'bg-gray-100 text-gray-800'
                          }`}
                        >
                          {application.matchScore}% Match
                        </span>
                      </div>
                    </div>
                  </div>
                </CardBody>
              </Card>
            ))}

            {filteredApplications.length === 0 && (
              <Card>
                <CardBody className="p-6 text-center">
                  <p className="text-gray-500">No applications match your current filters.</p>
                  <Button
                    variant="outline"
                    size="sm"
                    className="mt-2"
                    onClick={() => {
                      setFilters({
                        position: 'all',
                        status: 'all',
                        matchScore: 0,
                      });
                      setSearchTerm('');
                    }}
                  >
                    Reset Filters
                  </Button>
                </CardBody>
              </Card>
            )}
          </div>
        </div>

        <div className="lg:col-span-2">
          {selectedCandidate ? (
            <Card>
              <CardBody className="p-6">
                {(() => {
                  const candidate = applications.find(app => app.id === selectedCandidate);
                  if (!candidate) return null;

                  return (
                    <>
                      <div className="flex flex-col md:flex-row md:items-start justify-between mb-6">
                        <div className="flex items-start">
                          <img 
                            src={candidate.avatar} 
                            alt={candidate.name}
                            className="w-16 h-16 rounded-full object-cover mr-4"
                          />
                          <div>
                            <h2 className="text-2xl font-bold text-gray-900">{candidate.name}</h2>
                            <p className="text-lg text-gray-600">{candidate.position}</p>
                            <p className="text-sm text-gray-500">{candidate.email}</p>
                          </div>
                        </div>
                        <div className="flex mt-4 md:mt-0">
                          <Button
                            variant="outline"
                            size="sm"
                            className="mr-2"
                            onClick={() => toggleStarCandidate(candidate.id)}
                          >
                            <Star 
                              className={`h-4 w-4 mr-1 ${
                                starredCandidates.includes(candidate.id) 
                                  ? 'fill-warning-500 text-warning-500' 
                                  : 'text-gray-400'
                              }`} 
                            />
                            {starredCandidates.includes(candidate.id) ? 'Starred' : 'Star'}
                          </Button>
                          <a 
                            href={candidate.resumeUrl} 
                            target="_blank" 
                            rel="noopener noreferrer"
                          >
                            <Button variant="outline" size="sm">
                              <Download className="h-4 w-4 mr-1" />
                              Resume
                            </Button>
                          </a>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                        <div className="bg-primary-50 rounded-lg p-4">
                          <h3 className="font-semibold text-gray-900 mb-2">Match Score: {candidate.matchScore}%</h3>
                          <div className="w-full bg-gray-200 rounded-full h-2.5 mb-4">
                            <div 
                              className="bg-primary-600 h-2.5 rounded-full" 
                              style={{ width: `${candidate.matchScore}%` }}
                            ></div>
                          </div>
                          <p className="text-sm text-gray-600 mb-2">Key Matching Skills:</p>
                          <div className="flex flex-wrap gap-2">
                            {candidateSkills[candidate.id as keyof typeof candidateSkills]
                              .slice(0, 5)
                              .map((skill, index) => (
                                <span 
                                  key={index}
                                  className="px-2 py-1 rounded-full text-xs bg-primary-100 text-primary-700"
                                >
                                  {skill}
                                </span>
                              ))}
                          </div>
                        </div>

                        <div className="bg-gray-50 rounded-lg p-4">
                          <h3 className="font-semibold text-gray-900 mb-2">Application Details</h3>
                          <div className="space-y-2">
                            <div>
                              <p className="text-sm text-gray-500">Applied for</p>
                              <p className="text-sm font-medium text-gray-900">{candidate.position}</p>
                            </div>
                            <div>
                              <p className="text-sm text-gray-500">Application Date</p>
                              <p className="text-sm font-medium text-gray-900">
                                {new Date(candidate.appliedDate).toLocaleDateString()}
                              </p>
                            </div>
                            <div>
                              <p className="text-sm text-gray-500">Current Status</p>
                              <div className="mt-1">
                                {getStatusBadge(candidate.status)}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="mb-6">
                        <h3 className="text-lg font-semibold text-gray-900 mb-3">Skills</h3>
                        <div className="flex flex-wrap gap-2">
                          {candidateSkills[candidate.id as keyof typeof candidateSkills].map((skill, index) => (
                            <span 
                              key={index}
                              className="px-2.5 py-1.5 rounded-md text-sm bg-gray-100 text-gray-800"
                            >
                              {skill}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="mb-6">
                        <h3 className="text-lg font-semibold text-gray-900 mb-3">Experience</h3>
                        <div className="space-y-4">
                          {candidateExperience[candidate.id as keyof typeof candidateExperience].map((exp, index) => (
                            <div key={index} className="border-b border-gray-100 pb-4 last:border-b-0 last:pb-0">
                              <p className="font-medium text-gray-900">{exp.title}</p>
                              <p className="text-gray-700">{exp.company}</p>
                              <p className="text-sm text-gray-500 mb-2">{exp.duration}</p>
                              <p className="text-gray-600 text-sm">{exp.description}</p>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="mb-6">
                        <h3 className="text-lg font-semibold text-gray-900 mb-3">Notes</h3>
                        <textarea
                          className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                          rows={3}
                          placeholder="Add notes about this candidate..."
                        />
                      </div>

                      <div className="mb-6">
                        <h3 className="text-lg font-semibold text-gray-900 mb-3">Update Status</h3>
                        <div className="flex flex-wrap gap-2">
                          {statusOptions.map(option => (
                            <button
                              key={option.value}
                              onClick={() => handleStatusChange(candidate.id, option.value)}
                              className={`px-3 py-1.5 rounded-md text-sm ${
                                candidate.status === option.value
                                  ? option.color + ' font-medium'
                                  : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                              }`}
                            >
                              {option.label}
                            </button>
                          ))}
                        </div>
                      </div>

                      <div className="flex flex-col sm:flex-row gap-3">
                        <Button 
                          variant="primary" 
                          size="lg"
                          className="flex-1 flex items-center justify-center"
                          onClick={() => scheduleInterview(candidate.id)}
                        >
                          <Calendar className="w-4 h-4 mr-2" />
                          Schedule Interview
                        </Button>
                        <Button 
                          variant="outline" 
                          size="lg"
                          className="flex-1 flex items-center justify-center"
                          onClick={() => sendEmail(candidate.id)}
                        >
                          <Mail className="w-4 h-4 mr-2" />
                          Contact Candidate
                        </Button>
                      </div>
                    </>
                  );
                })()}
              </CardBody>
            </Card>
          ) : (
            <Card>
              <CardBody className="p-10 text-center">
                <div className="flex flex-col items-center justify-center">
                  <div className="w-20 h-20 rounded-full bg-primary-100 flex items-center justify-center mb-4">
                    <ChevronRight className="w-10 h-10 text-primary-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    Select a candidate
                  </h3>
                  <p className="text-gray-500 max-w-md">
                    Click on a candidate from the list to view their detailed profile, resume, and manage their application status.
                  </p>
                </div>
              </CardBody>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default Applications;