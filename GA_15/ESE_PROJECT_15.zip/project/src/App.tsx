import { lazy, Suspense } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

// Components
import Navbar from './components/common/Navbar';
import Footer from './components/common/Footer';
import LoadingSpinner from './components/common/LoadingSpinner';

// Context Providers
import { AuthProvider } from './context/AuthContext';
import { ToastProvider } from './context/ToastContext';

// Lazily loaded pages for better performance
const LandingPage = lazy(() => import('./pages/LandingPage'));
const Features = lazy(() => import('./pages/Features'));
const Pricing = lazy(() => import('./pages/Pricing'));
const JobSeekerDashboard = lazy(() => import('./pages/JobSeeker/Dashboard'));
const ResumeUpload = lazy(() => import('./pages/JobSeeker/ResumeUpload'));
const Matches = lazy(() => import('./pages/JobSeeker/Matches'));
const Learning = lazy(() => import('./pages/JobSeeker/Learning'));
const Settings = lazy(() => import('./pages/JobSeeker/Settings'));

const RecruiterDashboard = lazy(() => import('./pages/Recruiter/Dashboard'));
const JobPosting = lazy(() => import('./pages/Recruiter/JobPosting'));
const Applications = lazy(() => import('./pages/Recruiter/Applications'));
const Candidates = lazy(() => import('./pages/Recruiter/Candidates'));
const RecruiterSettings = lazy(() => import('./pages/Recruiter/Settings'));

const Login = lazy(() => import('./pages/Auth/Login'));
const Register = lazy(() => import('./pages/Auth/Register'));
const NotFound = lazy(() => import('./pages/NotFound'));

function App() {
  return (
    <AuthProvider>
      <ToastProvider>
        <Router>
          <div className="flex flex-col min-h-screen bg-gray-50">
            <Navbar />
            <main className="flex-grow">
              <Suspense fallback={<LoadingSpinner />}>
                <Routes>
                  <Route path="/" element={<LandingPage />} />
                  <Route path="/features" element={<Features />} />
                  <Route path="/pricing" element={<Pricing />} />
                  
                  {/* Job Seeker Routes */}
                  <Route path="/job-seeker/dashboard" element={<JobSeekerDashboard />} />
                  <Route path="/job-seeker/resume" element={<ResumeUpload />} />
                  <Route path="/job-seeker/matches" element={<Matches />} />
                  <Route path="/job-seeker/learning" element={<Learning />} />
                  <Route path="/job-seeker/settings" element={<Settings />} />
                  
                  {/* Recruiter Routes */}
                  <Route path="/recruiter/dashboard" element={<RecruiterDashboard />} />
                  <Route path="/recruiter/job-posting" element={<JobPosting />} />
                  <Route path="/recruiter/applications" element={<Applications />} />
                  <Route path="/recruiter/candidates" element={<Candidates />} />
                  <Route path="/recruiter/settings" element={<RecruiterSettings />} />
                  {/* Auth Routes */}
                  <Route path="/login" element={<Login />} />
                  <Route path="/register" element={<Register />} />
                  
                  {/* 404 Route */}
                  <Route path="*" element={<NotFound />} />
                </Routes>
              </Suspense>
            </main>
            <Footer />
          </div>
        </Router>
      </ToastProvider>
    </AuthProvider>
  );
}

export default App;
