import express from 'express';
import cors from 'cors';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import pdfParse from 'pdf-parse';
import natural from 'natural';

const app = express();
const port = 3001;

// Middleware
app.use(cors());
app.use(express.json());

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const uploadDir = path.join(__dirname, 'uploads');
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir);
    }
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname);
  }
});

const upload = multer({ 
  storage: storage,
  fileFilter: function (req, file, cb) {
    const filetypes = /pdf|doc|docx/;
    const mimetype = filetypes.test(file.mimetype);
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    
    if (mimetype && extname) {
      return cb(null, true);
    }
    cb(new Error('Only PDF, DOC, and DOCX files are allowed'));
  }
});

// TF-IDF for text matching
const TfIdf = natural.TfIdf;

// In-memory database for demo
const database = {
  users: [],
  resumes: [],
  jobs: [],
  applications: []
};

// API Routes

// Upload and parse resume
app.post('/api/resumes/upload', upload.single('resume'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const filePath = req.file.path;
    let text = '';

    // For simplicity, we're only handling PDF parsing in this demo
    if (path.extname(filePath).toLowerCase() === '.pdf') {
      const pdfBuffer = fs.readFileSync(filePath);
      const pdfData = await pdfParse(pdfBuffer);
      text = pdfData.text;
    } else {
      // In a real app, we would use different parsers for DOC/DOCX
      text = 'Document content would be extracted here';
    }

    // Extract skills (simplified)
    const skills = extractSkills(text);
    
    // Extract experience (simplified)
    const experience = extractExperience(text);

    const resumeData = {
      id: Date.now().toString(),
      userId: req.body.userId,
      fileName: req.file.originalname,
      filePath: filePath,
      parsedText: text,
      skills: skills,
      experience: experience,
      createdAt: new Date()
    };

    database.resumes.push(resumeData);

    res.status(201).json({
      message: 'Resume uploaded and parsed successfully',
      resumeId: resumeData.id,
      skills: skills,
      experience: experience
    });
  } catch (error) {
    console.error('Error processing resume:', error);
    res.status(500).json({ error: 'Error processing resume' });
  }
});

// Create job posting
app.post('/api/jobs', (req, res) => {
  const jobData = {
    id: Date.now().toString(),
    ...req.body,
    createdAt: new Date()
  };

  database.jobs.push(jobData);

  res.status(201).json({
    message: 'Job posting created successfully',
    jobId: jobData.id
  });
});

// Get job matches for a resume
app.get('/api/matches/resume/:resumeId', (req, res) => {
  const { resumeId } = req.params;
  const resume = database.resumes.find(r => r.id === resumeId);
  
  if (!resume) {
    return res.status(404).json({ error: 'Resume not found' });
  }

  const matches = findJobMatches(resume);
  
  res.json({ matches });
});

// Get resume matches for a job
app.get('/api/matches/job/:jobId', (req, res) => {
  const { jobId } = req.params;
  const job = database.jobs.find(j => j.id === jobId);
  
  if (!job) {
    return res.status(404).json({ error: 'Job not found' });
  }

  const matches = findResumeMatches(job);
  
  res.json({ matches });
});

// Apply for a job
app.post('/api/applications', (req, res) => {
  const { userId, resumeId, jobId } = req.body;
  
  if (!userId || !resumeId || !jobId) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const applicationData = {
    id: Date.now().toString(),
    userId,
    resumeId,
    jobId,
    status: 'pending',
    createdAt: new Date()
  };

  database.applications.push(applicationData);

  res.status(201).json({
    message: 'Application submitted successfully',
    applicationId: applicationData.id
  });
});

// Helper functions

// Simplified skill extraction
function extractSkills(text) {
  // In a real app, this would use NLP to identify skills
  const commonSkills = [
    'javascript', 'react', 'angular', 'vue', 'node', 'express', 'html', 'css',
    'python', 'java', 'c++', 'c#', 'php', 'ruby', 'swift', 'kotlin',
    'sql', 'nosql', 'mongodb', 'postgresql', 'mysql', 'oracle',
    'aws', 'azure', 'gcp', 'docker', 'kubernetes', 'terraform',
    'machine learning', 'ai', 'data science', 'big data', 'analytics',
    'project management', 'agile', 'scrum', 'leadership', 'communication'
  ];
  
  const foundSkills = [];
  const lowerText = text.toLowerCase();
  
  commonSkills.forEach(skill => {
    if (lowerText.includes(skill)) {
      foundSkills.push(skill);
    }
  });
  
  return foundSkills;
}

// Simplified experience extraction
function extractExperience(text) {
  // In a real app, this would use more sophisticated NLP
  // For demo, we'll just look for common patterns
  
  const lines = text.split('\n');
  const experience = [];
  
  let currentExp = null;
  
  for (const line of lines) {
    const trimmedLine = line.trim();
    
    // Look for job titles (simplified)
    if (/engineer|developer|manager|director|analyst|designer|architect/i.test(trimmedLine) && 
        !/education|university|college|school/i.test(trimmedLine)) {
      
      if (currentExp) {
        experience.push(currentExp);
      }
      
      currentExp = {
        title: trimmedLine,
        company: '',
        duration: '',
        description: []
      };
    } 
    // Look for dates (simplified)
    else if (/\d{4}\s*-\s*(\d{4}|present)/i.test(trimmedLine)) {
      if (currentExp) {
        currentExp.duration = trimmedLine;
      }
    }
    // Add to description
    else if (currentExp && trimmedLine.length > 20) {
      currentExp.description.push(trimmedLine);
    }
  }
  
  if (currentExp) {
    experience.push(currentExp);
  }
  
  return experience;
}

// Find job matches for a resume
function findJobMatches(resume) {
  const tfidf = new TfIdf();
  
  // Add resume text
  tfidf.addDocument(resume.parsedText);
  
  // Add job descriptions
  database.jobs.forEach(job => {
    tfidf.addDocument(job.description);
  });
  
  // Calculate matches
  const matches = database.jobs.map(job => {
    // Calculate similarity
    let score = 0;
    
    // Skills match
    const skillsMatch = resume.skills.filter(skill => 
      job.skills && job.skills.includes(skill)
    ).length;
    
    // Text similarity (simplified)
    resume.skills.forEach(skill => {
      if (job.description.toLowerCase().includes(skill.toLowerCase())) {
        score += 5;
      }
    });
    
    // Normalize score to 0-100
    score = Math.min(Math.max(50 + skillsMatch * 5 + score, 0), 100);
    
    return {
      job,
      score,
      skillsMatch: skillsMatch
    };
  });
  
  // Sort by score (descending)
  return matches.sort((a, b) => b.score - a.score);
}

// Find resume matches for a job
function findResumeMatches(job) {
  const tfidf = new TfIdf();
  
  // Add job description
  tfidf.addDocument(job.description);
  
  // Calculate matches
  const matches = database.resumes.map(resume => {
    // Calculate similarity
    let score = 0;
    
    // Skills match
    const skillsMatch = job.skills.filter(skill => 
      resume.skills.includes(skill)
    ).length;
    
    // Text similarity (simplified)
    job.skills.forEach(skill => {
      if (resume.parsedText.toLowerCase().includes(skill.toLowerCase())) {
        score += 5;
      }
    });
    
    // Normalize score to 0-100
    score = Math.min(Math.max(50 + skillsMatch * 5 + score, 0), 100);
    
    return {
      resume,
      score,
      skillsMatch: skillsMatch
    };
  });
  
  // Sort by score (descending)
  return matches.sort((a, b) => b.score - a.score);
}

// Start server
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});