    import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TicTacToeAI extends JFrame implements ActionListener {
    private JButton[][] buttons = new JButton[3][3];
    private char[][] board = { {' ', ' ', ' '}, {' ', ' ', ' '}, {' ', ' ', ' '} };
    private boolean playerTurn = false; // AI plays first

    public TicTacToeAI() {
        setTitle("Tic-Tac-Toe (AI vs User)");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(3, 3));

        // Initialize buttons
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                buttons[i][j] = new JButton("");
                buttons[i][j].setFont(new Font("Arial", Font.BOLD, 60));
                buttons[i][j].setFocusPainted(false);
                buttons[i][j].addActionListener(this);
                add(buttons[i][j]);
            }
        }

        setVisible(true);
        aiMove(); // AI makes the first move automatically
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (!playerTurn) return; // Ignore clicks when AI is playing

        JButton clickedButton = (JButton) e.getSource();
        int row = -1, col = -1;

        // Find which button was clicked
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (buttons[i][j] == clickedButton) {
                    row = i;
                    col = j;
                }
            }
        }

        if (row != -1 && col != -1 && board[row][col] == ' ') {
            makeMove(row, col, 'X');
            playerTurn = false;

            if (!checkWin('X') && !isBoardFull()) {
                aiMove();
            }
        }
    }

    private void makeMove(int row, int col, char player) {
        board[row][col] = player;
        buttons[row][col].setText(String.valueOf(player));

        if (checkWin(player)) {
            JOptionPane.showMessageDialog(this, (player == 'X' ? "You Win!" : "AI Wins!"));
            resetGame();
        } else if (isBoardFull()) {
            JOptionPane.showMessageDialog(this, "It's a Draw!");
            resetGame();
        }
    }

    private boolean checkWin(char player) {
        for (int i = 0; i < 3; i++) {
            if (board[i][0] == player && board[i][1] == player && board[i][2] == player) return true;
            if (board[0][i] == player && board[1][i] == player && board[2][i] == player) return true;
        }
        return (board[0][0] == player && board[1][1] == player && board[2][2] == player) ||
               (board[0][2] == player && board[1][1] == player && board[2][0] == player);
    }

    private boolean isBoardFull() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (board[i][j] == ' ') return false;
            }
        }
        return true;
    }

    private void aiMove() {
        int[] bestMove = minimax(board, 'O');
        makeMove(bestMove[0], bestMove[1], 'O');
        playerTurn = true;
    }

    private int[] minimax(char[][] board, char player) {
        int bestScore = (player == 'O') ? Integer.MIN_VALUE : Integer.MAX_VALUE;
        int[] bestMove = {-1, -1};

        if (checkWin('X')) return new int[] {-1, -1, -10}; // Player wins
        if (checkWin('O')) return new int[] {-1, -1, 10};  // AI wins
        if (isBoardFull()) return new int[] {-1, -1, 0};   // Draw

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (board[i][j] == ' ') {
                    board[i][j] = player;
                    int score = minimax(board, (player == 'O') ? 'X' : 'O')[2];
                    board[i][j] = ' ';

                    if (player == 'O') { // AI's turn (Maximize score)
                        if (score > bestScore) {
                            bestScore = score;
                            bestMove = new int[]{i, j, bestScore};
                        }
                    } else { // Player's turn (Minimize AI's score)
                        if (score < bestScore) {
                            bestScore = score;
                            bestMove = new int[]{i, j, bestScore};
                        }
                    }
                }
            }
        }
        return bestMove;
    }

    private void resetGame() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                board[i][j] = ' ';
                buttons[i][j].setText("");
            }
        }
        playerTurn = false;
        aiMove(); // AI starts first again
    }

    public static void main(String[] args) {
        new TicTacToeAI();
    }
}
