import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Random;

class CarRacingGame extends JPanel implements ActionListener, KeyListener {

    private int playerX = 150, playerY = 500;
    private int laneWidth = 100;
    private int roadY = 0;
    private int speed = 5;
    private int score = 0, lastScore = 0;
    private boolean gameOver = false, gameStarted = false;
    private String difficulty = "Medium";
    private ArrayList<Rectangle> opponentCars;
    private Timer timer;
    private Image playerCar, opponentCar1, opponentCar2, opponentCar3, startScreenBackground;
    private JFrame frame;
    private Random random = new Random();

    public CarRacingGame(JFrame frame) {
        this.frame = frame;
        setPreferredSize(new Dimension(400, 600));
        setBackground(Color.GRAY);
        opponentCars = new ArrayList<>();
        timer = new Timer(50, this);
        setFocusable(true);
        loadImages();
        showStartScreen();
    }

    private void loadImages() {
        playerCar = new ImageIcon("player_car.png").getImage();
        opponentCar1 = new ImageIcon("opponent_car1.png").getImage();
        opponentCar2 = new ImageIcon("opponent_car3.png").getImage();
        opponentCar3 = new ImageIcon("opponent_car3.png").getImage();
        startScreenBackground = new ImageIcon("start_screen.jpg").getImage();
    }

    private void showStartScreen() {
        JPanel panel = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(startScreenBackground, 0, 0, getWidth(), getHeight(), this);
            }
        };
        panel.setLayout(new BorderLayout());
        JButton startButton = new JButton("Start Game");
        startButton.setFont(new Font("Arial", Font.BOLD, 20));
        startButton.setPreferredSize(new Dimension(200, 50));
        startButton.addActionListener(e -> {
            frame.getContentPane().removeAll();
            frame.add(this);
            frame.revalidate();
            frame.repaint();
            showDifficultySelection();
        });
        panel.add(startButton, BorderLayout.CENTER);
        frame.setContentPane(panel);
        frame.revalidate();
        frame.repaint();
    }

    private void showDifficultySelection() {
        String[] options = {"Easy", "Medium", "Hard"};
        int choice = JOptionPane.showOptionDialog(this, "Select Difficulty:", "Game Level",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[1]);
        if (choice == 0) speed = 3;
        else if (choice == 1) speed = 5;
        else speed = 7;
        gameStarted = true;
        timer.start();
        addKeyListener(this);
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (!gameStarted) return;
        drawRoad(g);
        drawCar(g);
        drawOpponentCars(g);
        drawScore(g);
        if (gameOver) drawGameOver(g);
    }

    private void drawRoad(Graphics g) {
        g.setColor(Color.BLACK);
        g.fillRect(50, roadY, 300, 600);
        g.setColor(Color.WHITE);
        for (int i = 0; i < 600; i += 40) {
            g.fillRect(150, i, 5, 20);
            g.fillRect(250, i, 5, 20);
        }
    }

    private void drawCar(Graphics g) {
        g.drawImage(playerCar, playerX, playerY, 40, 60, this);
    }

    private void drawOpponentCars(Graphics g) {
        for (int i = 0; i < opponentCars.size(); i++) {
            Rectangle car = opponentCars.get(i);
            Image carImage = (i % 3 == 0) ? opponentCar1 : (i % 3 == 1) ? opponentCar2 : opponentCar3;
            g.drawImage(carImage, car.x, car.y, 40, 60, this);
        }
    }

    private void drawScore(Graphics g) {
        g.setColor(Color.WHITE);
        g.drawString("Score: " + score, 10, 20);
        g.drawString("Last Score: " + lastScore, 10, 40);
        g.drawString("Difficulty: " + difficulty, 10, 60);
    }

    private void drawGameOver(Graphics g) {
        g.setColor(Color.RED);
        g.setFont(new Font("Arial", Font.BOLD, 30));
        g.drawString("Game Over", 120, 300);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (!gameOver) {
            moveOpponentCars();
            checkCollision();
            score++;
        }
        repaint();
    }

    private void moveOpponentCars() {
        for (Rectangle car : opponentCars) {
            car.y += speed;
        }
        if (random.nextInt(100) < 3) {
            opponentCars.add(new Rectangle(50 + random.nextInt(3) * 100, 0, 40, 60));
        }
    }

    private void checkCollision() {
        for (Rectangle car : opponentCars) {
            if (car.intersects(new Rectangle(playerX, playerY, 40, 60))) {
                gameOver = true;
                lastScore = score;
                score = 0;
                timer.stop();
                showGameOverDialog();
            }
        }
    }

    private void showGameOverDialog() {
        int choice = JOptionPane.showConfirmDialog(this, "Game Over! Restart?", "Game Over", JOptionPane.YES_NO_OPTION);
        if (choice == JOptionPane.YES_OPTION) {
            restartGame();
        } else {
            System.exit(0);
        }
    }

    private void restartGame() {
        gameOver = false;
        playerX = 150;
        opponentCars.clear();
        score = 0;
        showDifficultySelection();
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_LEFT && playerX > 50) {
            playerX -= laneWidth;
        } else if (e.getKeyCode() == KeyEvent.VK_RIGHT && playerX < 250) {
            playerX += laneWidth;
        }
    }
    @Override public void keyReleased(KeyEvent e) {}
    @Override public void keyTyped(KeyEvent e) {}

    public static void main(String[] args) {
        JFrame frame = new JFrame("Car Racing Game");
        frame.setSize(400, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        new CarRacingGame(frame);
        frame.setVisible(true);
    }
}
