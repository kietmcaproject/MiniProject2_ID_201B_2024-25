import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Random;

public class ImproveGame extends JPanel implements ActionListener, KeyListener {

    // Player car attributes
    private int playerX = 150, playerY = 500;
    private final int laneWidth = 100;
    private int speed = 5;
    private int score = 0, lastScore = 0;
    private boolean gameOver = false, gameStarted = false;
    private ArrayList<Rectangle> opponentCars;
    private Timer timer;
    private Image playerCar, opponentCar1, opponentCar2, opponentCar3, startScreenBackground;
    private JFrame frame;
    private Random random = new Random();
    private int roadOffset = 0; // For moving road lanes
    private int carSpeedIncreaseThreshold = 100;  // Points to increase speed
    private final int COLLISION_BUFFER = 10; // Buffer for collision detection

    public ImproveGame(JFrame frame) {
        this.frame = frame;
        setPreferredSize(new Dimension(400, 600));
        setBackground(Color.GRAY);
        opponentCars = new ArrayList<>();
        timer = new Timer(30, this); // Game speed
        setFocusable(true);
        loadImages();
        addKeyListener(this);
    }

    private void loadImages() {
        playerCar = new ImageIcon("player_car.png").getImage();
        opponentCar1 = new ImageIcon("opponent_car1.png").getImage();
        opponentCar2 = new ImageIcon("opponent_car2.png").getImage();
        opponentCar3 = new ImageIcon("opponent_car3.png").getImage();
        startScreenBackground = new ImageIcon("start_screen.jpg").getImage();
    }

    private void showStartScreen() {
        JPanel panel = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(startScreenBackground, 0, 0, getWidth(), getHeight(), this);
            }
        };
        panel.setLayout(null);

        JButton startButton = new JButton("Start Game");
        startButton.setFont(new Font("Arial", Font.BOLD, 20));
        startButton.setBounds(100, 400, 200, 50);
        startButton.setBackground(Color.RED);
        startButton.setForeground(Color.WHITE);
        startButton.addActionListener(e -> {
            frame.getContentPane().removeAll();
            frame.add(this);
            frame.revalidate();
            frame.repaint();
            startGame();
        });

        panel.add(startButton);
        frame.setContentPane(panel);
        frame.revalidate();
        frame.repaint();
    }

    private void startGame() {
        gameStarted = true;
        score = 0;
        playerX = 150;
        playerY = 500;
        opponentCars.clear();
        roadOffset = 0;
        timer.start();
        frame.repaint();
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (!gameStarted) return;

        drawRoad(g);
        drawCar(g);
        drawOpponentCars(g);
        drawScore(g);

        if (gameOver) drawGameOver(g);
    }

    private void drawRoad(Graphics g) {
        g.setColor(Color.BLACK);
        g.fillRect(50, 0, 300, getHeight());

        g.setColor(Color.WHITE);
        for (int i = 0; i < getHeight() + roadOffset; i += 40) {
            int lineY = i - roadOffset;
            if (lineY >= 0 && lineY <= getHeight()) {
                g.fillRect(150, lineY, 5, 20);
                g.fillRect(250, lineY, 5, 20);
            }
        }
    }

    private void drawCar(Graphics g) {
        g.drawImage(playerCar, playerX, playerY, 40, 60, this);
    }

    private void drawOpponentCars(Graphics g) {
        for (Rectangle car : opponentCars) {
            Image carImage = (opponentCars.indexOf(car) % 3 == 0) ? opponentCar1 :
                    (opponentCars.indexOf(car) % 3 == 1) ? opponentCar2 : opponentCar3;
            g.drawImage(carImage, car.x, car.y, 40, 60, this);
        }
    }

 private void drawScore(Graphics g) {
        g.setColor(Color.WHITE);
        g.drawString("Score: " + score, 10, 20);
        g.drawString("Last Score: " + lastScore, 10, 40);
    }

    private void drawGameOver(Graphics g) {
        g.setColor(Color.RED);
        g.setFont(new Font("Arial", Font.BOLD, 30));
        g.drawString("Game Over", 120, 300);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (!gameOver) {
            moveOpponentCars();
            moveRoad();
            checkCollision();
            updateGameDifficulty();
            score++;
        }
        repaint();
    }

    private void moveRoad() {
        roadOffset += speed;
        if (roadOffset >= getHeight()) {
            roadOffset = 0;
        }
    }

    private void moveOpponentCars() {
        for (Rectangle car : opponentCars) {
            car.y += speed;
        }
        if (random.nextInt(100) < 5) {
            opponentCars.add(new Rectangle(50 + random.nextInt(3) * 100, 0, 40, 60));
        }
    }

    private void checkCollision() {
        for (Rectangle car : opponentCars) {
            Rectangle playerRect = new Rectangle(playerX, playerY, 40, 60);
            if (playerRect.intersects(car.getBounds().getBounds())) {
                if (Math.abs(playerX - car.x) < COLLISION_BUFFER) {
                    gameOver = true;
                    lastScore = score;
                    score = 0;
                    timer.stop();
                    showGameOverDialog();
                }
            }
        }
    }

    private void showGameOverDialog() {
        int choice = JOptionPane.showConfirmDialog(this, "Game Over! Restart?", "Game Over", JOptionPane.YES_NO_OPTION);
        if (choice == JOptionPane.YES_OPTION) {
            startGame();
        } else {
            System.exit(0);
        }
    }

    private void updateGameDifficulty() {
        if (score % carSpeedIncreaseThreshold == 0 && score > 0) {
            speed++;
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_LEFT && playerX > 50) {
            playerX -= laneWidth;
        } else if (e.getKeyCode() == KeyEvent.VK_RIGHT && playerX < 250) {
            playerX += laneWidth;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {}
    @Override
    public void keyTyped(KeyEvent e) {}

    public static void main(String[] args) {
        JFrame frame = new JFrame("Car Racing Game");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 600);
        ImproveGame game = new ImproveGame(frame);
        frame.setContentPane(game);
        frame.setVisible(true);
        game.showStartScreen();
    }
}