export const BACKEND_SERVER_URL="https://donalddesk.duckdns.org:8443";


// https://retail-edge-be-latest.onrender.com/

// const API='https://backend-health-bestie.vercel.app/users/conversations';

// use this card number : 5267 3181 8797 5449	 

  