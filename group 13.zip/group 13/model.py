import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.metrics import classification_report


train_df = pd.read_csv('climate_train.csv')
dev_df = pd.read_csv('climate_dev.csv')
test_df = pd.read_csv('climate_test.csv')

full_train_df = pd.concat([train_df, dev_df], ignore_index=True)

print(full_train_df.columns)

full_train_df.dropna(subset=['source_article', 'logical_fallacies'], inplace=True)
test_df.dropna(subset=['source_article', 'logical_fallacies'], inplace=True)


def map_to_binary(label):
    fake_labels = [
        "ad hominem", "ad populum", "appeal to emotion", "circular reasoning",
        "equivocation", "fallacy of credibility", "fallacy of extension",
        "fallacy of logic", "fallacy of relevance", "false causality",
        "false dilemma", "faulty generalization"
    ]
    return "fake" if label in fake_labels else "real"

full_train_df['label'] = full_train_df['logical_fallacies'].apply(map_to_binary)
test_df['label'] = test_df['logical_fallacies'].apply(map_to_binary)

print("Train label distribution:")
print(full_train_df['label'].value_counts())

vectorizer = TfidfVectorizer(max_features=5000, stop_words='english')
X_train = vectorizer.fit_transform(full_train_df['source_article'])
X_test = vectorizer.transform(test_df['source_article'])


y_train = full_train_df['label']
y_test = test_df['label']


clf = LogisticRegression(max_iter=1000, class_weight='balanced')
clf.fit(X_train, y_train)


y_pred = clf.predict(X_test)
print("🔍 Classification Report:")
print(classification_report(y_test, y_pred))

cm = confusion_matrix(y_test, y_pred, labels=clf.classes_)
sns.heatmap(cm, annot=True, fmt="d", xticklabels=clf.classes_, yticklabels=clf.classes_)
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Confusion Matrix")
plt.show()
import joblib
joblib.dump(clf, 'model.pkl')
joblib.dump(vectorizer, 'vectorizer.pkl')