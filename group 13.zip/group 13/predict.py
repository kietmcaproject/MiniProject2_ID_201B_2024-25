import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from model import vectorizer, clf  
import joblib

clf = joblib.load('model.pkl')
vectorizer = joblib.load('vectorizer.pkl')
def predict_news_category(text):
    print(f"Received text: {text}")
    text_vector = vectorizer.transform([text])
    prediction = clf.predict(text_vector)
    return prediction[0]

if __name__ == "__main__":
    news_text = input("Enter the news article text to classify as 'fake' or 'real':\n")
    prediction = predict_news_category(news_text)
    print(f"\n🔍 Prediction for input: \"{news_text}\"")
    print(f"🗂️ Predicted Logical Fallacy: {prediction}")

  #Mumbai weather News: City Wakes Up To Pleasant Climate; Humidity Levels Take A Slight Drop
 # Scientists Confirm That Rainwater Can Now Charge Smartphones!