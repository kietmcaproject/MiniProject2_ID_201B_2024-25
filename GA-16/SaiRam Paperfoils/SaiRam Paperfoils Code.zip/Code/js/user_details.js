import { getFirestore, doc, getDoc } from "https://www.gstatic.com/firebasejs/11.3.1/firebase-firestore.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/11.3.1/firebase-auth.js";
import { firebaseInit } from "./firebase_initalization.js";

firebaseInit();
const db = getFirestore();
const auth = getAuth();
// import { getStorage, ref, getDownloadURL } from "https://www.gstatic.com/firebasejs/11.3.1/firebase-storage.js";

onAuthStateChanged(auth, async (user) => {
  const userNameElement = document.getElementById("userName");
  const userDetailsLeftElement = document.getElementById("userDetailsLeft");
  const userDetailsRightElement = document.getElementById("userDetailsRight");
  const userIconElement = document.getElementById("userIcon");

  if (user) {
    try {
      const userRef = doc(db, 'users', user.uid);
      const docSnap = await getDoc(userRef);

      if (docSnap.exists()) {
        const userData = docSnap.data();
        
        // Update user name
        userNameElement.textContent ="Welcome "+ userData.name || "Name not available";

        // Dynamically update user details in left and right sections
        userDetailsLeftElement.innerHTML = `
          <li><i class="fa-solid fa-location-dot"></i> ${userData.address || "Address not available"}</li>
          <li><i class="fa-solid fa-phone"></i> ${userData.phone || "Phone not available"}</li>
          `;
          // <li><i class="fa-solid fa-wallet"></i> ${userData.country || "Country not available"}</li>

        userDetailsRightElement.innerHTML = `
        <li><i class="fa-solid fa-globe"></i> ${userData.Country || "Country not available"}</li>
          <li><i class="fa-solid fa-envelope"></i> ${userData.email || "Email not available"}</li>
          `;
          // <li><i class="fa-solid fa-briefcase"></i> ${userData.job || "Job not available"}</li>

        // Set user icon (use a default icon if no image is available)
        // userIconElement.src = userData.profileIcon || "/Photos/userIcon.png";
      } else {
        console.log("User document not found!");
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  } else {
    console.log("No user is signed in.");
    userNameElement.textContent = "Please log in to view your profile.";
    userDetailsLeftElement.innerHTML = "<li><i class='fa-solid fa-location-dot'></i> Please log in</li>";
    userDetailsRightElement.innerHTML = "<li><i class='fa-solid fa-envelope'></i> Please log in</li>";
    userIconElement.src = "/images/default-user-icon.png"; // Fallback to default icon
    setTimeout(() => {
      window.location.href = "/html/login.html";
    }, 3000);
  }
});
