
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.3.1/firebase-app.js";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCuPxJdvfJTAkzYIy9iKeBh4y2zKyKHDKE",
  authDomain: "sairam-paperfoils.firebaseapp.com",
  projectId: "sairam-paperfoils",
  storageBucket: "sairam-paperfoils.firebasestorage.app",
  messagingSenderId: "239577114691",
  appId: "1:239577114691:web:7deea7ecbbffdad784ccf6",
  measurementId: "G-RB7WTJ69VL"
};

// Initialize Firebase
export function firebaseInit(){
    
const app = initializeApp(firebaseConfig);

}