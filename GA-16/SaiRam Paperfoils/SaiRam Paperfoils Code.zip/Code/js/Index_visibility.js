import { getAuth, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/11.3.1/firebase-auth.js";
import { firebaseInit } from "./firebase_initalization.js";

firebaseInit();
const auth = getAuth();

const specialUserId = "NpmiYqY8h6drQoRtjicKGW93RpL2"; // Special user ID for Mentorship access

function updateNavbar(user) {
    const navItems = {
        mentorship: document.querySelector(".nav-mentorship"),
        signup: document.querySelector(".nav-signup"),
        login: document.querySelector(".nav-login"),
        updateProfile: document.querySelector(".nav-update-profile"),
        userDetails: document.querySelector(".nav-user-details"),
        logout: document.querySelector(".nav-logout"),
        profileSection: document.getElementById("profileSection"),
    };

    if (user) {
        // User is logged in
        navItems.signup.style.display = "none";
        navItems.login.style.display = "none";
        navItems.updateProfile.style.display = "inline-block";
        navItems.userDetails.style.display = "inline-block";
        navItems.logout.style.display = "inline-block";
        navItems.profileSection.style.display = "flex";

        // Show mentorship only for special user
        navItems.mentorship.style.display = user.uid === specialUserId ? "inline-block" : "none";

    } else {
        // User is logged out
        navItems.signup.style.display = "inline-block";
        navItems.login.style.display = "inline-block";
        navItems.updateProfile.style.display = "none";
        navItems.userDetails.style.display = "none";
        navItems.logout.style.display = "none";
        navItems.profileSection.style.display = "none";
        navItems.mentorship.style.display = "none";
    }
}

// Listen for auth state changes
onAuthStateChanged(auth, (user) => {
    updateNavbar(user);
});

// Logout function
document.querySelector(".nav-logout").addEventListener("click", async (e) => {
    e.preventDefault();
    try {
        await signOut(auth);
        window.location.href = "index.html"; // Redirect to home after logout
    } catch (error) {
        console.error("Logout Error:", error);
    }
});
