import {
  require_react
} from "./chunk-32E4H3EV.js";
import "./chunk-G3PMV62Z.js";
export default require_react();
//# sourceMappingURL=react.js.map
