import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.swing.*;

public class MatchCards {
    class Card {
        String cardName;
        ImageIcon cardImageIcon;

        Card(String cardName, ImageIcon cardImageIcon) {
            this.cardName = cardName;
            this.cardImageIcon = cardImageIcon;
        }

        public String toString() {
            return cardName;
        }
    }

    String[] cardList = {
        "darkness", "double", "fairy", "fighting", "fire",
        "grass", "lightning", "metal", "psychic", "water"
    };

    int rows = 4;
    int columns = 5;
    int cardWidth = 90;
    int cardHeight = 128;

    ArrayList<Card> cardSet;
    ImageIcon cardBackImageIcon;

    int boardWidth = columns * cardWidth;
    int boardHeight = rows * cardHeight;

    JFrame frame = new JFrame("Pokemon Match Cards");
    JLabel textLabel = new JLabel();
    JPanel textPanel = new JPanel();
    JPanel boardPanel = new JPanel();
    JPanel controlPanel = new JPanel();

    JButton startButton = new JButton();
    JButton restartButton = new JButton();
    JButton endButton = new JButton();

    JComboBox<String> languageSelector;

    int errorCount = 0;
    ArrayList<JButton> board;
    Timer hideCardTimer;
    boolean gameReady = false;
    JButton card1Selected;
    JButton card2Selected;

    // Language maps
    Map<String, String> englishTexts = new HashMap<>();
    Map<String, String> spanishTexts = new HashMap<>();
    Map<String, String> currentTexts;

    MatchCards() {
        setupLanguageMaps();

        setupCards();
        shuffleCards();

        frame.setLayout(new BorderLayout());
        frame.setSize(boardWidth, boardHeight + 90); // Extra space for control panel
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        textLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        textLabel.setHorizontalAlignment(JLabel.CENTER);
        textLabel.setText(currentTexts.get("clickStart"));

        textPanel.setPreferredSize(new Dimension(boardWidth, 30));
        textPanel.add(textLabel);
        frame.add(textPanel, BorderLayout.NORTH);

        board = new ArrayList<>();
        boardPanel.setLayout(new GridLayout(rows, columns));
        for (int i = 0; i < cardSet.size(); i++) {
            JButton tile = new JButton();
            tile.setPreferredSize(new Dimension(cardWidth, cardHeight));
            tile.setOpaque(true);
            tile.setIcon(cardBackImageIcon);
            tile.setFocusable(false);
            tile.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (!gameReady) return;

                    JButton tile = (JButton) e.getSource();
                    if (tile.getIcon() == cardBackImageIcon) {
                        if (card1Selected == null) {
                            card1Selected = tile;
                            int index = board.indexOf(card1Selected);
                            card1Selected.setIcon(cardSet.get(index).cardImageIcon);
                        } else if (card2Selected == null) {
                            card2Selected = tile;
                            int index = board.indexOf(card2Selected);
                            card2Selected.setIcon(cardSet.get(index).cardImageIcon);

                            if (!cardSet.get(board.indexOf(card1Selected)).cardName.equals(
                                    cardSet.get(board.indexOf(card2Selected)).cardName)) {
                                errorCount++;
                                textLabel.setText(currentTexts.get("errors") + errorCount);
                                hideCardTimer.start();
                            } else {
                                card1Selected = null;
                                card2Selected = null;

                                if (checkWin()) {
                                    gameReady = false;
                                    JOptionPane.showMessageDialog(frame,
                                            String.format(currentTexts.get("victory"), errorCount),
                                            "Victory",
                                            JOptionPane.INFORMATION_MESSAGE);
                                    textLabel.setText(currentTexts.get("ended"));
                                    restartButton.setEnabled(false);
                                    startButton.setEnabled(true);
                                    endButton.setEnabled(false);
                                }
                            }
                        }
                    }
                }
            });
            board.add(tile);
            boardPanel.add(tile);
        }
        frame.add(boardPanel, BorderLayout.CENTER);

        // Control panel setup for buttons + language selector
        controlPanel.setLayout(new FlowLayout());

        startButton.setFont(new Font("Arial", Font.PLAIN, 16));
        startButton.setFocusable(false);
        startButton.addActionListener(e -> startGame());

        restartButton.setFont(new Font("Arial", Font.PLAIN, 16));
        restartButton.setFocusable(false);
        restartButton.setEnabled(false);
        restartButton.addActionListener(e -> restartGame());

        endButton.setFont(new Font("Arial", Font.PLAIN, 16));
        endButton.setFocusable(false);
        endButton.setEnabled(false);
        endButton.addActionListener(e -> endGame());

        languageSelector = new JComboBox<>(new String[]{"English", "Spanish"});
        languageSelector.setFocusable(false);
        languageSelector.addActionListener(e -> {
            String selected = (String) languageSelector.getSelectedItem();
            if ("English".equals(selected)) {
                currentTexts = englishTexts;
            } else if ("Spanish".equals(selected)) {
                currentTexts = spanishTexts;
            }
            updateUIText();
        });

        controlPanel.add(startButton);
        controlPanel.add(restartButton);
        controlPanel.add(endButton);
        controlPanel.add(languageSelector);

        frame.add(controlPanel, BorderLayout.SOUTH);

        frame.pack();
        frame.setVisible(true);

        hideCardTimer = new Timer(1500, e -> hideCards());
        hideCardTimer.setRepeats(false);

        updateUIText();
    }

    void setupLanguageMaps() {
        englishTexts.put("start", "Start Game");
        englishTexts.put("restart", "Restart Game");
        englishTexts.put("end", "End Game");
        englishTexts.put("errors", "Errors: ");
        englishTexts.put("memorize", "Memorize the cards!");
        englishTexts.put("ended", "Game Ended. Click 'Start Game' to play again.");
        englishTexts.put("victory", "You matched all cards with %d errors!");
        englishTexts.put("clickStart", "Click 'Start Game' to begin");

        spanishTexts.put("start", "Iniciar Juego");
        spanishTexts.put("restart", "Reiniciar Juego");
        spanishTexts.put("end", "Terminar Juego");
        spanishTexts.put("errors", "Errores: ");
        spanishTexts.put("memorize", "¡Memoriza las cartas!");
        spanishTexts.put("ended", "Juego terminado. Haz clic en 'Iniciar Juego' para jugar de nuevo.");
        spanishTexts.put("victory", "¡Has emparejado todas las cartas con %d errores!");
        spanishTexts.put("clickStart", "Haz clic en 'Iniciar Juego' para comenzar");

        currentTexts = englishTexts;
    }

    void updateUIText() {
        startButton.setText(currentTexts.get("start"));
        restartButton.setText(currentTexts.get("restart"));
        endButton.setText(currentTexts.get("end"));

        if (!gameReady) {
            textLabel.setText(currentTexts.get("clickStart"));
        } else {
            textLabel.setText(currentTexts.get("errors") + errorCount);
        }
    }

    void setupCards() {
        cardSet = new ArrayList<>();
        for (String cardName : cardList) {
            Image cardImg = new ImageIcon(cardName + ".jpg").getImage();
            ImageIcon cardImageIcon = new ImageIcon(cardImg.getScaledInstance(cardWidth, cardHeight, Image.SCALE_SMOOTH));
            Card card = new Card(cardName, cardImageIcon);
            cardSet.add(card);
        }
        cardSet.addAll(new ArrayList<>(cardSet)); // duplicate cards

        Image cardBackImg = new ImageIcon("back.jpg").getImage();
        cardBackImageIcon = new ImageIcon(cardBackImg.getScaledInstance(cardWidth, cardHeight, Image.SCALE_SMOOTH));
    }

    void shuffleCards() {
        for (int i = 0; i < cardSet.size(); i++) {
            int j = (int) (Math.random() * cardSet.size());
            Card temp = cardSet.get(i);
            cardSet.set(i, cardSet.get(j));
            cardSet.set(j, temp);
        }
    }

    void hideCards() {
        if (gameReady && card1Selected != null && card2Selected != null) {
            card1Selected.setIcon(cardBackImageIcon);
            card2Selected.setIcon(cardBackImageIcon);
            card1Selected = null;
            card2Selected = null;
        } else {
            for (JButton button : board) {
                button.setIcon(cardBackImageIcon);
            }
            gameReady = true;
            restartButton.setEnabled(true);
            endButton.setEnabled(true);
            startButton.setEnabled(false);
            updateUIText();
        }
    }

    void startGame() {
        errorCount = 0;
        shuffleCards();
        for (int i = 0; i < board.size(); i++) {
            board.get(i).setIcon(cardSet.get(i).cardImageIcon);
        }
        gameReady = false;
        card1Selected = null;
        card2Selected = null;
        restartButton.setEnabled(false);
        endButton.setEnabled(true);
        startButton.setEnabled(false);
        textLabel.setText(currentTexts.get("memorize"));
        hideCardTimer.restart();
    }

    void restartGame() {
        errorCount = 0;
        shuffleCards();
        for (int i = 0; i < board.size(); i++) {
            board.get(i).setIcon(cardSet.get(i).cardImageIcon);
        }
        gameReady = false;
        card1Selected = null;
        card2Selected = null;
        restartButton.setEnabled(false);
        endButton.setEnabled(true);
        startButton.setEnabled(false);
        textLabel.setText(currentTexts.get("memorize"));
        hideCardTimer.restart();
    }

    void endGame() {
        gameReady = false;
        for (JButton button : board) {
            button.setIcon(cardBackImageIcon);
        }
        textLabel.setText(currentTexts.get("ended"));
        restartButton.setEnabled(false);
        endButton.setEnabled(false);
        startButton.setEnabled(true);
    }

    boolean checkWin() {
        for (int i = 0; i < board.size(); i++) {
            if (board.get(i).getIcon() == cardBackImageIcon) {
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new MatchCards();
        });
    }
}
