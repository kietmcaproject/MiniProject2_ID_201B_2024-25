
/// <reference types="vite/client" />

interface Window {
  ImageCapture?: {
    prototype: ImageCapture;
    new(track: MediaStreamTrack): ImageCapture;
  };
}

interface ImageCapture {
  grabFrame(): Promise<ImageBitmap>;
  takePhoto(): Promise<Blob>;
}

