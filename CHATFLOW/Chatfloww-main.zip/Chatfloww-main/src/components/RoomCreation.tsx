
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useNavigate } from 'react-router-dom';
import { MessageCircle, User, Plus, LogIn } from 'lucide-react';

interface RoomCreationProps {
  onCreateRoom?: (roomName: string) => void;
  onJoinRoom?: (roomId: string) => void;
}

const RoomCreation = ({ onCreateRoom, onJoinRoom }: RoomCreationProps) => {
  const [newRoomName, setNewRoomName] = useState('');
  const [joinRoomId, setJoinRoomId] = useState('');
  const [username, setUsername] = useState('');
  const [creatingUsername, setCreatingUsername] = useState('');
  const navigate = useNavigate();

  const generateRoomId = () => {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
  };

  const handleCreateRoom = () => {
    if (newRoomName.trim() && creatingUsername.trim()) {
      const roomId = generateRoomId();
      if (onCreateRoom) {
        onCreateRoom(newRoomName);
      }
      navigate(`/room/${roomId}`, { 
        state: { 
          roomName: newRoomName,
          username: creatingUsername,
          isCreator: true 
        } 
      });
    }
  };

  const handleJoinRoom = () => {
    if (joinRoomId.trim() && username.trim()) {
      if (onJoinRoom) {
        onJoinRoom(joinRoomId);
      }
      navigate(`/room/${joinRoomId}`, { 
        state: { 
          username: username,
          isCreator: false 
        } 
      });
    }
  };

  return (
    <div className="flex flex-col md:flex-row gap-6 w-full max-w-2xl mx-auto my-8">
      <Dialog>
        <DialogTrigger asChild>
          <Button className="flex-1 h-20 text-lg card-glass btn-hover-effect group">
            <div className="flex flex-col items-center">
              <div className="rounded-full bg-primary/20 p-2 mb-2 transition-all duration-300 group-hover:bg-primary/30">
                <Plus className="h-5 w-5 text-primary" />
              </div>
              <span>Create Room</span>
            </div>
          </Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Create a New Room</DialogTitle>
            <DialogDescription>
              Enter a name for your chat room and your display name
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <div className="flex items-center">
                <MessageCircle className="mr-2 h-4 w-4" />
                <span className="text-sm font-medium">Room Name</span>
              </div>
              <Input
                value={newRoomName}
                onChange={(e) => setNewRoomName(e.target.value)}
                placeholder="e.g., Team Meeting"
                className="col-span-3"
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center">
                <User className="mr-2 h-4 w-4" />
                <span className="text-sm font-medium">Your Display Name</span>
              </div>
              <Input
                value={creatingUsername}
                onChange={(e) => setCreatingUsername(e.target.value)}
                placeholder="e.g., John Doe"
                className="col-span-3"
              />
            </div>
          </div>
          <DialogFooter>
            <Button 
              onClick={handleCreateRoom} 
              disabled={!newRoomName.trim() || !creatingUsername.trim()}
              className="btn-hover-effect"
            >
              <Plus className="mr-2 h-4 w-4" />
              Create Room
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog>
        <DialogTrigger asChild>
          <Button variant="secondary" className="flex-1 h-20 text-lg card-glass btn-hover-effect group">
            <div className="flex flex-col items-center">
              <div className="rounded-full bg-accent p-2 mb-2 transition-all duration-300 group-hover:bg-accent/70">
                <LogIn className="h-5 w-5" />
              </div>
              <span>Join Room</span>
            </div>
          </Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Join an Existing Room</DialogTitle>
            <DialogDescription>
              Enter the room ID and your display name to join
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <div className="flex items-center">
                <MessageCircle className="mr-2 h-4 w-4" />
                <span className="text-sm font-medium">Room ID</span>
              </div>
              <Input
                value={joinRoomId}
                onChange={(e) => setJoinRoomId(e.target.value.toUpperCase())}
                placeholder="e.g., ABC123"
                className="col-span-3 uppercase"
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center">
                <User className="mr-2 h-4 w-4" />
                <span className="text-sm font-medium">Your Display Name</span>
              </div>
              <Input
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="e.g., Jane Doe"
                className="col-span-3"
              />
            </div>
          </div>
          <DialogFooter>
            <Button 
              onClick={handleJoinRoom} 
              disabled={!joinRoomId.trim() || !username.trim()}
              className="btn-hover-effect"
              variant="secondary"
            >
              <LogIn className="mr-2 h-4 w-4" />
              Join Room
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default RoomCreation;
