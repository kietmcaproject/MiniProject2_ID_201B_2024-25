import React, { useState, useEffect, useRef } from 'react';
import { useParams, useLocation, useNavigate } from 'react-router-dom';
import ChatMessage, { MessageType } from './ChatMessage';
import ChatInput from './ChatInput';
import { Button } from './ui/button';
import { supabase } from "@/integrations/supabase/client";
import { toast } from '@/components/ui/use-toast';
import { ChevronLeft, Users, Share, Video } from 'lucide-react';
import { ScrollArea } from './ui/scroll-area';
import VideoCall from './VideoCall';

interface Message {
  id: string;
  text: string;
  timestamp: string;
  created_at?: string;
  isSent: boolean;
  type: MessageType;
  mediaUrl?: string;
  username: string;
}

const ChatRoom = () => {
  const { roomId } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const { username = 'Anonymous', roomName = `Room ${roomId}`, isCreator = false } = location.state || {};
  
  const [messages, setMessages] = useState<Message[]>([]);
  const [participants, setParticipants] = useState<string[]>([username]);
  const [isTyping, setIsTyping] = useState(false);
  const [showParticipants, setShowParticipants] = useState(false);
  const [isInVideoCall, setIsInVideoCall] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const viewportRef = useRef<HTMLDivElement>(null);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const shouldScrollToBottom = useRef(true);

  // Function to scroll to bottom
  const scrollToBottom = () => {
    if (shouldScrollToBottom.current && viewportRef.current) {
      viewportRef.current.scrollTo({
        top: viewportRef.current.scrollHeight,
        behavior: 'smooth'
      });
    }
  };

  // Scroll to bottom when messages change
  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Add scroll listener to detect when user manually scrolls up
  useEffect(() => {
    const viewport = viewportRef.current;
    if (!viewport) return;

    const handleScroll = () => {
      const isAtBottom = viewport.scrollHeight - viewport.clientHeight - viewport.scrollTop < 50;
      shouldScrollToBottom.current = isAtBottom;
    };

    viewport.addEventListener('scroll', handleScroll);
    return () => viewport.removeEventListener('scroll', handleScroll);
  }, []);

  // Function to check if a message is older than 24 hours
  const isMessageExpired = (timestamp: string) => {
    const messageTime = new Date(timestamp).getTime();
    const currentTime = new Date().getTime();
    const hoursDiff = (currentTime - messageTime) / (1000 * 60 * 60);
    return hoursDiff >= 24;
  };

  // Function to delete expired messages
  const deleteExpiredMessages = async () => {
    try {
      // Get messages older than 24 hours
      const twentyFourHoursAgo = new Date();
      twentyFourHoursAgo.setHours(twentyFourHoursAgo.getHours() - 24);
      
      const { data: expiredMessages, error: fetchError } = await supabase
        .from('chat_messages')
        .select('id')
        .eq('room_id', roomId)
        .lt('created_at', twentyFourHoursAgo.toISOString());
      
      if (fetchError) {
        console.error('Error fetching expired messages:', fetchError);
        return;
      }
      
      if (expiredMessages && expiredMessages.length > 0) {
        const expiredIds = expiredMessages.map(msg => msg.id);
        
        const { error: deleteError } = await supabase
          .from('chat_messages')
          .delete()
          .in('id', expiredIds);
        
        if (deleteError) {
          console.error('Error deleting expired messages:', deleteError);
        } else {
          console.log(`Deleted ${expiredIds.length} expired messages`);
        }
      }
    } catch (error) {
      console.error('Error in deleteExpiredMessages:', error);
    }
  };

  useEffect(() => {
    const loadMessages = async () => {
      // Run cleanup of expired messages first
      await deleteExpiredMessages();
      
      const { data, error } = await supabase
        .from('chat_messages')
        .select('*')
        .eq('room_id', roomId)
        .order('created_at', { ascending: true });

      if (error) {
        console.error('Error loading messages:', error);
        toast({
          title: "Error loading messages",
          description: error.message,
          variant: "destructive",
        });
        return;
      }

      // Filter out expired messages from the UI
      const validMessages = data.filter(msg => !isMessageExpired(msg.created_at || msg.timestamp));
      
      const formattedMessages = validMessages.map(msg => ({
        id: msg.id,
        text: msg.text,
        timestamp: new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        created_at: msg.created_at || msg.timestamp,
        isSent: msg.username === username,
        type: msg.type as MessageType,
        mediaUrl: msg.media_url,
        username: msg.username
      }));

      setMessages(formattedMessages);
      
      // Extract unique usernames from messages
      const uniqueUsers = [...new Set(validMessages.map(msg => msg.username))];
      setParticipants(prev => [...new Set([...prev, ...uniqueUsers])]);
    };

    loadMessages();

    // Set up periodic checks for expired messages (every 5 minutes)
    const checkInterval = setInterval(() => {
      deleteExpiredMessages().then(() => {
        // Update the messages list after deletion
        setMessages(prevMessages => 
          prevMessages.filter(msg => !isMessageExpired(msg.created_at || msg.timestamp))
        );
      });
    }, 5 * 60 * 1000);

    const channel = supabase
      .channel('chat_messages')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'chat_messages',
          filter: `room_id=eq.${roomId}`
        },
        (payload) => {
          const newMessage = payload.new;
          
          // Skip expired messages
          if (isMessageExpired(newMessage.created_at || newMessage.timestamp)) {
            return;
          }
          
          const formattedMessage = {
            id: newMessage.id,
            text: newMessage.text,
            timestamp: new Date(newMessage.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            created_at: newMessage.created_at || newMessage.timestamp,
            isSent: newMessage.username === username,
            type: newMessage.type as MessageType,
            mediaUrl: newMessage.media_url,
            username: newMessage.username
          };
          setMessages(prev => [...prev, formattedMessage]);
          
          // Add user to participants if not already there
          if (!participants.includes(newMessage.username)) {
            setParticipants(prev => [...prev, newMessage.username]);
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
      clearInterval(checkInterval);
    };
  }, [roomId, username, participants]);
  
  const handleSendMessage = async (text: string, type: MessageType = 'text', mediaUrl?: string) => {
    const newMessage = {
      room_id: roomId,
      text,
      type,
      media_url: mediaUrl,
      username,
      timestamp: new Date().toISOString()
    };

    const { error } = await supabase
      .from('chat_messages')
      .insert([newMessage]);

    if (error) {
      console.error('Error sending message:', error);
      toast({
        title: "Error sending message",
        description: error.message,
        variant: "destructive",
      });
    }
    
    // After sending a message, ensure we scroll to bottom
    shouldScrollToBottom.current = true;
  };

  const handleLeaveRoom = () => {
    navigate('/');
  };

  const handleShareScreen = async () => {
    try {
      // Check if browser supports screen capture
      if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) {
        toast({
          title: "Screen sharing not supported",
          description: "Your browser doesn't support screen sharing.",
          variant: "destructive",
        });
        return;
      }
      
      const mediaStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
      const track = mediaStream.getVideoTracks()[0];
      
      // Check if ImageCapture is supported
      if (!window.ImageCapture) {
        toast({
          title: "Screen capture not supported",
          description: "Your browser doesn't support image capture. Try using Chrome or Edge.",
          variant: "destructive",
        });
        track.stop();
        return;
      }
      
      const imageCapture = new window.ImageCapture(track);
      const bitmap = await imageCapture.grabFrame();
      
      const canvas = document.createElement('canvas');
      canvas.width = bitmap.width;
      canvas.height = bitmap.height;
      const context = canvas.getContext('2d');
      if (!context) {
        toast({
          title: "Screen sharing error",
          description: "Failed to create canvas context for screen capture.",
          variant: "destructive",
        });
        track.stop();
        return;
      }
      
      context.drawImage(bitmap, 0, 0);
      
      // Add a loading toast
      const loadingToast = toast({
        title: "Processing screenshot",
        description: "Please wait while we process your screenshot...",
      });
      
      const blob = await new Promise<Blob>((resolve, reject) => {
        canvas.toBlob(blob => {
          if (blob) {
            resolve(blob);
          } else {
            reject(new Error('Failed to create blob from canvas'));
          }
        }, 'image/jpeg', 0.8); // Use JPEG with 80% quality for better performance
      });
      
      const reader = new FileReader();
      reader.readAsDataURL(blob);
      reader.onloadend = () => {
        const base64data = reader.result as string;
        handleSendMessage("Shared screen", "screen", base64data);
        
        // Remove loading toast and show success
        toast({
          title: "Screen shared",
          description: "Your screenshot has been shared in the chat.",
        });
      };
      
      track.stop();
    } catch (error) {
      console.error('Error sharing screen:', error);
      toast({
        title: "Screen sharing error",
        description: error instanceof Error ? error.message : "Could not share screen. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleStartVideoCall = () => {
    // Send a system message that user started a video call
    handleSendMessage(`${username} started a video call`, 'system');
    setIsInVideoCall(true);
  };
  
  const handleEndVideoCall = () => {
    setIsInVideoCall(false);
    // Send a system message that user ended the video call
    handleSendMessage(`${username} ended the video call`, 'system');
  };

  const simulateTyping = () => {
    setIsTyping(true);
    setTimeout(() => setIsTyping(false), 3000);
  };

  useEffect(() => {
    if (!username) {
      navigate('/');
    }
    
    // Simulate someone typing occasionally
    const typingInterval = setInterval(() => {
      if (Math.random() > 0.7) simulateTyping();
    }, 10000);
    
    return () => clearInterval(typingInterval);
  }, [username, navigate]);

  const toggleParticipants = () => {
    setShowParticipants(!showParticipants);
  };

  return (
    <div className="flex flex-col h-screen max-w-2xl mx-auto bg-background">
      <div className="flex flex-col h-full">
        <div className="flex justify-between items-center p-4 border-b shadow-sm card-glass">
          <div className="flex items-center">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={handleLeaveRoom} 
              className="mr-2 transition-transform hover:scale-110"
            >
              <ChevronLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-semibold">{roomName}</h1>
              <div className="flex items-center text-sm text-muted-foreground">
                <span>Room ID: {roomId}</span>
                <span className="mx-2 text-xs">•</span>
                <span>{participants.length} {participants.length === 1 ? 'member' : 'members'}</span>
              </div>
            </div>
          </div>
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              size="icon"
              onClick={toggleParticipants}
              className={`btn-hover-effect ${showParticipants ? 'bg-accent' : ''}`}
            >
              <Users className="h-5 w-5" />
            </Button>
            <Button 
              variant="outline" 
              onClick={handleStartVideoCall}
              className="btn-hover-effect"
            >
              <Video className="h-5 w-5 mr-1" />
              Video Call
            </Button>
            <Button 
              variant="outline" 
              onClick={handleShareScreen}
              className="btn-hover-effect"
            >
              <Share className="h-5 w-5 mr-1" />
              Share Screen
            </Button>
          </div>
        </div>
        
        <div className="flex flex-1 overflow-hidden relative">
          {/* Main chat area with ScrollArea component */}
          <ScrollArea 
            className="flex-1 h-full scrollbar-thin" 
            ref={scrollAreaRef}
            viewportRef={viewportRef}
          >
            <div className="p-4 space-y-4">
              {messages.map((message) => (
                <ChatMessage
                  key={message.id}
                  message={`${message.username}: ${message.text}`}
                  timestamp={message.timestamp}
                  isSent={message.isSent}
                  type={message.type}
                  mediaUrl={message.mediaUrl}
                />
              ))}
              {isTyping && (
                <div className="flex mb-4">
                  <div className="max-w-[70%] rounded-2xl px-4 py-2 bg-accent animate-fade-in">
                    <div className="typing-indicator mb-1">
                      <span></span>
                      <span></span>
                      <span></span>
                    </div>
                    <p className="text-xs text-foreground/70">Someone is typing...</p>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          </ScrollArea>
          
          {/* Participants sidebar */}
          {showParticipants && (
            <div className="absolute right-0 top-0 h-full w-64 bg-background border-l border-border p-4 card-glass animate-fade-in transform transition-transform z-10 overflow-y-auto">
              <h3 className="font-medium mb-3 text-lg">Participants</h3>
              <ul className="space-y-2">
                {participants.map((user, index) => (
                  <li key={index} className="flex items-center p-2 rounded-md hover:bg-accent/50 transition-colors">
                    <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground">
                      {user.charAt(0).toUpperCase()}
                    </div>
                    <span className="ml-2">{user}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        <ChatInput onSendMessage={handleSendMessage} onShareScreen={handleShareScreen} />
        
        {/* Video call overlay */}
        {isInVideoCall && (
          <VideoCall 
            roomId={roomId || ''} 
            username={username}
            onClose={handleEndVideoCall}
          />
        )}
      </div>
    </div>
  );
};

export default ChatRoom;
