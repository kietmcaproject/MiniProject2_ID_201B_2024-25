
import React, { useState, useEffect, useRef } from 'react';
import { Button } from './ui/button';
import { Video, VideoOff, Mic, MicOff, Webcam } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';

interface VideoCallProps {
  roomId: string;
  username: string;
  onClose: () => void;
}

type PeerConnection = {
  connection: RTCPeerConnection;
  stream?: MediaStream;
};

const VideoCall: React.FC<VideoCallProps> = ({ roomId, username, onClose }) => {
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStreams, setRemoteStreams] = useState<Map<string, MediaStream>>(new Map());
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [isConnecting, setIsConnecting] = useState(true);
  
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const peerConnections = useRef<Map<string, PeerConnection>>(new Map());
  
  // Initialize WebRTC
  useEffect(() => {
    const initializeCall = async () => {
      try {
        // Request user media
        const stream = await navigator.mediaDevices.getUserMedia({
          video: true,
          audio: true
        });
        
        setLocalStream(stream);
        
        // Make sure to set the stream to the video element
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = stream;
        }
        
        // Connect to signaling server through Supabase realtime
        setupSignaling();
        
        setIsConnecting(false);
        
      } catch (error) {
        console.error('Error accessing media devices:', error);
        toast({
          title: "Camera/Microphone Access Error",
          description: "Could not access your camera or microphone. Please check permissions.",
          variant: "destructive",
        });
        onClose();
      }
    };
    
    initializeCall();
    
    // Cleanup function
    return () => {
      // Stop all tracks in the local stream
      if (localStream) {
        localStream.getTracks().forEach(track => track.stop());
      }
      
      // Close all peer connections
      peerConnections.current.forEach((peer) => {
        peer.connection.close();
      });
    };
  }, []);
  
  // Setup signaling using Supabase's realtime
  const setupSignaling = () => {
    import('@/integrations/supabase/client').then(({ supabase }) => {
      // Channel for signaling
      const channel = supabase
        .channel(`video-call-${roomId}`)
        .on('broadcast', { event: 'signal' }, (payload) => {
          handleSignalingMessage(payload);
        })
        .subscribe();
        
      // Announce presence in the room
      if (localStream) {
        channel.send({
          type: 'broadcast',
          event: 'signal',
          payload: {
            type: 'join',
            sender: username
          }
        });
      }
    });
  };
  
  // Handle incoming signaling messages
  const handleSignalingMessage = (payload: any) => {
    const { type, sender, sdp, ice, target } = payload;
    
    // If message is not for us, ignore
    if (target && target !== username) return;
    
    switch (type) {
      case 'join':
        if (sender !== username) {
          // Create new peer connection for the joining user
          createPeerConnection(sender, true);
        }
        break;
      
      case 'offer':
        handleOffer(sender, sdp);
        break;
        
      case 'answer':
        handleAnswer(sender, sdp);
        break;
        
      case 'ice-candidate':
        handleIceCandidate(sender, ice);
        break;
        
      case 'leave':
        handlePeerLeave(sender);
        break;
    }
  };
  
  // Create a new peer connection
  const createPeerConnection = async (peerId: string, isInitiator: boolean) => {
    try {
      import('@/integrations/supabase/client').then(async ({ supabase }) => {
        // STUN servers for ICE negotiation
        const configuration = {
          iceServers: [
            { urls: 'stun:stun.l.google.com:19302' },
            { urls: 'stun:stun1.l.google.com:19302' }
          ]
        };
        
        const peerConnection = new RTCPeerConnection(configuration);
        
        // Add local tracks to the connection
        if (localStream) {
          localStream.getTracks().forEach(track => {
            peerConnection.addTrack(track, localStream);
          });
        }
        
        // Handle ICE candidates
        peerConnection.onicecandidate = (event) => {
          if (event.candidate) {
            // Send ICE candidate to peer
            supabase.channel(`video-call-${roomId}`).send({
              type: 'broadcast',
              event: 'signal',
              payload: {
                type: 'ice-candidate',
                sender: username,
                target: peerId,
                ice: event.candidate
              }
            });
          }
        };
        
        // Handle incoming tracks
        peerConnection.ontrack = (event) => {
          // Create a new MediaStream for the remote peer
          const stream = new MediaStream();
          event.streams[0].getTracks().forEach(track => {
            stream.addTrack(track);
          });
          
          // Update remote streams
          setRemoteStreams(prev => {
            const newStreams = new Map(prev);
            newStreams.set(peerId, stream);
            return newStreams;
          });
        };
        
        // Store peer connection
        peerConnections.current.set(peerId, {
          connection: peerConnection
        });
        
        // If we're the initiator, create and send an offer
        if (isInitiator) {
          const offer = await peerConnection.createOffer();
          await peerConnection.setLocalDescription(offer);
          
          supabase.channel(`video-call-${roomId}`).send({
            type: 'broadcast',
            event: 'signal',
            payload: {
              type: 'offer',
              sender: username,
              target: peerId,
              sdp: peerConnection.localDescription
            }
          });
        }
      });
    } catch (error) {
      console.error('Error creating peer connection:', error);
    }
  };
  
  // Handle incoming offer
  const handleOffer = async (peerId: string, sdp: RTCSessionDescriptionInit) => {
    try {
      import('@/integrations/supabase/client').then(async ({ supabase }) => {
        // Create peer connection if it doesn't exist
        if (!peerConnections.current.has(peerId)) {
          createPeerConnection(peerId, false);
        }
        
        const peerConnection = peerConnections.current.get(peerId)?.connection;
        if (!peerConnection) return;
        
        // Set remote description
        await peerConnection.setRemoteDescription(new RTCSessionDescription(sdp));
        
        // Create answer
        const answer = await peerConnection.createAnswer();
        await peerConnection.setLocalDescription(answer);
        
        // Send answer
        supabase.channel(`video-call-${roomId}`).send({
          type: 'broadcast',
          event: 'signal',
          payload: {
            type: 'answer',
            sender: username,
            target: peerId,
            sdp: peerConnection.localDescription
          }
        });
      });
    } catch (error) {
      console.error('Error handling offer:', error);
    }
  };
  
  // Handle incoming answer
  const handleAnswer = async (peerId: string, sdp: RTCSessionDescriptionInit) => {
    try {
      const peerConnection = peerConnections.current.get(peerId)?.connection;
      if (peerConnection) {
        await peerConnection.setRemoteDescription(new RTCSessionDescription(sdp));
      }
    } catch (error) {
      console.error('Error handling answer:', error);
    }
  };
  
  // Handle incoming ICE candidate
  const handleIceCandidate = async (peerId: string, ice: RTCIceCandidateInit) => {
    try {
      const peerConnection = peerConnections.current.get(peerId)?.connection;
      if (peerConnection) {
        await peerConnection.addIceCandidate(new RTCIceCandidate(ice));
      }
    } catch (error) {
      console.error('Error handling ICE candidate:', error);
    }
  };
  
  // Handle peer leaving
  const handlePeerLeave = (peerId: string) => {
    // Close connection and remove streams
    const peerConnection = peerConnections.current.get(peerId);
    if (peerConnection) {
      peerConnection.connection.close();
      peerConnections.current.delete(peerId);
    }
    
    // Remove remote stream
    setRemoteStreams(prev => {
      const newStreams = new Map(prev);
      newStreams.delete(peerId);
      return newStreams;
    });
  };
  
  // Toggle audio
  const toggleAudio = () => {
    if (localStream) {
      const audioTracks = localStream.getAudioTracks();
      audioTracks.forEach(track => {
        track.enabled = !track.enabled;
      });
      setIsMuted(!isMuted);
    }
  };
  
  // Toggle video
  const toggleVideo = () => {
    if (localStream) {
      const videoTracks = localStream.getVideoTracks();
      videoTracks.forEach(track => {
        track.enabled = !track.enabled;
      });
      setIsVideoOff(!isVideoOff);
    }
  };
  
  // End the call and clean up
  const endCall = async () => {
    try {
      import('@/integrations/supabase/client').then(({ supabase }) => {
        // Notify peers that we're leaving
        supabase.channel(`video-call-${roomId}`).send({
          type: 'broadcast',
          event: 'signal',
          payload: {
            type: 'leave',
            sender: username
          }
        });
        
        // Stop local stream tracks
        if (localStream) {
          localStream.getTracks().forEach(track => track.stop());
        }
        
        // Close all peer connections
        peerConnections.current.forEach((peer) => {
          peer.connection.close();
        });
        
        onClose();
      });
    } catch (error) {
      console.error('Error ending call:', error);
      onClose();
    }
  };
  
  return (
    <div className="fixed inset-0 bg-black/90 z-50 flex flex-col">
      <div className="p-4 flex justify-between items-center bg-background/20">
        <h3 className="font-semibold text-white">Video Call</h3>
        <Button variant="destructive" onClick={endCall}>End Call</Button>
      </div>
      
      <div className="flex-1 flex flex-wrap justify-center items-center gap-4 p-4 overflow-auto">
        {isConnecting ? (
          <div className="text-white text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-white mx-auto mb-4"></div>
            <p>Setting up your video call...</p>
          </div>
        ) : (
          <>
            {/* Local video */}
            <div className="relative min-w-[320px] min-h-[240px] max-w-[480px] rounded-lg overflow-hidden border-2 border-primary shadow-lg">
              {!isVideoOff ? (
                <video 
                  ref={localVideoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover bg-gray-800"
                />
              ) : (
                <div className="absolute inset-0 bg-gray-900 flex flex-col items-center justify-center">
                  <Avatar className="h-24 w-24 mb-2 bg-primary">
                    <AvatarFallback>{username.charAt(0).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <p className="text-gray-400">Camera Off</p>
                </div>
              )}
              <div className="absolute bottom-2 left-2 bg-black/50 px-2 py-1 rounded-md text-white text-sm">
                You ({username}) {isMuted && '(Muted)'}
              </div>
            </div>
            
            {/* Remote videos */}
            {Array.from(remoteStreams).map(([peerId, stream]) => (
              <div key={peerId} className="relative min-w-[320px] min-h-[240px] max-w-[480px] rounded-lg overflow-hidden border-2 border-accent shadow-lg">
                {stream.getVideoTracks().length > 0 && stream.getVideoTracks()[0].enabled ? (
                  <video
                    autoPlay
                    playsInline
                    className="w-full h-full object-cover bg-gray-800"
                    ref={el => {
                      if (el) el.srcObject = stream;
                    }}
                  />
                ) : (
                  <div className="absolute inset-0 bg-gray-900 flex flex-col items-center justify-center">
                    <Avatar className="h-24 w-24 mb-2 bg-accent">
                      <AvatarFallback>{peerId.charAt(0).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <p className="text-gray-400">Camera Off</p>
                  </div>
                )}
                <div className="absolute bottom-2 left-2 bg-black/50 px-2 py-1 rounded-md text-white text-sm">
                  {peerId}
                </div>
              </div>
            ))}
          </>
        )}
      </div>
      
      <div className="p-4 bg-background/20 flex justify-center">
        <div className="flex gap-4">
          <Button
            variant={isMuted ? "destructive" : "outline"}
            size="icon"
            onClick={toggleAudio}
            className="rounded-full h-12 w-12"
          >
            {isMuted ? <MicOff className="h-6 w-6" /> : <Mic className="h-6 w-6" />}
          </Button>
          
          <Button
            variant={isVideoOff ? "destructive" : "outline"}
            size="icon"
            onClick={toggleVideo}
            className="rounded-full h-12 w-12"
          >
            {isVideoOff ? <VideoOff className="h-6 w-6" /> : <Webcam className="h-6 w-6" />}
          </Button>
          
          <Button
            variant="destructive"
            onClick={endCall}
            className="rounded-full px-6"
          >
            End Call
          </Button>
        </div>
      </div>
    </div>
  );
};

export default VideoCall;
