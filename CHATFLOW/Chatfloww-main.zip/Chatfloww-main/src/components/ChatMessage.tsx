
import React from 'react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

export type MessageType = 'text' | 'emoji' | 'image' | 'screen' | 'file' | 'system' | 'video' | 'music' | 'youtube';

interface ChatMessageProps {
  message: string;
  timestamp: string;
  isSent: boolean;
  type: MessageType;
  mediaUrl?: string;
}

const ChatMessage: React.FC<ChatMessageProps> = ({
  message,
  timestamp,
  isSent,
  type,
  mediaUrl,
}) => {
  // Extract username from message for better display
  let displayContent = message;
  let username = '';
  
  if (message.includes(':')) {
    const parts = message.split(':', 2);
    username = parts[0];
    displayContent = parts[1].trim();
  }
  
  // For system messages, we want to render them differently
  if (type === 'system') {
    return (
      <div className="flex justify-center my-2">
        <div className="bg-muted/40 text-muted-foreground text-sm px-3 py-1 rounded-full">
          {displayContent}
        </div>
      </div>
    );
  }
  
  // Normal message rendering
  return (
    <div className={`flex mb-4 ${isSent ? 'justify-end' : 'justify-start'}`}>
      <div 
        className={cn(
          "max-w-[80%] rounded-2xl px-4 py-2 break-words",
          isSent 
            ? "bg-primary text-primary-foreground rounded-tr-none" 
            : "bg-accent rounded-tl-none"
        )}
      >
        {!isSent && <p className="font-semibold text-sm mb-1">{username}</p>}
        
        {/* Render content based on message type */}
        {type === 'text' && <p className="whitespace-pre-wrap">{displayContent}</p>}
        
        {type === 'emoji' && <p className="text-4xl">{displayContent}</p>}
        
        {type === 'image' && mediaUrl && (
          <div className="mb-2">
            <img 
              src={mediaUrl} 
              alt="Shared image" 
              className="max-w-full rounded-lg" 
              loading="lazy" 
            />
            {displayContent && <p className="mt-2">{displayContent}</p>}
          </div>
        )}
        
        {type === 'screen' && mediaUrl && (
          <div className="mb-2">
            <img 
              src={mediaUrl} 
              alt="Shared screen" 
              className="max-w-full rounded-lg" 
              loading="lazy" 
            />
            <p className="mt-2">Shared a screenshot</p>
          </div>
        )}
        
        {type === 'file' && mediaUrl && (
          <div className="mb-2">
            <a 
              href={mediaUrl} 
              target="_blank" 
              rel="noopener noreferrer" 
              className="flex items-center bg-background/20 p-2 rounded"
            >
              <div className="mr-2">📄</div>
              <div className="overflow-hidden text-ellipsis">
                <p className="font-medium">{displayContent || "Shared file"}</p>
                <p className="text-xs opacity-70">Click to view</p>
              </div>
            </a>
          </div>
        )}
        
        {type === 'video' && (
          <div className="mb-2 text-center">
            <p className="font-medium">📹 Video Call</p>
            <p className="text-sm">{displayContent}</p>
          </div>
        )}

        {type === 'music' && mediaUrl && (
          <div className="mb-2">
            <audio controls className="w-full">
              <source src={mediaUrl} />
              Your browser does not support the audio element.
            </audio>
            {displayContent && <p className="mt-2">{displayContent}</p>}
          </div>
        )}

        {type === 'youtube' && mediaUrl && (
          <div className="mb-2">
            <iframe 
              width="100%" 
              height="200" 
              src={mediaUrl.replace('watch?v=', 'embed/')} 
              title="YouTube video player" 
              frameBorder="0" 
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
              allowFullScreen
              className="rounded-lg"
            ></iframe>
            {displayContent && <p className="mt-2">{displayContent}</p>}
          </div>
        )}
        
        <div className="text-right mt-1">
          <span 
            className={`text-xs ${isSent ? 'text-primary-foreground/70' : 'text-foreground/50'}`}
          >
            {timestamp}
          </span>
        </div>
      </div>
    </div>
  );
};

export default ChatMessage;
