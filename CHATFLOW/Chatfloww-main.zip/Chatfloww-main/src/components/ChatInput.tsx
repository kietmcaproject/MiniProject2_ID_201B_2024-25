import React, { useState, useRef, useMemo, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  MessageCircle, Video, Music, Youtube, 
  ScreenShare, Plus, X, Smile, Paperclip, 
  Image, FileImage, FileVideo, FileAudio
} from "lucide-react";
import { 
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
  SheetClose
} from "@/components/ui/sheet";
import { 
  Popover,
  PopoverContent,
  PopoverTrigger
} from "@/components/ui/popover";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { MessageType } from './ChatMessage';
import { toast } from '@/components/ui/use-toast';
import EmojiPicker from 'emoji-picker-react';

interface ChatInputProps {
  onSendMessage: (message: string, type?: MessageType, mediaUrl?: string) => void;
  onShareScreen?: () => void;
}

// Common emoji categories for quick suggestions
const quickEmojis = [
  '😊', '😂', '❤️', '👍', '🎉', '🔥', '👏', '🙏', '😍', '🤔', 
  '👋', '✨', '💯', '🌟', '😎', '🤩', '👀', '💪', '🚀', '💡'
];

const ChatInput = ({ onSendMessage, onShareScreen }: ChatInputProps) => {
  const [message, setMessage] = useState('');
  const [mediaUrl, setMediaUrl] = useState('');
  const [mediaType, setMediaType] = useState<MessageType>('text');
  const [isExpanded, setIsExpanded] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [randomEmojis, setRandomEmojis] = useState<string[]>([]);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const sheetCloseRef = useRef<HTMLButtonElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Generate random emoji suggestions on mount and when emoji picker opens
  useEffect(() => {
    generateRandomEmojis();
  }, []);

  const generateRandomEmojis = () => {
    // Shuffle and pick 5 random emojis from our quick emoji array
    const shuffled = [...quickEmojis].sort(() => 0.5 - Math.random());
    setRandomEmojis(shuffled.slice(0, 5));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if ((message.trim() && mediaType === 'text') || (mediaUrl && mediaType !== 'text') || selectedFile) {
      if (selectedFile) {
        // Handle file upload - for simplicity, we'll use base64 encoding
        const reader = new FileReader();
        reader.onloadend = () => {
          const fileType = selectedFile.type.split('/')[0];
          let type: MessageType = 'text';
          
          if (fileType === 'image') type = 'image';
          else if (fileType === 'video') type = 'video';
          else if (fileType === 'audio') type = 'music';
          
          onSendMessage(message || `Shared a ${selectedFile.name}`, type, reader.result as string);
          resetForm();
        };
        reader.readAsDataURL(selectedFile);
      } else {
        onSendMessage(message || `Shared a ${mediaType}`, mediaType, mediaUrl);
        resetForm();
      }
    }
  };

  const resetForm = () => {
    setMessage('');
    setMediaUrl('');
    setMediaType('text');
    setIsExpanded(false);
    setSelectedFile(null);
    
    // Focus the input after sending
    setTimeout(() => {
      inputRef.current?.focus();
    }, 0);
  };

  const handleScreenShare = () => {
    if (sheetCloseRef.current) {
      sheetCloseRef.current.click();
    }
    
    if (onShareScreen) {
      onShareScreen();
    }
  };

  const handleMediaSelect = (type: MessageType) => {
    setMediaType(type);
    setIsExpanded(true);
    setSelectedFile(null);
    
    // Close the sheet
    if (sheetCloseRef.current) {
      sheetCloseRef.current.click();
    }
    
    // Focus the URL input
    setTimeout(() => {
      inputRef.current?.focus();
    }, 100);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    // Submit on Enter, unless Shift is held
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const resetMedia = () => {
    setMediaType('text');
    setMediaUrl('');
    setIsExpanded(false);
    setSelectedFile(null);
  };

  const validateMediaUrl = (type: MessageType, url: string): boolean => {
    if (!url) return false;
    
    try {
      new URL(url);
      
      if (type === 'youtube') {
        return url.includes('youtube.com') || url.includes('youtu.be');
      }
      
      return true;
    } catch (e) {
      toast({
        title: "Invalid URL",
        description: "Please enter a valid URL",
        variant: "destructive",
      });
      return false;
    }
  };

  const getMediaTypeLabel = () => {
    switch (mediaType) {
      case 'video': return 'Video URL';
      case 'music': return 'Audio URL';
      case 'youtube': return 'YouTube URL';
      default: return '';
    }
  };

  const addEmoji = (emojiData: any) => {
    const emoji = emojiData.emoji;
    setMessage(prev => prev + emoji);
    
    // Focus back on input after emoji selection
    if (inputRef.current) {
      inputRef.current.focus();
    }
  };

  const handleQuickEmojiClick = (emoji: string) => {
    setMessage(prev => prev + emoji);
    // Generate new random emojis after using one
    generateRandomEmojis();
    
    // Focus back on input after emoji selection
    if (inputRef.current) {
      inputRef.current.focus();
    }
  };

  const handleFileSelect = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const file = files[0];
      setSelectedFile(file);
      
      // Close the sheet
      if (sheetCloseRef.current) {
        sheetCloseRef.current.click();
      }
      
      // Set appropriate message based on file type
      const fileType = file.type.split('/')[0];
      setMessage(`Shared ${fileType}: ${file.name}`);
      
      // Focus the input for additional caption
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
    }
  };

  const quickMediaOptions = useMemo(() => [
    { icon: <FileImage className="h-4 w-4" />, label: 'Image', type: 'image' as MessageType },
    { icon: <FileVideo className="h-4 w-4" />, label: 'Video', type: 'video' as MessageType },
    { icon: <FileAudio className="h-4 w-4" />, label: 'Audio', type: 'music' as MessageType },
    { icon: <Youtube className="h-4 w-4" />, label: 'YouTube', type: 'youtube' as MessageType }
  ], []);

  return (
    <form onSubmit={handleSubmit} className="p-4 border-t bg-background card-glass">
      {/* Hidden file input for device file selection */}
      <input 
        type="file" 
        ref={fileInputRef}
        onChange={handleFileChange}
        accept="image/*,video/*,audio/*"
        className="hidden"
      />
      
      {/* Quick emoji suggestions */}
      <div className="flex gap-2 mb-3 overflow-x-auto pb-1">
        {randomEmojis.map((emoji, index) => (
          <Button 
            key={index} 
            type="button" 
            variant="outline" 
            className="px-2 py-1 h-8 hover:bg-accent/50 btn-hover-effect"
            onClick={() => handleQuickEmojiClick(emoji)}
          >
            {emoji}
          </Button>
        ))}
        <Button 
          type="button" 
          variant="outline" 
          size="sm"
          className="px-2 py-1 h-8 hover:bg-accent/50 btn-hover-effect"
          onClick={generateRandomEmojis}
        >
          🔄
        </Button>
      </div>
      
      {isExpanded && mediaType !== 'text' && !selectedFile && (
        <div className="flex items-center mb-3 animate-fade-in">
          <div className="flex items-center p-2 bg-accent/50 rounded-l-md">
            {mediaType === 'video' && <Video className="mr-2 text-foreground/70" />}
            {mediaType === 'music' && <Music className="mr-2 text-foreground/70" />}
            {mediaType === 'youtube' && <Youtube className="mr-2 text-foreground/70" />}
            <span className="text-sm font-medium">{getMediaTypeLabel()}:</span>
          </div>
          <Input
            value={mediaUrl}
            onChange={(e) => setMediaUrl(e.target.value)}
            placeholder={`Enter ${mediaType} URL...`}
            className="flex-1 rounded-l-none"
            ref={inputRef}
          />
          <Button 
            type="button" 
            variant="ghost" 
            size="icon"
            onClick={resetMedia}
            className="ml-2"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      )}
      
      {selectedFile && (
        <div className="flex items-center mb-3 animate-fade-in bg-accent/50 p-2 rounded-md">
          <div className="flex items-center">
            {selectedFile.type.includes('image') && <Image className="mr-2 text-foreground/70" />}
            {selectedFile.type.includes('video') && <FileVideo className="mr-2 text-foreground/70" />}
            {selectedFile.type.includes('audio') && <FileAudio className="mr-2 text-foreground/70" />}
            <span className="text-sm font-medium truncate max-w-[200px]">{selectedFile.name}</span>
          </div>
          <Button 
            type="button" 
            variant="ghost" 
            size="icon"
            onClick={resetMedia}
            className="ml-2"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      )}
      
      <div className="flex gap-2 items-center">
        <div className="flex-1 flex items-center gap-2 bg-accent/30 rounded-md px-2">
          <Popover open={showEmojiPicker} onOpenChange={setShowEmojiPicker}>
            <PopoverTrigger asChild>
              <Button 
                type="button" 
                size="icon" 
                variant="ghost" 
                className="hover:bg-accent/50"
              >
                <Smile className="h-5 w-5 text-foreground/70" />
              </Button>
            </PopoverTrigger>
            <PopoverContent 
              side="top" 
              className="p-0 border-none shadow-lg"
            >
              <EmojiPicker 
                onEmojiClick={addEmoji}
                width={320}
                height={400}
              />
            </PopoverContent>
          </Popover>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                type="button" 
                size="icon" 
                variant="ghost" 
                className="hover:bg-accent/50"
                onClick={handleFileSelect}
              >
                <Paperclip className="h-5 w-5 text-foreground/70" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuItem 
                onClick={handleFileSelect}
                className="cursor-pointer"
              >
                <div className="flex items-center gap-2">
                  <FileImage className="h-4 w-4" />
                  <span>Upload from device</span>
                </div>
              </DropdownMenuItem>
              {quickMediaOptions.map((option) => (
                <DropdownMenuItem 
                  key={option.label} 
                  onClick={() => handleMediaSelect(option.type)}
                  className="cursor-pointer"
                >
                  <div className="flex items-center gap-2">
                    {option.icon}
                    <span>{option.label}</span>
                  </div>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
          
          <Input
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={mediaType === 'text' && !selectedFile ? "Type a message..." : "Add a caption (optional)"}
            className="flex-1 border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0"
            ref={mediaType === 'text' && !selectedFile ? inputRef : undefined}
          />
        </div>
        
        <Sheet>
          <SheetTrigger asChild>
            <Button type="button" variant="outline" size="icon" className="btn-hover-effect">
              <Plus className="h-5 w-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="bottom" className="h-auto max-h-80">
            <SheetHeader className="pb-4">
              <SheetTitle>Share Media</SheetTitle>
              <SheetDescription>
                Select the type of media you want to share
              </SheetDescription>
            </SheetHeader>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 py-4">
              <Button 
                onClick={handleFileSelect}
                className="flex flex-col h-20 items-center justify-center btn-hover-effect"
                variant="outline"
              >
                <FileImage className="h-6 w-6 mb-2" /> 
                <span>From Device</span>
              </Button>
              <Button 
                onClick={() => handleMediaSelect('video')}
                className="flex flex-col h-20 items-center justify-center btn-hover-effect"
                variant="outline"
              >
                <Video className="h-6 w-6 mb-2" /> 
                <span>Share Video</span>
              </Button>
              <Button 
                onClick={() => handleMediaSelect('music')}
                className="flex flex-col h-20 items-center justify-center btn-hover-effect"
                variant="outline"
              >
                <Music className="h-6 w-6 mb-2" /> 
                <span>Share Music</span>
              </Button>
              <Button 
                onClick={() => handleMediaSelect('youtube')}
                className="flex flex-col h-20 items-center justify-center btn-hover-effect"
                variant="outline"
              >
                <Youtube className="h-6 w-6 mb-2" /> 
                <span>Share YouTube</span>
              </Button>
              <Button 
                onClick={handleScreenShare}
                className="flex flex-col h-20 items-center justify-center btn-hover-effect"
                variant="outline"
              >
                <ScreenShare className="h-6 w-6 mb-2" /> 
                <span>Share Screen</span>
              </Button>
            </div>
            <SheetClose ref={sheetCloseRef} className="sr-only">Close</SheetClose>
          </SheetContent>
        </Sheet>
        
        <Button 
          type="submit" 
          disabled={(mediaType === 'text' && !message.trim() && !selectedFile) || 
                   (mediaType !== 'text' && !validateMediaUrl(mediaType, mediaUrl) && !selectedFile)}
          className="btn-hover-effect"
        >
          <MessageCircle className="h-5 w-5 mr-2" />
          Send
        </Button>
      </div>
    </form>
  );
};

export default ChatInput;
