
import React from 'react';
import RoomCreation from '@/components/RoomCreation';

const Index = () => {
  return (
    <div className="flex flex-col h-screen max-w-2xl mx-auto bg-background">
      <div className="p-6 border-b">
        <h1 className="text-3xl font-bold text-center background-animate bg-clip-text text-transparent bg-gradient-to-r from-primary to-primary/60">
          Chat Room App
        </h1>
        <p className="text-center text-muted-foreground mt-2 max-w-md mx-auto">
          Create a new room or join an existing one to start chatting with friends, family, or colleagues in real-time.
        </p>
      </div>
      
      <div className="flex-1 p-6 flex flex-col items-center justify-center">
        <div className="w-full max-w-lg">
          <RoomCreation />
          
          <div className="mt-12 space-y-4">
            <h2 className="text-xl font-semibold text-center">Features</h2>
            <div className="grid md:grid-cols-2 gap-4 animate-fade-in">
              <div className="p-4 rounded-lg bg-accent/50 shadow-sm">
                <h3 className="font-medium mb-2">Real-time Chat</h3>
                <p className="text-sm text-muted-foreground">
                  Exchange messages instantly with other participants in the room.
                </p>
              </div>
              <div className="p-4 rounded-lg bg-accent/50 shadow-sm">
                <h3 className="font-medium mb-2">Media Sharing</h3>
                <p className="text-sm text-muted-foreground">
                  Share videos, music, YouTube links, and screenshots with others.
                </p>
              </div>
              <div className="p-4 rounded-lg bg-accent/50 shadow-sm">
                <h3 className="font-medium mb-2">Screen Sharing</h3>
                <p className="text-sm text-muted-foreground">
                  Capture and share your screen with a single click.
                </p>
              </div>
              <div className="p-4 rounded-lg bg-accent/50 shadow-sm">
                <h3 className="font-medium mb-2">User-Friendly</h3>
                <p className="text-sm text-muted-foreground">
                  Simple and intuitive interface for a seamless chat experience.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <footer className="border-t p-4">
        <p className="text-center text-sm text-muted-foreground">
          &copy; {new Date().getFullYear()} Chat Room App. All rights reserved.
        </p>
      </footer>
    </div>
  );
};

export default Index;
