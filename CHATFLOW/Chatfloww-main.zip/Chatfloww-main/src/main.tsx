
import { createRoot } from 'react-dom/client'
import App from './App.tsx'
import './index.css'
import { supabase } from "@/integrations/supabase/client";

// Setup global message cleanup function
const setupMessageCleanup = async () => {
  try {
    // Check for and delete messages older than 24 hours
    const twentyFourHoursAgo = new Date();
    twentyFourHoursAgo.setHours(twentyFourHoursAgo.getHours() - 24);
    
    const { error } = await supabase
      .from('chat_messages')
      .delete()
      .lt('created_at', twentyFourHoursAgo.toISOString());
    
    if (error) {
      console.error('Global message cleanup error:', error);
    } else {
      console.log('Cleaned up expired messages');
    }
  } catch (error) {
    console.error('Error in setupMessageCleanup:', error);
  }
};

// Run cleanup on app start
setupMessageCleanup();

// Set up a periodic cleanup every hour
setInterval(setupMessageCleanup, 60 * 60 * 1000);

createRoot(document.getElementById("root")!).render(<App />);
