
import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Calendar, MapPin, Building, FileText, Clock } from 'lucide-react';
import { Application } from '@/redux/slices/applicationsSlice';
import { format } from 'date-fns';

interface ViewApplicationDialogProps {
  application: Application | null;
  isOpen: boolean;
  onClose: () => void;
}

const ViewApplicationDialog = ({ application, isOpen, onClose }: ViewApplicationDialogProps) => {
  if (!application) return null;

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), 'PPP');
    } catch (e) {
      return dateString;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'accepted':
        return 'bg-green-100 text-green-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      case 'interview':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle className="text-2xl">Application Details</DialogTitle>
          <DialogDescription>
            Submitted on {formatDate(application.appliedDate || '')}
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-6">
          <div className="flex items-center gap-2">
            <Badge className={getStatusColor(application.status)}>
              {application.status.charAt(0).toUpperCase() + application.status.slice(1)}
            </Badge>
          </div>
          
          <div className="space-y-4">
            <div>
              <h3 className="font-medium text-gray-900 flex items-center gap-2">
                <Building className="h-4 w-4" /> Position
              </h3>
              <p className="mt-1 text-lg font-semibold">{application.jobTitle}</p>
            </div>
            
            <div>
              <h3 className="font-medium text-gray-900 flex items-center gap-2">
                <MapPin className="h-4 w-4" /> Company
              </h3>
              <p className="mt-1">{application.company}</p>
            </div>
            
            <div>
              <h3 className="font-medium text-gray-900 flex items-center gap-2">
                <Clock className="h-4 w-4" /> Applied On
              </h3>
              <p className="mt-1">{formatDate(application.appliedDate || '')}</p>
            </div>
            
            <Separator />
            
            {application.coverLetter && (
              <div>
                <h3 className="font-medium text-gray-900 flex items-center gap-2">
                  <FileText className="h-4 w-4" /> Cover Letter
                </h3>
                <div className="mt-2 p-3 bg-gray-50 rounded-md whitespace-pre-wrap text-gray-700">
                  {application.coverLetter}
                </div>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ViewApplicationDialog;
