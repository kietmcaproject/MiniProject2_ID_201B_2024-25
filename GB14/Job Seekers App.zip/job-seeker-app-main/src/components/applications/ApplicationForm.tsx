
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { supabase } from '@/lib/supabase';
import { Upload } from 'lucide-react';
import { useAppSelector } from '@/redux/hooks';

interface ApplicationFormProps {
  jobId: string;
  onSuccess?: () => void;
  onCancel?: () => void;
}

const ApplicationForm = ({ jobId, onSuccess, onCancel }: ApplicationFormProps) => {
  const [coverLetter, setCoverLetter] = useState('');
  const [resume, setResume] = useState<string>('');
  const [resumeFileName, setResumeFileName] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [profileExists, setProfileExists] = useState(false);
  const navigate = useNavigate();
  const { user } = useAppSelector(state => state.auth);

  useEffect(() => {
    // Check if user profile exists in the database
    const checkUserProfile = async () => {
      if (!user) return;
      
      try {
        const { data, error } = await supabase
          .from('profiles')
          .select('id')
          .eq('id', user.id)
          .maybeSingle(); // Changed from single() to maybeSingle() to handle non-existent profiles gracefully
        
        if (error && error.code !== 'PGRST116') { // PGRST116 is "no rows returned" error code
          console.error('Error checking profile:', error);
          setProfileExists(false);
        } else {
          setProfileExists(!!data); // Will be true if data exists, false otherwise
        }
      } catch (error) {
        console.error('Error checking profile:', error);
        setProfileExists(false);
      }
    };
    
    checkUserProfile();
  }, [user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!resume) {
      toast.error("Resume required", {
        description: "Please upload your resume before submitting",
        duration: 5000,
      });
      return;
    }

    if (!user) {
      navigate('/login');
      return;
    }

    setIsSubmitting(true);
    try {
      console.log('Preparing to submit application');
      console.log('Job ID:', jobId);
      console.log('User ID:', user.id);
      console.log('Resume data length:', resume.length);
      
      // Create or update profile entry
      const { data: profileData, error: profileError } = await supabase
        .from('profiles')
        .upsert({
          id: user.id,
          full_name: user.name || 'User',
          email: user.email,
          role: user.role
        }, {
          onConflict: 'id'
        })
        .select();
        
      if (profileError) {
        console.error('Error ensuring profile exists:', profileError);
        throw new Error('Unable to create user profile');
      }

      console.log('Profile created or updated successfully:', profileData);
      
      const applicationData = {
        job_id: jobId,
        user_id: user.id,
        cover_letter: coverLetter || '',
        resume: resume,
        status: 'pending',
        applied_date: new Date().toISOString()
      };
      
      console.log('Submitting application to Supabase...');
      
      const { data, error } = await supabase
        .from('applications')
        .insert([applicationData])
        .select()
        .single();

      if (error) {
        console.error('Supabase error details:', error);
        throw error;
      }

      console.log('Application submitted successfully:', data);
      
      toast.success("Application submitted", {
        description: "Your application has been successfully submitted",
        duration: 3000,
      });

      if (onSuccess) {
        onSuccess();
      }
    } catch (error: any) {
      console.error('Error submitting application:', error);
      toast.error("Error", {
        description: error.message || "Failed to submit application. Please try again.",
        duration: 5000,
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResumeUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) { // 5MB limit
      toast.error("File too large", {
        description: "Please upload a file smaller than 5MB",
        duration: 5000,
      });
      return;
    }

    try {
      // Set the file name
      setResumeFileName(file.name);
      console.log('File selected:', file.name);
      
      // Convert file to base64
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target && typeof e.target.result === 'string') {
          const base64String = e.target.result;
          setResume(base64String);
          console.log('Resume successfully converted to base64. Length:', base64String.length);
        } else {
          console.error('Error reading file: Invalid result type');
          toast.error("Error", {
            description: "Failed to process file. Please try again.",
            duration: 5000,
          });
        }
      };
      
      reader.onerror = (error) => {
        console.error('Error reading file:', error);
        toast.error("Error", {
          description: "Failed to read file. Please try again.",
          duration: 5000,
        });
      };
      
      reader.readAsDataURL(file);
    } catch (error) {
      console.error('Error uploading resume:', error);
      toast.error("Error", {
        description: "Failed to upload resume. Please try again.",
        duration: 5000,
      });
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Cover Letter (Optional)
        </label>
        <Textarea
          value={coverLetter}
          onChange={(e) => setCoverLetter(e.target.value)}
          placeholder="Write a cover letter to introduce yourself..."
          className="min-h-[200px]"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Resume (Required)
        </label>
        <div className="mt-1 flex items-center">
          <input
            type="file"
            accept=".pdf,.doc,.docx"
            onChange={handleResumeUpload}
            className="hidden"
            id="resume-upload"
          />
          <label
            htmlFor="resume-upload"
            className="cursor-pointer inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            <Upload className="h-5 w-5 mr-2" />
            {resumeFileName ? "Change Resume" : "Upload Resume"}
          </label>
          {resumeFileName && (
            <span className="ml-3 text-sm text-green-600">
              {resumeFileName} uploaded successfully
            </span>
          )}
        </div>
      </div>

      <div className="flex justify-end space-x-4">
        {onCancel && (
          <Button
            type="button"
            variant="outline"
            onClick={onCancel}
            disabled={isSubmitting}
          >
            Cancel
          </Button>
        )}
        <Button type="submit" disabled={isSubmitting || !resume}>
          {isSubmitting ? "Submitting..." : "Submit Application"}
        </Button>
      </div>
    </form>
  );
};

export default ApplicationForm;
