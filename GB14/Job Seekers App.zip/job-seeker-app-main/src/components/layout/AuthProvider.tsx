
import React, { useEffect, useState } from 'react';
import { useAppSelector, useAppDispatch } from '@/redux/hooks';
import { loginSuccess, logout } from '@/redux/slices/authSlice';
import { supabase } from '@/lib/supabase';
import { toast } from "sonner";

interface AuthProviderProps {
  children: React.ReactNode;
}

export const AuthProvider = ({ children }: AuthProviderProps) => {
  const { isAuthenticated } = useAppSelector(state => state.auth);
  const dispatch = useAppDispatch();
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    console.log("Setting up auth state listener");
    
    // Set up auth state listener first
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      console.log('Auth state changed event:', event);
      
      if (event === 'SIGNED_IN' && session) {
        // Extract user metadata and determine role
        const userRole = session.user.user_metadata?.role || session.user.user_metadata?.preferred_role || 'jobseeker';
        console.log('User role from metadata:', userRole);
        
        dispatch(loginSuccess({
          id: session.user.id,
          name: session.user.user_metadata?.full_name || session.user.user_metadata?.name || 'User',
          email: session.user.email || '',
          role: userRole
        }));
      } else if (event === 'SIGNED_OUT') {
        dispatch(logout());
      }
    });
    
    // Then check for existing session
    const checkSession = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        console.log("Current session on init:", session);
        
        if (session) {
          // Extract user metadata and determine role
          const userRole = session.user.user_metadata?.role || session.user.user_metadata?.preferred_role || 'jobseeker';
          console.log('User role from session metadata:', userRole);
          
          dispatch(loginSuccess({
            id: session.user.id,
            name: session.user.user_metadata?.full_name || session.user.user_metadata?.name || 'User',
            email: session.user.email || '',
            role: userRole
          }));
        } else {
          // Ensure we reset to logged out state if no session
          dispatch(logout());
        }
        setLoading(false);
      } catch (error) {
        console.error("Error checking session:", error);
        setLoading(false);
      }
    };
    
    // Check session immediately
    checkSession();

    // Clean up subscription when component unmounts
    return () => {
      subscription.unsubscribe();
    };
  }, [dispatch]);

  // Log auth state changes for debugging
  useEffect(() => {
    console.log("AuthProvider - Auth state changed:", { isAuthenticated });
  }, [isAuthenticated]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
        <div className="ml-3">Loading authentication...</div>
      </div>
    );
  }

  return <>{children}</>;
};

export default AuthProvider;
