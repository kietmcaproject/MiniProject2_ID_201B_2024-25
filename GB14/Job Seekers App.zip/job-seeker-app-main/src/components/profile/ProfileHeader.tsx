
import React from 'react';
import { User } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface ProfileHeaderProps {
  profile: any;
}

const ProfileHeader: React.FC<ProfileHeaderProps> = ({ profile }) => {
  return (
    <Card className="mb-8">
      <CardHeader className="bg-card/5 pb-2">
        <CardTitle className="flex items-center gap-2 text-2xl">
          <User className="h-6 w-6" />
          My Profile
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-6">
        <div className="flex flex-col sm:flex-row items-center gap-6">
          <div className="bg-muted rounded-full p-6 flex items-center justify-center">
            <User className="h-20 w-20 text-muted-foreground" />
          </div>
          <div className="space-y-2 text-center sm:text-left">
            <h2 className="text-2xl font-bold">{profile?.full_name || 'User'}</h2>
            <p className="text-muted-foreground">{profile?.email}</p>
            <div className="inline-block px-3 py-1 bg-primary/10 text-primary rounded-full text-sm font-medium capitalize">
              {profile?.role || 'User'}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ProfileHeader;
