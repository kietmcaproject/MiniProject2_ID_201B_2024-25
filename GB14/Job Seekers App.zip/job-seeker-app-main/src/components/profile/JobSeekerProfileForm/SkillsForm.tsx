
import React from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface SkillsFormProps {
  profile: any;
  formData: {
    skills: string[];
  };
  isEditing: boolean;
  skillInput: string;
  setSkillInput: React.Dispatch<React.SetStateAction<string>>;
  handleAddSkill: () => void;
  handleRemoveSkill: (skill: string) => void;
}

const SkillsForm: React.FC<SkillsFormProps> = ({
  profile,
  formData,
  isEditing,
  skillInput,
  setSkillInput,
  handleAddSkill,
  handleRemoveSkill
}) => {
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-md">Skills</CardTitle>
      </CardHeader>
      <CardContent>
        {isEditing ? (
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Input 
                value={skillInput}
                onChange={(e) => setSkillInput(e.target.value)}
                placeholder="Add a skill"
                className="flex-1"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddSkill();
                  }
                }}
              />
              <Button type="button" onClick={handleAddSkill} size="sm">Add</Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {formData.skills && formData.skills.map((skill: string, index: number) => (
                <span 
                  key={index}
                  className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm flex items-center gap-2"
                >
                  {skill}
                  <button 
                    type="button"
                    onClick={() => handleRemoveSkill(skill)}
                    className="hover:bg-primary/20 rounded-full"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
          </div>
        ) : (
          <div>
            {profile?.skills && profile.skills.length > 0 ? (
              <div className="flex flex-wrap gap-2">
                {profile.skills.map((skill: string, index: number) => (
                  <span 
                    key={index}
                    className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground italic">No skills added yet</p>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default SkillsForm;
