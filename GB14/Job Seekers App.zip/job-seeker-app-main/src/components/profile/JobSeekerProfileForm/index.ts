
import JobSeekerProfileForm from '../JobSeekerProfileForm';

export default JobSeekerProfileForm;
export { default as PersonalInfoForm } from './PersonalInfoForm';
export { default as SkillsForm } from './SkillsForm';
export { default as ResumeForm } from './ResumeForm';
