
import React from 'react';
import { FileText } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface ResumeFormProps {
  profile: any;
  formData: {
    resume_url: string;
  };
  handleChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
  isEditing: boolean;
}

const ResumeForm: React.FC<ResumeFormProps> = ({
  profile,
  formData,
  handleChange,
  isEditing
}) => {
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-md">Resume</CardTitle>
      </CardHeader>
      <CardContent>
        {isEditing ? (
          <div className="space-y-2">
            <label htmlFor="resume_url" className="text-sm font-medium">Resume URL</label>
            <Input 
              id="resume_url"
              name="resume_url"
              value={formData.resume_url}
              onChange={handleChange}
              placeholder="Link to your resume"
            />
            <p className="text-sm text-muted-foreground">
              Enter a link to your resume hosted on Google Drive, Dropbox, or other cloud storage.
            </p>
          </div>
        ) : (
          <div className="space-y-2">
            {profile?.resume_url ? (
              <div className="flex gap-2">
                <FileText className="h-5 w-5" />
                <a 
                  href={profile.resume_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary hover:underline"
                >
                  View Resume
                </a>
              </div>
            ) : (
              <p className="text-muted-foreground italic">No resume added yet</p>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ResumeForm;
