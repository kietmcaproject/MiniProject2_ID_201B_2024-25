
import React from 'react';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Globe, MapPin } from 'lucide-react';

interface CompanyInfoFormProps {
  profile: any;
  formData: {
    company_name: string;
    company_website: string;
    company_location: string;
    company_description: string;
  };
  handleChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
  isEditing: boolean;
}

const CompanyInfoForm: React.FC<CompanyInfoFormProps> = ({
  profile,
  formData,
  handleChange,
  isEditing
}) => {
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-md">Company Information</CardTitle>
      </CardHeader>
      <CardContent>
        {isEditing ? (
          <div className="space-y-4">
            <div className="space-y-2">
              <label htmlFor="company_name" className="text-sm font-medium">Company Name</label>
              <Input 
                id="company_name"
                name="company_name"
                value={formData.company_name}
                onChange={handleChange}
                placeholder="Your company's name"
              />
            </div>
            
            <div className="space-y-2">
              <label htmlFor="company_website" className="text-sm font-medium">Company Website</label>
              <Input 
                id="company_website"
                name="company_website"
                value={formData.company_website}
                onChange={handleChange}
                placeholder="https://www.example.com"
                type="url"
              />
            </div>
            
            <div className="space-y-2">
              <label htmlFor="company_location" className="text-sm font-medium">Company Location</label>
              <Input 
                id="company_location"
                name="company_location"
                value={formData.company_location}
                onChange={handleChange}
                placeholder="City, Country"
              />
            </div>
            
            <div className="space-y-2">
              <label htmlFor="company_description" className="text-sm font-medium">Company Description</label>
              <Textarea 
                id="company_description"
                name="company_description"
                value={formData.company_description}
                onChange={handleChange}
                placeholder="Tell us about your company"
                rows={5}
              />
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Company Name</h3>
              <p>{profile?.company_name || 'Not specified'}</p>
            </div>
            
            {profile?.company_website && (
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Website</h3>
                <a href={profile.company_website} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline flex items-center gap-1">
                  <Globe className="h-4 w-4" />
                  {profile.company_website}
                </a>
              </div>
            )}
            
            {profile?.company_location && (
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Location</h3>
                <p className="flex items-center gap-1">
                  <MapPin className="h-4 w-4" />
                  {profile.company_location}
                </p>
              </div>
            )}
            
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Company Description</h3>
              <p className="whitespace-pre-wrap">{profile?.company_description || 'No description added yet'}</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default CompanyInfoForm;
