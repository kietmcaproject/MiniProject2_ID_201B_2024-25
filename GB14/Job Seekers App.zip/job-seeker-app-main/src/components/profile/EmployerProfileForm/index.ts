
import PersonalInfoForm from './PersonalInfoForm';
import CompanyInfoForm from './CompanyInfoForm';

export { PersonalInfoForm, CompanyInfoForm };
