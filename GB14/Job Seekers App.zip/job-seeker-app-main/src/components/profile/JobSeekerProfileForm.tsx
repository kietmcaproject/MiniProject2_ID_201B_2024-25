import React, { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/components/ui/use-toast';
import { useAppSelector } from '@/redux/hooks';
import { Edit, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import PersonalInfoForm from './JobSeekerProfileForm/PersonalInfoForm';
import SkillsForm from './JobSeekerProfileForm/SkillsForm';
import ResumeForm from './JobSeekerProfileForm/ResumeForm';

interface JobSeekerProfileFormProps {
  profile: any;
  setProfile: React.Dispatch<React.SetStateAction<any>>;
}

const JobSeekerProfileForm: React.FC<JobSeekerProfileFormProps> = ({ profile, setProfile }) => {
  const { user } = useAppSelector(state => state.auth);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    full_name: profile?.full_name || '',
    bio: profile?.bio || '',
    skills: profile?.skills || [],
    resume_url: profile?.resume_url || ''
  });

  const [skillInput, setSkillInput] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleAddSkill = () => {
    if (skillInput.trim() && !formData.skills.includes(skillInput.trim())) {
      setFormData(prev => ({
        ...prev,
        skills: [...(prev.skills || []), skillInput.trim()]
      }));
      setSkillInput('');
    }
  };

  const handleRemoveSkill = (skillToRemove: string) => {
    setFormData(prev => ({
      ...prev,
      skills: (prev.skills || []).filter((skill: string) => skill !== skillToRemove)
    }));
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    try {
      setIsSubmitting(true);

      const { error } = await supabase
        .from('profiles')
        .update({
          full_name: formData.full_name,
          bio: formData.bio,
          skills: formData.skills,
          resume_url: formData.resume_url,
          updated_at: new Date().toISOString()
        })
        .eq('id', user?.id);

      if (error) throw error;

      setProfile({ ...profile, ...formData, updated_at: new Date().toISOString() });
      setIsEditing(false);
      
      toast.success({
        title: "Profile updated",
        description: "Your profile has been successfully updated.",
      });
      
    } catch (error: any) {
      toast.error({
        title: "Error updating profile",
        description: error.message || "Failed to update profile",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold">Job Seeker Profile</h2>
        {!isEditing ? (
          <Button 
            onClick={() => setIsEditing(true)} 
            variant="outline"
            className="flex items-center gap-2"
          >
            <Edit className="h-4 w-4" />
            Edit Profile
          </Button>
        ) : null}
      </div>

      <Tabs defaultValue="personal" className="w-full">
        <TabsList>
          <TabsTrigger value="personal">Personal Info</TabsTrigger>
          <TabsTrigger value="skills">Skills</TabsTrigger>
          <TabsTrigger value="resume">Resume</TabsTrigger>
        </TabsList>

        <TabsContent value="personal" className="mt-4">
          <PersonalInfoForm 
            profile={profile}
            formData={formData}
            handleChange={handleChange}
            isEditing={isEditing}
          />
        </TabsContent>

        <TabsContent value="skills" className="mt-4">
          <SkillsForm
            profile={profile}
            formData={formData}
            isEditing={isEditing}
            skillInput={skillInput}
            setSkillInput={setSkillInput}
            handleAddSkill={handleAddSkill}
            handleRemoveSkill={handleRemoveSkill}
          />
        </TabsContent>

        <TabsContent value="resume" className="mt-4">
          <ResumeForm
            profile={profile}
            formData={formData}
            handleChange={handleChange}
            isEditing={isEditing}
          />
        </TabsContent>
      </Tabs>

      {isEditing && (
        <div className="flex justify-end gap-4">
          <Button 
            variant="outline" 
            onClick={() => {
              setIsEditing(false);
              setFormData({
                full_name: profile?.full_name || '',
                bio: profile?.bio || '',
                skills: profile?.skills || [],
                resume_url: profile?.resume_url || ''
              });
            }}
            disabled={isSubmitting}
          >
            Cancel
          </Button>
          <Button 
            type="submit"
            form="profile-form"
            disabled={isSubmitting}
            className="flex items-center gap-2"
          >
            {isSubmitting ? 'Saving...' : (
              <>
                <Save className="h-4 w-4" />
                Save Changes
              </>
            )}
          </Button>
        </div>
      )}

      {/* Hidden form to handle submit */}
      <form id="profile-form" onSubmit={handleSubmit} className="hidden"></form>
    </div>
  );
};

export default JobSeekerProfileForm;
