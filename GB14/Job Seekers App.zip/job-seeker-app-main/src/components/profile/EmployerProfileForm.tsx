import React, { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/components/ui/use-toast';
import { useAppSelector } from '@/redux/hooks';
import { Edit, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PersonalInfoForm, CompanyInfoForm } from './EmployerProfileForm/index';

interface EmployerProfileFormProps {
  profile: any;
  setProfile: React.Dispatch<React.SetStateAction<any>>;
}

const EmployerProfileForm: React.FC<EmployerProfileFormProps> = ({ profile, setProfile }) => {
  const { user } = useAppSelector(state => state.auth);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    full_name: profile?.full_name || '',
    bio: profile?.bio || '',
    company_name: profile?.company_name || '',
    company_website: profile?.company_website || '',
    company_location: profile?.company_location || '',
    company_description: profile?.company_description || '',
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    try {
      setIsSubmitting(true);

      const { error } = await supabase
        .from('profiles')
        .update({
          full_name: formData.full_name,
          bio: formData.bio,
          company_name: formData.company_name,
          company_website: formData.company_website,
          company_location: formData.company_location,
          company_description: formData.company_description,
          updated_at: new Date().toISOString()
        })
        .eq('id', user?.id);

      if (error) throw error;

      setProfile({ ...profile, ...formData, updated_at: new Date().toISOString() });
      setIsEditing(false);
      
      toast({
        title: "Profile updated",
        description: "Your employer profile has been successfully updated.",
      });
      
    } catch (error: any) {
      toast({
        title: "Error updating profile",
        description: error.message || "Failed to update profile",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold">Employer Profile</h2>
        {!isEditing ? (
          <Button 
            onClick={() => setIsEditing(true)} 
            variant="outline"
            className="flex items-center gap-2"
          >
            <Edit className="h-4 w-4" />
            Edit Profile
          </Button>
        ) : null}
      </div>

      <Tabs defaultValue="personal" className="w-full">
        <TabsList>
          <TabsTrigger value="personal">Personal Info</TabsTrigger>
          <TabsTrigger value="company">Company Details</TabsTrigger>
        </TabsList>

        <TabsContent value="personal" className="mt-4">
          <PersonalInfoForm
            profile={profile}
            formData={formData}
            handleChange={handleChange}
            isEditing={isEditing}
          />
        </TabsContent>

        <TabsContent value="company" className="mt-4">
          <CompanyInfoForm
            profile={profile}
            formData={formData}
            handleChange={handleChange}
            isEditing={isEditing}
          />
        </TabsContent>
      </Tabs>

      {isEditing && (
        <div className="flex justify-end gap-4">
          <Button 
            variant="outline" 
            onClick={() => {
              setIsEditing(false);
              setFormData({
                full_name: profile?.full_name || '',
                bio: profile?.bio || '',
                company_name: profile?.company_name || '',
                company_website: profile?.company_website || '',
                company_location: profile?.company_location || '',
                company_description: profile?.company_description || '',
              });
            }}
            disabled={isSubmitting}
          >
            Cancel
          </Button>
          <Button 
            type="submit"
            form="profile-form"
            disabled={isSubmitting}
            className="flex items-center gap-2"
          >
            {isSubmitting ? 'Saving...' : (
              <>
                <Save className="h-4 w-4" />
                Save Changes
              </>
            )}
          </Button>
        </div>
      )}
      
      {/* Hidden form to handle the submit action */}
      <form id="profile-form" onSubmit={handleSubmit} className="hidden" />
    </div>
  );
};

export default EmployerProfileForm;
