
// Re-export the hook implementation
import { useToast as useToastHook, type ToasterToast } from "@/hooks/use-toast";
import { type ToastActionElement } from "@/components/ui/toast";

// Re-export the hook
export const useToast = useToastHook;

// Create a toast function that can be imported and used
// This is not a React hook, but a function that creates toast instances
export type ToastProps = {
  title?: React.ReactNode;
  description?: React.ReactNode;
  action?: ToastActionElement;
  variant?: "default" | "destructive";
};

const createToast = (props: ToastProps) => {
  // Get toast function from a component that has mounted the ToastProvider
  const toaster = document.querySelector("[data-toast-provider]") as HTMLElement;
  if (toaster) {
    const event = new CustomEvent("toast", {
      detail: props,
    });
    toaster.dispatchEvent(event);
  } else {
    console.warn(
      "Toast was triggered but no toast provider was found. Make sure <Toaster /> is added to your app."
    );
  }
};

// Create the toast function object with methods
export const toast = {
  // Call the toast function directly for default variant
  ...(((props: ToastProps) => createToast(props)) as any),
  
  // Success variant shorthand
  success: (props: { title?: React.ReactNode; description?: React.ReactNode }) => {
    createToast({ ...props, variant: "default" });
  },

  // Error variant shorthand
  error: (props: { title?: React.ReactNode; description?: React.ReactNode }) => {
    createToast({ ...props, variant: "destructive" });
  },

  // Dismiss method
  dismiss: (toastId?: string) => {
    const toaster = document.querySelector("[data-toast-provider]") as HTMLElement;
    if (toaster) {
      const event = new CustomEvent("toast-dismiss", {
        detail: { toastId },
      });
      toaster.dispatchEvent(event);
    }
  },
};
