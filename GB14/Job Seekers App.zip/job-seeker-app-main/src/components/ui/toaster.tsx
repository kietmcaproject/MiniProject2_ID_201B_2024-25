
import { useToast } from "@/hooks/use-toast"
import {
  Toast,
  ToastClose,
  ToastDescription,
  ToastProvider,
  ToastTitle,
  ToastViewport,
} from "@/components/ui/toast"
import { useEffect, useRef } from "react"

export function Toaster() {
  const { toasts, toast, dismiss } = useToast()
  const providerRef = useRef<HTMLDivElement>(null)

  // Set up event listeners for the toast events
  useEffect(() => {
    const provider = providerRef.current
    if (!provider) return
    
    // Add a data attribute to find this provider
    provider.setAttribute("data-toast-provider", "true")
    
    // Listen for toast events
    const handleToast = (event: CustomEvent) => {
      toast(event.detail)
    }
    
    // Listen for dismiss events
    const handleDismiss = (event: CustomEvent) => {
      dismiss(event.detail?.toastId)
    }
    
    // Add event listeners
    provider.addEventListener("toast", handleToast as EventListener)
    provider.addEventListener("toast-dismiss", handleDismiss as EventListener)
    
    // Clean up
    return () => {
      provider.removeEventListener("toast", handleToast as EventListener)
      provider.removeEventListener("toast-dismiss", handleDismiss as EventListener)
      provider.removeAttribute("data-toast-provider")
    }
  }, [toast, dismiss])

  return (
    <div ref={providerRef}>
      <ToastProvider>
        {toasts.map(function ({ id, title, description, action, ...props }) {
          return (
            <Toast key={id} {...props}>
              <div className="grid gap-1">
                {title && <ToastTitle>{title}</ToastTitle>}
                {description && (
                  <ToastDescription>{description}</ToastDescription>
                )}
              </div>
              {action}
              <ToastClose />
            </Toast>
          )
        })}
        <ToastViewport />
      </ToastProvider>
    </div>
  )
}
