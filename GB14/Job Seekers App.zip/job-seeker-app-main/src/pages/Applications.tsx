
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Briefcase } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from "sonner";
import Layout from '@/components/layout/Layout';
import { useAppDispatch, useAppSelector } from '@/redux/hooks';
import { 
  fetchApplicationsStart,
  fetchApplicationsSuccess,
  fetchApplicationsFail,
  updateApplicationStatus,
  Application
} from '@/redux/slices/applicationsSlice';
import ApplicationsTable from '@/components/applications/ApplicationsTable';
import ViewApplicationDialog from '@/components/applications/ViewApplicationDialog';
import { supabase } from '@/lib/supabase';

const Applications = () => {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const { applications, loading, error } = useAppSelector(state => state.applications);
  const { isAuthenticated, user } = useAppSelector(state => state.auth);
  
  const [selectedApplication, setSelectedApplication] = useState<Application | null>(null);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [dataFetchAttempted, setDataFetchAttempted] = useState(false);

  useEffect(() => {
    console.log("Applications page - Auth state:", { isAuthenticated, user, dataFetchAttempted });
    
    if (!isAuthenticated) {
      if (dataFetchAttempted) {
        toast.error("Authentication required", {
          description: "Please log in to view your applications"
        });
        navigate('/login');
      }
      return;
    }

    const fetchApplications = async () => {
      setDataFetchAttempted(true);
      dispatch(fetchApplicationsStart());
      
      try {
        let query = supabase
          .from('applications')
          .select(`
            *,
            jobs (
              title,
              company
            )
          `);

        // Filter based on user role
        if (user?.role === 'jobseeker') {
          query = query.eq('user_id', user.id);
        } else if (user?.role === 'employer') {
          // For employers, we need to join with jobs to get their applications
          query = query.eq('jobs.employer_id', user.id);
        }

        const { data, error } = await query;

        if (error) throw error;
        
        console.log("Applications data:", data);

        if (data) {
          // Transform the data to match our Application type
          const transformedApplications = data.map(app => ({
            id: app.id,
            jobId: app.job_id,
            userId: app.user_id,
            jobTitle: app.jobs?.title || 'Unknown Job',
            company: app.jobs?.company || 'Unknown Company',
            status: app.status,
            appliedDate: app.applied_date,
            resume: app.resume,
            coverLetter: app.cover_letter
          }));

          dispatch(fetchApplicationsSuccess(transformedApplications));
        } else {
          dispatch(fetchApplicationsSuccess([]));
        }
      } catch (error: any) {
        console.error('Error fetching applications:', error);
        dispatch(fetchApplicationsFail(error.message || "Failed to fetch applications"));
        toast.error("Error", {
          description: "Failed to fetch applications. Please try again."
        });
      }
    };

    fetchApplications();
  }, [dispatch, isAuthenticated, navigate, user]);

  const handleUpdateStatus = async (applicationId: string, newStatus: Application['status']) => {
    try {
      const { error } = await supabase
        .from('applications')
        .update({ status: newStatus })
        .eq('id', applicationId);

      if (error) throw error;

      dispatch(updateApplicationStatus({ id: applicationId, status: newStatus }));
      toast.success("Status updated", {
        description: `Application status has been updated to ${newStatus}`
      });
    } catch (error: any) {
      console.error('Error updating application status:', error);
      toast.error("Error", {
        description: "Failed to update application status. Please try again."
      });
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-12 flex justify-center">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-blue-500 border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]" />
          <div className="ml-3">Loading applications...</div>
        </div>
      </Layout>
    );
  }

  if (error) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-12">
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded relative" role="alert">
            <strong className="font-bold">Error:</strong>
            <span className="block sm:inline"> {error}</span>
            <Button 
              onClick={() => window.location.reload()}
              variant="outline"
              className="mt-2"
            >
              Try Again
            </Button>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-12">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">
            {user?.role === 'employer' ? 'Manage Applications' : 'My Applications'}
          </h1>
          <p className="text-gray-600">
            {user?.role === 'employer' 
              ? 'Review and manage applications for your job postings'
              : 'Track the status of your job applications'}
          </p>
        </div>

        {applications.length > 0 ? (
          <ApplicationsTable 
            applications={applications}
            onViewApplication={(app) => {
              setSelectedApplication(app);
              setViewDialogOpen(true);
            }}
            onUpdateStatus={user?.role === 'employer' ? handleUpdateStatus : undefined}
          />
        ) : (
          <div className="bg-white rounded-lg shadow-sm border p-12 text-center">
            <Briefcase className="h-16 w-16 mx-auto text-gray-300 mb-4" />
            <h3 className="text-xl font-semibold mb-2">No Applications Yet</h3>
            <p className="text-gray-600 mb-6">
              {user?.role === 'employer'
                ? "You haven't received any applications yet."
                : "You haven't applied for any jobs yet."}
            </p>
            <Button 
              className="bg-job-blue hover:bg-job-blue-light"
              onClick={() => navigate('/jobs')}
            >
              {user?.role === 'employer' ? 'Post a Job' : 'Browse Jobs'}
            </Button>
          </div>
        )}

        <ViewApplicationDialog
          application={selectedApplication}
          isOpen={viewDialogOpen}
          onClose={() => {
            setViewDialogOpen(false);
            setSelectedApplication(null);
          }}
        />
      </div>
    </Layout>
  );
};

export default Applications;
