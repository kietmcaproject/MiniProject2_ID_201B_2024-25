
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppSelector } from '@/redux/hooks';
import { fetchUserProfile } from '@/services/profileService';
import { signOut as signOutAction } from '@/services/authService';
import { useAppDispatch } from '@/redux/hooks';
import { logout } from '@/redux/slices/authSlice';
import JobSeekerProfileForm from '@/components/profile/JobSeekerProfileForm';
import EmployerProfileForm from '@/components/profile/EmployerProfileForm';
import { Button } from '@/components/ui/button';
import { toast } from "@/components/ui/use-toast";

const Profile = () => {
  const { user, isAuthenticated } = useAppSelector(state => state.auth);
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const [profile, setProfile] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }

    const loadProfile = async () => {
      setIsLoading(true);
      try {
        // No need to fetch the profile again here, it should be in Redux state
        // But if you do need to refresh it, you can uncomment the following lines:
        // await fetchUserProfile(user, dispatch);
        // setProfile(user); // Assuming fetchUserProfile dispatches loginSuccess with the profile data
        setProfile(user);
      } catch (error) {
        console.error("Failed to load profile:", error);
        toast.error({
          title: "Error",
          description: "Failed to load profile. Please try again.",
        });
      } finally {
        setIsLoading(false);
      }
    };

    loadProfile();
  }, [isAuthenticated, navigate, dispatch, user]);

  const signOut = async () => {
    try {
      await signOutAction();
      dispatch(logout());
      navigate('/login');
    } catch (error) {
      console.error("Sign out failed:", error);
      toast.error({
        title: "Sign Out Failed",
        description: "Failed to sign out. Please try again.",
      });
    }
  };

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (!profile) {
    return <div>Failed to load profile. Please try again.</div>;
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-2xl font-bold mb-4">Profile</h1>
      {user?.role === 'jobseeker' && (
        <JobSeekerProfileForm profile={profile} setProfile={setProfile} />
      )}
      {user?.role === 'employer' && (
        <EmployerProfileForm profile={profile} setProfile={setProfile} />
      )}
      <Button onClick={signOut} variant="destructive">Sign Out</Button>
    </div>
  );
};

export default Profile;
