import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calendar, DollarSign, MapPin, Briefcase } from 'lucide-react';
import ApplicationForm from '@/components/applications/ApplicationForm';
import { toast } from "@/components/ui/use-toast";

const JobDetail = () => {
  const { id } = useParams<{ id: string }>();
  const [job, setJob] = useState<any>(null);
  const [isApplying, setIsApplying] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchJob = async () => {
      if (!id) {
        console.error('Job ID is missing.');
        return;
      }

      try {
        const { data, error } = await supabase
          .from('jobs')
          .select('*')
          .eq('id', id)
          .single();

        if (error) {
          console.error('Error fetching job:', error);
          toast.error({
            title: "Error fetching job",
            description: error.message || "Failed to load job details",
          });
        }

        if (data) {
          setJob(data);
        } else {
          console.log('Job not found');
          toast.error({
            title: "Job not found",
            description: "The job you are looking for does not exist.",
          });
          navigate('/jobs');
        }
      } catch (error: any) {
        console.error('Unexpected error:', error);
        toast.error({
          title: "Unexpected error",
          description: error.message || "An unexpected error occurred",
        });
      }
    };

    fetchJob();
  }, [id, navigate]);

  if (!job) {
    return <div>Loading job details...</div>;
  }

  const handleApplyClick = () => {
    setIsApplying(true);
  };

  const handleApplicationSuccess = () => {
    setIsApplying(false);
    toast.success({
      title: "Application submitted",
      description: "Your application has been successfully submitted",
    });
    navigate('/jobs');
  };

  const handleApplicationCancel = () => {
    setIsApplying(false);
  };

  return (
    <div className="container mx-auto mt-8 p-4">
      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle className="text-2xl font-bold">{job.title}</CardTitle>
          <CardDescription>{job.company}</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4">
          <div className="flex items-center space-x-2">
            <Badge variant="secondary">{job.type}</Badge>
            <Badge variant="outline">{job.category}</Badge>
          </div>
          <div className="flex items-center space-x-2 text-gray-600">
            <MapPin className="h-4 w-4" />
            <span>{job.location}</span>
          </div>
          <div className="flex items-center space-x-2 text-gray-600">
            <DollarSign className="h-4 w-4" />
            <span>{job.salary}</span>
          </div>
          <div className="flex items-center space-x-2 text-gray-600">
            <Calendar className="h-4 w-4" />
            <span>Posted on: {new Date(job.created_at).toLocaleDateString()}</span>
          </div>
          <div className="flex items-center space-x-2 text-gray-600">
            <Briefcase className="h-4 w-4" />
            <span>Experience: {job.experience}</span>
          </div>
          <div>
            <h3 className="text-lg font-semibold">Job Description</h3>
            <p className="text-gray-700">{job.description}</p>
          </div>
          <div>
            <h3 className="text-lg font-semibold">Responsibilities</h3>
            <ul className="list-disc pl-5 text-gray-700">
              {job.responsibilities?.map((responsibility: string, index: number) => (
                <li key={index}>{responsibility}</li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold">Requirements</h3>
            <ul className="list-disc pl-5 text-gray-700">
              {job.requirements?.map((requirement: string, index: number) => (
                <li key={index}>{requirement}</li>
              ))}
            </ul>
          </div>
        </CardContent>
        {!isApplying ? (
          <div className="p-4">
            <Button onClick={handleApplyClick} className="w-full">
              Apply Now
            </Button>
          </div>
        ) : (
          <CardContent className="p-4">
            <h3 className="text-xl font-semibold mb-4">Application Form</h3>
            <ApplicationForm
              jobId={id}
              onSuccess={handleApplicationSuccess}
              onCancel={handleApplicationCancel}
            />
          </CardContent>
        )}
      </Card>
    </div>
  );
};

export default JobDetail;
