
import { createClient } from '@supabase/supabase-js';
import { toast } from "sonner";

// Use the same values as in src/integrations/supabase/client.ts
const supabaseUrl = "https://ywudgkmrbbwpcbvlakrb.supabase.co";
const supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inl3dWRna21yYmJ3cGNidmxha3JiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDQyNzE3NjksImV4cCI6MjA1OTg0Nzc2OX0.ng6SmC8e2fG67UrUgjZ3eWKH9fnegdmwJdJGC8k8XjQ";

// Create a single Supabase client instance with explicit auth settings
export const supabase = createClient(supabaseUrl, supabaseKey, {
  auth: {
    storage: localStorage,
    persistSession: true,
    autoRefreshToken: true,
  }
});

// Set up auth state change listener
supabase.auth.onAuthStateChange((event, session) => {
  console.log('Auth state changed:', event, session?.user?.id);
  
  if (event === 'SIGNED_OUT') {
    toast.success("Signed out successfully", {
      duration: 3000, // Auto dismiss after 3 seconds
    });
  }

  if (event === 'SIGNED_IN' && session) {
    toast.success("Signed in successfully", {
      duration: 3000, // Auto dismiss after 3 seconds
    });
  }
});
