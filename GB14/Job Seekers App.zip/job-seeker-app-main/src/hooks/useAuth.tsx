
import { useState } from 'react';
import { useAppDispatch } from '@/redux/hooks';
import { supabase } from '@/lib/supabase'; 
import { loginStart, loginFail } from '@/redux/slices/authSlice';
import { toast } from "sonner";

type AuthResponse = {
  success: boolean;
  error?: any;
};

export const useAuth = () => {
  const [loading, setLoading] = useState(false);
  const dispatch = useAppDispatch();

  const signIn = async (email: string, password: string): Promise<AuthResponse> => {
    dispatch(loginStart());
    setLoading(true);
    
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
      });
      
      if (error) {
        dispatch(loginFail(error.message));
        toast.error("Login failed", {
          description: error.message,
          duration: 5000, // Error messages stay a bit longer
        });
        setLoading(false);
        return { success: false, error: error.message };
      }

      // Auth state change listener will handle updating the Redux store
      console.log("Sign in successful", data);
      
      setLoading(false);
      return { success: true };
    } catch (error: any) {
      dispatch(loginFail(error.message));
      toast.error("Login failed", {
        description: error.message || "An unexpected error occurred",
        duration: 5000, // Error messages stay a bit longer
      });
      setLoading(false);
      return { success: false, error };
    }
  };

  const signUp = async (email: string, password: string, name: string, role: string): Promise<AuthResponse> => {
    setLoading(true);
    
    try {
      console.log(`Signing up with role: ${role}`);
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            name,
            full_name: name,
            role, // Ensure role is correctly stored in user metadata
            preferred_role: role // Store as alternate field for backward compatibility
          }
        }
      });
      
      if (error) {
        toast.error("Registration failed", {
          description: error.message,
          duration: 5000, // Error messages stay a bit longer
        });
        setLoading(false);
        return { success: false, error: error.message };
      }

      toast.success("Registration successful", {
        description: "Please check your email to verify your account",
        duration: 5000, // Success messages with instructions stay a bit longer
      });
      
      setLoading(false);
      return { success: true };
    } catch (error: any) {
      toast.error("Registration failed", {
        description: error.message || "An unexpected error occurred",
        duration: 5000, // Error messages stay a bit longer
      });
      setLoading(false);
      return { success: false, error };
    }
  };

  const signOut = async (): Promise<AuthResponse> => {
    setLoading(true);
    console.log("Signing out");
    
    try {
      const { error } = await supabase.auth.signOut();
      
      if (error) {
        toast.error("Sign out failed", {
          description: error.message,
          duration: 5000, // Error messages stay a bit longer
        });
        setLoading(false);
        return { success: false, error: error.message };
      }
      
      // The auth state listener will handle dispatching logout and showing the success toast
      setLoading(false);
      return { success: true };
    } catch (error: any) {
      toast.error("Sign out failed", {
        description: error.message || "An unexpected error occurred",
        duration: 5000, // Error messages stay a bit longer
      });
      setLoading(false);
      return { success: false, error };
    }
  };

  return {
    signIn,
    signUp,
    signOut,
    loading
  };
};
