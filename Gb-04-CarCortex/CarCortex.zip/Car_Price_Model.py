#!/usr/bin/env python
# coding: utf-8

# In[ ]:


# === 1. IMPORT LIBRARIES ===
import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from xgboost import XGBRegressor
import pickle as pk

# === 2. LOAD DATA ===
cars_data = pd.read_csv('Cardetails.csv')
cars_data.drop(columns=['torque'], inplace=True)
cars_data.dropna(inplace=True)
cars_data.drop_duplicates(inplace=True)

# === 3. BRAND NAME EXTRACTION ===
def get_brand_name(car_name):
    return car_name.split(' ')[0].strip()

cars_data['name'] = cars_data['name'].apply(get_brand_name)

# === 4. CLEAN MILEAGE, POWER, ENGINE ===
def clean_data(value):
    value = value.split(' ')[0].strip()
    if value == '':
        return 0.0
    return float(value)

cars_data['mileage'] = cars_data['mileage'].apply(clean_data)
cars_data['max_power'] = cars_data['max_power'].apply(clean_data)
cars_data['engine'] = cars_data['engine'].apply(clean_data)

# === 5. ENCODING CATEGORICAL DATA ===
cars_data['name'].replace(
    ['Maruti', 'Skoda', 'Honda', 'Hyundai', 'Toyota', 'Ford', 'Renault',
     'Mahindra', 'Tata', 'Chevrolet', 'Datsun', 'Jeep', 'Mercedes-Benz',
     'Mitsubishi', 'Audi', 'Volkswagen', 'BMW', 'Nissan', 'Lexus', 'Jaguar',
     'Land', 'MG', 'Volvo', 'Daewoo', 'Kia', 'Fiat', 'Force', 'Ambassador',
     'Ashok', 'Isuzu', 'Opel'],
    list(range(1, 32)), inplace=True
)

cars_data['transmission'].replace(['Manual', 'Automatic'], [1, 2], inplace=True)
cars_data['seller_type'].replace(['Individual', 'Dealer', 'Trustmark Dealer'], [1, 2, 3], inplace=True)
cars_data['fuel'].replace(['Diesel', 'Petrol', 'LPG', 'CNG'], [1, 2, 3, 4], inplace=True)
cars_data['owner'].replace(['First Owner', 'Second Owner', 'Third Owner',
                            'Fourth & Above Owner', 'Test Drive Car'],
                           [1, 2, 3, 4, 5], inplace=True)

# === 6. ADD OPTIONAL FEATURE: CAR AGE ===
cars_data['car_age'] = 2024 - cars_data['year']
cars_data.drop(columns=['year'], inplace=True)

# === 7. SPLIT INPUT & OUTPUT ===
input_data = cars_data.drop(columns=['selling_price'])
output_data = cars_data['selling_price']

x_train, x_test, y_train, y_test = train_test_split(input_data, output_data, test_size=0.2, random_state=42)

# === 8. TRAIN XGBOOST MODEL ===
model = XGBRegressor(
    n_estimators=200,
    learning_rate=0.1,
    max_depth=6,
    subsample=0.8,
    colsample_bytree=0.8,
    random_state=42
)
model.fit(x_train, y_train)

# === 9. EVALUATE MODEL ===
y_pred = model.predict(x_test)
print("R² Score:", r2_score(y_test, y_pred))
print("MAE:", mean_absolute_error(y_test, y_pred))
print("MSE:", mean_squared_error(y_test, y_pred))

# === 10. TEST SINGLE PREDICTION ===
input_data_model = pd.DataFrame(
    [[5, 12000, 1, 1, 1, 1, 12.99, 2494.0, 100.6, 5.0, 2]],  # Added 'car_age' as last feature
    columns=['name', 'km_driven', 'fuel', 'seller_type', 'transmission', 'owner',
             'mileage', 'engine', 'max_power', 'seats', 'car_age']
)

print("Predicted price for sample input: ₹", model.predict(input_data_model)[0])

# === 11. SAVE MODEL ===
pk.dump(model, open('model.pkl', 'wb'))

