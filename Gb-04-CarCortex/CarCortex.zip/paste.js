const { MongoClient, ObjectId } = require('mongodb');
const bcrypt = require('bcryptjs');

class DatabaseHandler {
    constructor(connectionString = 'mongodb://localhost:27017/', databaseName = 'user_database') {
        this.connectionString = connectionString;
        this.databaseName = databaseName;
        this.client = null;
        this.db = null;
        this.usersCollection = null;
    }

    async connect() {
        try {
            this.client = new MongoClient(this.connectionString);
            await this.client.connect();
            
            // Test the connection
            await this.client.db('admin').command({ ping: 1 });
            console.log('Successfully connected to MongoDB!');
            
            this.db = this.client.db(this.databaseName);
            this.usersCollection = this.db.collection('users');
            
            // Create indexes for better performance and uniqueness
            await this.createIndexes();
            
            return true;
        } catch (error) {
            console.error('Failed to connect to MongoDB:', error);
            throw error;
        }
    }

    async createIndexes() {
        try {
            // Create unique index on email field
            await this.usersCollection.createIndex({ email: 1 }, { unique: true });
            console.log('Database indexes created successfully!');
        } catch (error) {
            console.error('Error creating indexes:', error);
        }
    }

    async hashPassword(password) {
        const saltRounds = 12;
        return await bcrypt.hash(password, saltRounds);
    }

    async verifyPassword(password, hashedPassword) {
        return await bcrypt.compare(password, hashedPassword);
    }

    async findOneUser(query) {
        return await this.usersCollection.findOne(query);
    }

    async insertOneUser(document) {
        try {
            // Hash the password if it exists in the document
            if (document.password) {
                document.password = await this.hashPassword(document.password);
            }
            
            const result = await this.usersCollection.insertOne(document);
            return result;
        } catch (error) {
            if (error.code === 11000) { // Duplicate key error
                throw new Error('Email already exists');
            }
            throw error;
        }
    }

    async close() {
        if (this.client) {
            await this.client.close();
            console.log('MongoDB connection closed');
        }
    }
}

// Export the class and create a singleton instance
const dbHandler = new DatabaseHandler();

module.exports = {
    DatabaseHandler,
    dbHandler
};