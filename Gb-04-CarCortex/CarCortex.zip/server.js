const express = require('express');
const session = require('express-session');
const cors = require('cors');
const path = require('path');
const { dbHandler } = require('./paste');
const bcrypt = require('bcryptjs');
const MongoStore = require('connect-mongo');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(cors({
    origin: 'http://localhost:3000',
    credentials: true,
    methods: ['GET', 'POST', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.static(path.join(__dirname, 'public')));

// ======================
// ROUTE DEFINITIONS
// ======================

function defineRoutes() {
    // API Routes
    app.get('/api/car-data', (req, res) => {
        const carData = {
            brands: [
                'Maruti', 'Hyundai', 'Honda', 'Toyota', 'Tata', 
                'Mahindra', 'Ford', 'Chevrolet', 'Renault', 'Nissan', 
                'Volkswagen', 'Skoda', 'BMW', 'Mercedes-Benz', 'Audi'
            ],
            fuelTypes: ['Petrol', 'Diesel', 'CNG', 'LPG', 'Electric'],
            sellerTypes: ['Individual', 'Dealer', 'Trustmark Dealer'],
            transmissions: ['Manual', 'Automatic'],
            ownerTypes: ['First Owner', 'Second Owner', 'Third Owner', 'Fourth & Above Owner', 'Test Drive Car']
        };
        res.json(carData);
    });

    app.post('/api/login', async (req, res) => {
        try {
            const { email, password } = req.body;
            const user = await dbHandler.findOneUser({ email });

            if (!user) {
                return res.status(401).json({ success: false, message: 'Invalid email or password' });
            }

            const isMatch = await bcrypt.compare(password, user.password);

            if (!isMatch) {
                return res.status(401).json({ success: false, message: 'Invalid email or password' });
            }

            req.session.user = {
                id: user._id,
                email: user.email,
                name: user.name
            };

            res.json({ success: true, message: 'Login successful', user: req.session.user });
        } catch (error) {
            console.error('Login error:', error);
            res.status(500).json({ success: false, message: 'Login failed' });
        }
    });

    app.post('/api/register', async (req, res) => {
        try {
            const { name, email, password } = req.body;
            const existingUser = await dbHandler.findOneUser({ email });

            if (existingUser) {
                return res.status(400).json({ success: false, message: 'Email already registered' });
            }

            const result = await dbHandler.insertOneUser({
                name,
                email,
                password,
                createdAt: new Date()
            });

            res.json({ success: true, message: 'Registration successful', userId: result.insertedId });
        } catch (error) {
            console.error('Registration error:', error);
            res.status(500).json({ success: false, message: 'Registration failed' });
        }
    });

    app.get('/api/check-auth', (req, res) => {
        if (req.session.user) {
            res.json({ isAuthenticated: true, user: req.session.user });
        } else {
            res.json({ isAuthenticated: false });
        }
    });

    app.post('/api/logout', (req, res) => {
        req.session.destroy(err => {
            if (err) {
                console.error('Logout error:', err);
                return res.status(500).json({ success: false });
            }
            res.clearCookie('carapp.sid');
            res.json({ success: true });
        });
    });

    // Page Routes
    app.get(['/', '/login.html'], (req, res) => {
        res.sendFile(path.join(__dirname, 'public', 'login.html'));
    });

    app.get('/register.html', (req, res) => {
        res.sendFile(path.join(__dirname, 'public', 'register.html'));
    });

    app.get('/home.html', (req, res) => {
        if (!req.session.user) {
            return res.redirect('/login.html');
        }
        res.sendFile(path.join(__dirname, 'public', 'home.html'));
    });

    // 404 Handler
    app.use((req, res) => {
        res.status(404).json({ success: false, message: 'Route not found' });
    });

    // Error Handler
    app.use((err, req, res, next) => {
        console.error('Server error:', err);
        res.status(500).json({ success: false, message: 'Internal server error' });
    });
}

// ======================
// SERVER STARTUP
// ======================

async function startServer() {
    try {
        await dbHandler.connect();
        console.log('✅ Database connected successfully');

        app.use(session({
            secret: 'your-secret-key-change-this-in-production',
            resave: false,
            saveUninitialized: false,
            cookie: {
                secure: false,
                maxAge: 24 * 60 * 60 * 1000,
                httpOnly: true,
                sameSite: 'lax'
            },
            name: 'carapp.sid',
            store: MongoStore.create({
                client: dbHandler.client,
                dbName: dbHandler.databaseName,
                collectionName: 'sessions',
                ttl: 24 * 60 * 60
            })
        }));

        defineRoutes();

        app.listen(PORT, () => {
            console.log(`🚀 Server running on http://localhost:${PORT}`);
        });
    } catch (err) {
        console.error('❌ Failed to start server:', err);
        process.exit(1);
    }
}

startServer();
