async function logout() {
    try {
        const response = await fetch('/api/logout', {
            method: 'POST',
            credentials: 'include' // Important for session cookies
        });

        if (response.ok) {
            window.location.href = '/login.html';
        } else {
            console.error('Logout failed');
        }
    } catch (error) {
        console.error('Logout error:', error);
    }
}

// Create animated background particles
function createParticles() {
    const particlesContainer = document.getElementById('particles');
    const particleCount = 50;

    for (let i = 0; i < particleCount; i++) {
        const particle = document.createElement('div');
        particle.className = 'particle';

        const size = Math.random() * 6 + 2;
        const x = Math.random() * window.innerWidth;
        const y = Math.random() * window.innerHeight;
        const animationDelay = Math.random() * 6;

        particle.style.cssText = `
    width: ${size}px;
    height: ${size}px;
    left: ${x}px;
    top: ${y}px;
    animation-delay: ${animationDelay}s;
    `;

        particlesContainer.appendChild(particle);
    }
}


function populateDropdowns(data) {
    const dropdownConfig = {
        carBrand: data.brands,
        fuelType: data.fuelTypes,
        sellerType: data.sellerTypes,
        transmission: data.transmissions,
        ownerType: data.ownerTypes
    };

    for (const [selectId, items] of Object.entries(dropdownConfig)) {
        const select = document.getElementById(selectId);
        if (!select) continue;

        select.innerHTML = '';

        const defaultOption = document.createElement('option');
        defaultOption.value = '';
        defaultOption.textContent = '-- Select --';
        defaultOption.disabled = true;
        defaultOption.selected = true;
        select.appendChild(defaultOption);

        items.forEach(item => {
            const option = document.createElement('option');
            option.value = item;
            option.textContent = item;
            select.appendChild(option);
        });
    }
}

function setupRangeInputs() {
    const rangeInputs = [
        { id: 'carYear', output: 'yearValue', format: v => v },
        { id: 'kmDriven', output: 'kmValue', format: v => `${parseInt(v).toLocaleString()} km` },
        { id: 'mileage', output: 'mileageValue', format: v => `${v} km/l` },
        { id: 'engine', output: 'engineValue', format: v => `${parseInt(v).toLocaleString()} cc` },
        { id: 'maxPower', output: 'powerValue', format: v => `${v} bhp` },
        { id: 'seats', output: 'seatsValue', format: v => `${v} seats` }
    ];

    rangeInputs.forEach(({ id, output, format }) => {
        const input = document.getElementById(id);
        const outputEl = document.getElementById(output);

        if (!input || !outputEl) return;

        outputEl.textContent = format(input.value);

        input.addEventListener('input', () => {
            outputEl.textContent = format(input.value);
        });
    });
}


function triggerEnhancedConfetti() {
    const colors = ['#ff6b6b', '#4ecdc4', '#45b7d1', '#96ceb4', '#ffeead', '#667eea', '#764ba2'];
    const shapes = ['circle', 'square', 'triangle'];

    for (let i = 0; i < 100; i++) {
        const confetti = document.createElement('div');
        const shape = shapes[Math.floor(Math.random() * shapes.length)];
        const color = colors[Math.floor(Math.random() * colors.length)];
        const size = Math.random() * 8 + 4;
        const left = Math.random() * 100;
        const animationDuration = Math.random() * 3 + 2;
        const delay = Math.random() * 0.5;

        confetti.className = 'confetti';
        confetti.style.cssText = `
    width: ${size}px;
    height: ${size}px;
    background: ${color};
    left: ${left}%;
    top: -10px;
    border-radius: ${shape === 'circle' ? '50%' : '0'};
    transform: ${shape === 'triangle' ? 'rotate(45deg)' : 'none'};
    animation: confetti-fall ${animationDuration}s linear ${delay}s forwards;
    box-shadow: 0 0 10px ${color}50;
    `;

        document.body.appendChild(confetti);

        setTimeout(() => {
            confetti.remove();
        }, (animationDuration + delay) * 1000);
    }

    // Add enhanced keyframes
    if (!document.getElementById('confetti-styles')) {
        const style = document.createElement('style');
        style.id = 'confetti-styles';
        style.textContent = `
    @keyframes confetti-fall {
        0 % {
            transform: translateY(-100vh) rotate(0deg) scale(1);
                            opacity: 1;
        }
                        10% {
        transform: translateY(-90vh) rotate(90deg) scale(1.1);
                        }
    20% {
        transform: translateY(-70vh) rotate(180deg) scale(0.9);
                        }
    50% {
        transform: translateY(-20vh) rotate(450deg) scale(1.2);
    opacity: 0.8;
                        }
    80% {
        transform: translateY(20vh) rotate(720deg) scale(0.8);
    opacity: 0.6;
                        }
    100% {
        transform: translateY(100vh) rotate(1080deg) scale(0.5);
    opacity: 0;
                        }
                    }
    `;
        document.head.appendChild(style);
    }
}

// Add smooth scroll behavior and intersection observer for animations
window.addEventListener('scroll', () => {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 50) {
        navbar.style.background = 'rgba(255, 255, 255, 0.15)';
    } else {
        navbar.style.background = 'rgba(255, 255, 255, 0.1)';
    }
});

// Add hover effects for form elements
document.addEventListener('DOMContentLoaded', () => {
    const formGroups = document.querySelectorAll('.form-group');

    formGroups.forEach(group => {
        const input = group.querySelector('select, input[type="range"]');
        if (input) {
            input.addEventListener('focus', () => {
                group.style.transform = 'translateY(-2px)';
                group.style.transition = 'all 0.3s ease';
            });

            input.addEventListener('blur', () => {
                group.style.transform = 'translateY(0)';
            });
        }
    });
});

// Add typing animation for welcome message
function typeWriter(element, text, speed = 50) {
    let i = 0;
    element.innerHTML = '';

    function type() {
        if (i < text.length) {
            element.innerHTML += text.charAt(i);
            i++;
            setTimeout(type, speed);
        }
    }
    type();
}

// Enhanced loading states
function showLoadingOverlay() {
    const overlay = document.createElement('div');
    overlay.id = 'loading-overlay';
    overlay.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(102, 126, 234, 0.9);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 10000;
    backdrop-filter: blur(10px);
    `;

    overlay.innerHTML = `
    <div style="text-align: center; color: white;">
        <div style="width: 60px; height: 60px; border: 4px solid rgba(255,255,255,0.3); border-top: 4px solid white; border-radius: 50%; animation: spin 1s linear infinite; margin: 0 auto 20px;"></div>
        <h3 style="font-size: 1.5rem; margin: 0;">Processing Your Request</h3>
        <p style="margin: 10px 0 0; opacity: 0.8;">Please wait while we calculate the best price...</p>
    </div>
    `;

    document.body.appendChild(overlay);
    return overlay;
}

function hideLoadingOverlay() {
    const overlay = document.getElementById('loading-overlay');
    if (overlay) {
        overlay.style.animation = 'fadeOut 0.5s ease-out forwards';
        setTimeout(() => overlay.remove(), 500);
    }
}

// Add success sound effect simulation
function playSuccessSound() {
    // Create audio context for success sound simulation
    if (typeof AudioContext !== 'undefined' || typeof webkitAudioContext !== 'undefined') {
        const audioContext = new (AudioContext || webkitAudioContext)();
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();

        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);

        oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
        oscillator.frequency.setValueAtTime(1000, audioContext.currentTime + 0.1);
        oscillator.frequency.setValueAtTime(1200, audioContext.currentTime + 0.2);

        gainNode.gain.setValueAtTime(0, audioContext.currentTime);
        gainNode.gain.linearRampToValueAtTime(0.1, audioContext.currentTime + 0.01);
        gainNode.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.3);

        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.3);
    }
}

// Enhanced predict price function with better UX
async function predictPriceEnhanced() {
    const formData = {
        name: document.getElementById('carBrand').value,
        year: parseInt(document.getElementById('carYear').value),
        kmDriven: parseInt(document.getElementById('kmDriven').value),
        fuelType: document.getElementById('fuelType').value,
        sellerType: document.getElementById('sellerType').value,
        transmission: document.getElementById('transmission').value,
        ownerType: document.getElementById('ownerType').value,
        mileage: parseFloat(document.getElementById('mileage').value),
        engine: parseFloat(document.getElementById('engine').value),
        maxPower: parseFloat(document.getElementById('maxPower').value),
        seats: parseInt(document.getElementById('seats').value)
    };

    const messageDiv = document.getElementById('message');
    const resultDiv = document.getElementById('result');

    messageDiv.textContent = '';
    resultDiv.style.display = 'none';

    // Enhanced validation with specific error messages
    const validationErrors = [];
    if (!formData.name) validationErrors.push('Car Brand');
    if (!formData.fuelType) validationErrors.push('Fuel Type');
    if (!formData.sellerType) validationErrors.push('Seller Type');
    if (!formData.transmission) validationErrors.push('Transmission');
    if (!formData.ownerType) validationErrors.push('Owner Type');

    if (validationErrors.length > 0) {
        messageDiv.innerHTML = `
                    <i class="fas fa-exclamation-triangle"></i>
                    Please select: ${validationErrors.join(', ')}
                `;
        return;
    }

    // Show loading overlay
    const loadingOverlay = showLoadingOverlay();

    try {
        // Simulate API call with realistic delay
        await new Promise(resolve => setTimeout(resolve, 3000));

        // Enhanced mock prediction with more realistic calculations
        let basePrice = 500000; // Base price

        // Brand factor
        const brandMultipliers = {
            'BMW': 2.5, 'Mercedes': 2.8, 'Audi': 2.3,
            'Toyota': 1.4, 'Honda': 1.3, 'Hyundai': 1.1,
            'Maruti': 0.8, 'Tata': 0.9
        };
        basePrice *= brandMultipliers[formData.name] || 1.0;

        // Year depreciation
        const age = 2024 - formData.year;
        const depreciationRate = Math.pow(0.85, age);
        basePrice *= depreciationRate;

        // Kilometer factor
        const kmFactor = Math.max(0.4, 1 - (formData.kmDriven / 300000));
        basePrice *= kmFactor;

        // Fuel type factor
        const fuelMultiplier = formData.fuelType === 'Electric' ? 1.3 :
            formData.fuelType === 'Hybrid' ? 1.2 : 1.0;
        basePrice *= fuelMultiplier;

        // Transmission factor
        if (formData.transmission === 'Automatic') basePrice *= 1.15;

        const finalPrice = Math.round(basePrice);

        // Hide loading and show result
        hideLoadingOverlay();

        // Animate price counting up
        animatePriceCounter(finalPrice);

        resultDiv.style.display = 'block';

        // Play success sound and trigger confetti
        playSuccessSound();
        triggerEnhancedConfetti();

        // Smooth scroll to result
        setTimeout(() => {
            resultDiv.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }, 500);

    } catch (error) {
        hideLoadingOverlay();
        console.error('Prediction error:', error);
        messageDiv.innerHTML = `
    <i class="fas fa-exclamation-circle"></i>
    Something went wrong. Please try again.
    `;
    }
}

// Animate price counter
function animatePriceCounter(targetPrice) {
    const priceElement = document.getElementById('predictedPrice');
    const duration = 2000; // 2 seconds
    const frameDuration = 1000 / 60; // 60 FPS
    const totalFrames = Math.round(duration / frameDuration);
    let frame = 0;

    const counter = setInterval(() => {
        frame++;
        const progress = frame / totalFrames;
        const easeOut = 1 - Math.pow(1 - progress, 3); // Cubic ease-out
        const currentPrice = Math.round(targetPrice * easeOut);

        priceElement.textContent = '₹ ' + currentPrice.toLocaleString('en-IN');

        if (frame >= totalFrames) {
            clearInterval(counter);
            priceElement.textContent = '₹ ' + targetPrice.toLocaleString('en-IN');
        }
    }, frameDuration);
}

document.addEventListener('DOMContentLoaded', async () => {
    // First check authentication status
    try {
        const authResponse = await fetch('/api/check-auth', {
            credentials: 'include' // Important for session cookies
        });

        if (!authResponse.ok) {
            throw new Error('Not authenticated');
        }

        const authData = await authResponse.json();

        if (!authData.isAuthenticated) {
            window.location.href = '/login.html';
            return;
        }

        // Set user display name
        document.getElementById('userFirstName').textContent = authData.user.name;

        // Load car data
        await loadCarData();

        // Initialize UI components
        setupRangeInputs();
        setupEventListeners();

    } catch (error) {
        console.error('Initialization error:', error);
        window.location.href = '/login.html';
    }
});


async function predictPrice() {
    const formData = {
        name: document.getElementById('carBrand').value,
        year: parseInt(document.getElementById('carYear').value),
        kmDriven: parseInt(document.getElementById('kmDriven').value),
        fuelType: document.getElementById('fuelType').value,
        sellerType: document.getElementById('sellerType').value,
        transmission: document.getElementById('transmission').value,
        ownerType: document.getElementById('ownerType').value,
        mileage: parseFloat(document.getElementById('mileage').value),
        engine: parseFloat(document.getElementById('engine').value),
        maxPower: parseFloat(document.getElementById('maxPower').value),
        seats: parseInt(document.getElementById('seats').value)
    };

    const messageDiv = document.getElementById('message');
    messageDiv.textContent = '';
    messageDiv.style.color = '#d9534f';

    // Basic validation
    if (!formData.name || !formData.fuelType || !formData.transmission) {
        messageDiv.textContent = 'Please fill all required fields';
        return;
    }

    try {
        const response = await fetch('/api/predict', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            credentials: 'include', // Include session cookies
            body: JSON.stringify(formData)
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.message || 'Prediction failed');
        }

        // Display results
        document.getElementById('predictedPrice').textContent =
            data.predicted_price.toLocaleString('en-IN', {
                style: 'currency',
                currency: 'INR',
                maximumFractionDigits: 0
            }).replace('₹', '₹ ');

        document.getElementById('result').style.display = 'block';
        messageDiv.textContent = '';
        triggerConfetti();

    } catch (error) {
        console.error('Prediction error:', error);
        messageDiv.textContent = error.message || 'An error occurred. Please try again.';

        // If unauthorized, redirect to login
        if (error.message.includes('Unauthorized')) {
            setTimeout(() => {
                window.location.href = '/login.html';
            }, 1500);
        }
    }
}
