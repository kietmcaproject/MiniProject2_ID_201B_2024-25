import sys
import json
import pickle
import pandas as pd
import os
import warnings
warnings.filterwarnings('ignore')

def load_model():
    try:
        model_path = os.path.join(os.path.dirname(__file__), 'model.pkl')
        with open(model_path, 'rb') as f:
            return pickle.load(f)
    except Exception as e:
        print(f"Error loading model: {str(e)}", file=sys.stderr)
        sys.exit(1)

def preprocess_input(data):
    try:
        # Brand name extraction (same as training)
        brand_name = data['name'].split(' ')[0].strip() if isinstance(data['name'], str) else 'Maruti'
        
        # Create DataFrame with expected columns
        df = pd.DataFrame([{
            'name': brand_name,
            'km_driven': data.get('km_driven', 0),
            'fuel': data.get('fuel', 'Petrol'),
            'seller_type': data.get('seller_type', 'Individual'),
            'transmission': data.get('transmission', 'Manual'),
            'owner': data.get('owner', 'First Owner'),
            'mileage': data.get('mileage', 15.0),
            'engine': data.get('engine', 1200),
            'max_power': data.get('max_power', 80.0),
            'seats': data.get('seats', 5),
            'year': data.get('year', 2015)
        }])

        # Clean numerical fields (same as training)
        for col in ['mileage', 'max_power', 'engine']:
            df[col] = pd.to_numeric(df[col], errors='coerce')
            df[col] = df[col].fillna(df[col].median())

        # Convert brand names to numeric (same as training)
        brand_mapping = {
            'Maruti': 1, 'Skoda': 2, 'Honda': 3, 'Hyundai': 4, 'Toyota': 5,
            'Ford': 6, 'Renault': 7, 'Mahindra': 8, 'Tata': 9, 'Chevrolet': 10,
            'Datsun': 11, 'Jeep': 12, 'Mercedes-Benz': 13, 'Mitsubishi': 14,
            'Audi': 15, 'Volkswagen': 16, 'BMW': 17, 'Nissan': 18, 'Lexus': 19,
            'Jaguar': 20, 'Land': 21, 'MG': 22, 'Volvo': 23, 'Daewoo': 24,
            'Kia': 25, 'Fiat': 26, 'Force': 27, 'Ambassador': 28, 'Ashok': 29,
            'Isuzu': 30, 'Opel': 31
        }
        df['name'] = df['name'].map(brand_mapping).fillna(1)  # Default to Maruti if unknown

        # Encode categorical variables (same as training)
        df['transmission'] = df['transmission'].map({'Manual': 1, 'Automatic': 2}).fillna(1)
        df['seller_type'] = df['seller_type'].map({
            'Individual': 1,
            'Dealer': 2,
            'Trustmark Dealer': 3
        }).fillna(1)
        df['fuel'] = df['fuel'].map({
            'Diesel': 1,
            'Petrol': 2,
            'LPG': 3,
            'CNG': 4
        }).fillna(2)
        df['owner'] = df['owner'].map({
            'First Owner': 1,
            'Second Owner': 2,
            'Third Owner': 3,
            'Fourth & Above Owner': 4,
            'Test Drive Car': 5
        }).fillna(1)

        # Calculate car_age (same as training)
        current_year = 2024  # Update this if needed
        df['car_age'] = current_year - df['year']
        df.drop(columns=['year'], inplace=True)

        # Ensure column order matches training
        cols_order = [
            'name', 'km_driven', 'fuel', 'seller_type', 'transmission', 'owner',
            'mileage', 'engine', 'max_power', 'seats', 'car_age'
        ]
        df = df[cols_order]

        return df

    except Exception as e:
        print(f"Preprocessing error: {str(e)}", file=sys.stderr)
        sys.exit(1)

def predict_price(model, data):
    try:
        return model.predict(data)[0]
    except Exception as e:
        print(f"Prediction error: {str(e)}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    try:
        if len(sys.argv) < 2:
            raise ValueError("Missing input data")
            
        input_data = json.loads(sys.argv[1])
        model = load_model()
        processed_data = preprocess_input(input_data)
        prediction = predict_price(model, processed_data)
        print(prediction)

    except Exception as e:
        print(f"Error: {str(e)}", file=sys.stderr)
        sys.exit(1)