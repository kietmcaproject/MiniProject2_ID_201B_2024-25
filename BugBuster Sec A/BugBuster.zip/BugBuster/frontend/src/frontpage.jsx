import React from 'react';
import { Link } from 'react-router-dom';
import './frontpage.css';
import Navbar from './Navbar';

const Home1 = () => {
  return (
    <div className='home'>
      {/* Hero Section */}
      <Navbar />
      <section className='hero'>
        <div className='hero-content'>
          <h1 className='hero-title'>Welcome to BugBuster</h1>
          <p className='hero-subtitle'>
            AI-powered bug detection & suggestions for better, cleaner code.
          </p>
          <Link to='/dashboard' className='cta-button'>
            Get Started
          </Link>
        </div>
        <div className='hero-image'>
          <img
            src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSvkUFmp5jSF-DhrD5102bzHU7RbidetfqYfA&s'
            alt='AI Bug Detection'
          />
        </div>
      </section>

      {/* Features Section */}
      <section className='features'>
        <h2>Why BugBuster?</h2>
        <div className='feature-grid'>
          <div className='feature-card'>
            <h3>AI-Powered Analysis</h3>
            <p>
              Detects bugs, code smells, and optimizations using machine
              learning.
            </p>
          </div>
          <div className='feature-card'>
            <h3>Real-Time Suggestions</h3>
            <p>Instantly get fixes, improvements, and better alternatives.</p>
          </div>
          <div className='feature-card'>
            <h3>Simple & Developer-Friendly</h3>
            <p>Just paste your code and let BugBuster do the thinking.</p>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className='cta-section'>
        <h2>Ready to clean up your code?</h2>
        <Link to='/dashboard' className='cta-button large'>
          Start Debugging Now
        </Link>
      </section>
    </div>
  );
};

export default Home1;
