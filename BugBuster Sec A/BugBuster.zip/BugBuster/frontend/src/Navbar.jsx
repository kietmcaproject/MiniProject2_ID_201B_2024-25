import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import './navbar.css';

function Navbar({ handleSuccess }) {
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(false);

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('loggedInUser');
    if (handleSuccess) {
      handleSuccess('User Logged out');
    }
    setTimeout(() => {
      navigate('/login');
    }, 1000);
  };

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  return (
    <nav className='navbar'>
      <div className='nav-content'>
        <Link to='/' className='nav-logo'>
          BugBuster
        </Link>

        <div className={`nav-links ${isOpen ? 'open' : ''}`}>
          <Link to='/' onClick={() => setIsOpen(false)}>
            Home
          </Link>
          
          <Link to='/dashboard' onClick={() => setIsOpen(false)}>
            Editor
          </Link>

          <Link to='/contact' onClick={() => setIsOpen(false)}>
            Contact
          </Link>

          <Link to='/about' onClick={() => setIsOpen(false)}>
            About
          </Link>
          <button
            className='logout-btn mobile'
            onClick={() => {
              setIsOpen(false);
              handleLogout();
            }}
          >
            Logout
          </button>
        </div>

        <div className='nav-actions'>
          <button className='logout-btn desktop' onClick={handleLogout}>
            Logout
          </button>
          <div
            className={`hamburger ${isOpen ? 'active' : ''}`}
            onClick={toggleMenu}
          >
            <span></span>
            <span></span>
            <span></span>
          </div>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
