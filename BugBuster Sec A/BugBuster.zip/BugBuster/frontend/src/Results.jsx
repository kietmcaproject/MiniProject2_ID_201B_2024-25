import { useLocation } from 'react-router-dom';
import { useEffect, useState } from 'react';
import Prism from 'prismjs';
import 'prismjs/themes/prism-tomorrow.css';
import './Results.css';
import './Navbar';
import Navbar from './Navbar';
function cleanCode(input) {
  let cleanedCode = input.trim();
  cleanedCode = cleanedCode.replace(/```/g, '').trim(); // only remove triple backticks
  return cleanedCode;
}

export default function Results() {
  const { state } = useLocation();
  const { code, responses } = state;

  const [improvedCode, setImprovedCode] = useState('');
  const [bestTimeComplexityCode, setBestTimeComplexityCode] = useState('');
  const [bestSpaceComplexityCode, setBestSpaceComplexityCode] = useState('');

  useEffect(() => {
    Prism.highlightAll();

    const improved = responses.find((r) =>
      r.question.toLowerCase().includes('refactored version of the code')
    );
    setImprovedCode(improved ? improved.answer : '');

    const timeOptimized = responses.find((r) =>
      r.question.toLowerCase().includes('best time complexity')
    );
    setBestTimeComplexityCode(timeOptimized ? timeOptimized.answer : '');

    const spaceOptimized = responses.find((r) =>
      r.question.toLowerCase().includes('best space complexity')
    );
    setBestSpaceComplexityCode(spaceOptimized ? spaceOptimized.answer : '');
  }, [responses]);

  const handleCopy = async (codeToCopy) => {
    await navigator.clipboard.writeText(cleanCode(codeToCopy));
    alert('Code copied to clipboard!');
  };

  return (
    <>
      <Navbar />

      <section className='results-container'>
        <h2 className='pop-heading'>Improved Code</h2>
        <div className='code-header'>
          <button
            className='copy-button'
            onClick={() => handleCopy(improvedCode)}
          >
            Copy
          </button>
        </div>
        <pre className='code-block'>
          <code className='language-javascript'>{cleanCode(improvedCode)}</code>
        </pre>

        <h2 className='pop-heading'>Best Time Complexity Code</h2>
        <div className='code-header'>
          <button
            className='copy-button'
            onClick={() => handleCopy(bestTimeComplexityCode)}
          >
            Copy
          </button>
        </div>
        <pre className='code-block'>
          <code className='language-javascript'>
            {cleanCode(bestTimeComplexityCode)}
          </code>
        </pre>

        <h2 className='pop-heading'>Best Space Complexity Code</h2>
        <div className='code-header'>
          <button
            className='copy-button'
            onClick={() => handleCopy(bestSpaceComplexityCode)}
          >
            Copy
          </button>
        </div>
        <pre className='code-block'>
          <code className='language-javascript'>
            {cleanCode(bestSpaceComplexityCode)}
          </code>
        </pre>

        <h2 className='pop-heading'>AI Answers</h2>
        <div className='card-grid'>
          {responses
            .filter(
              (res) =>
                !res.question.toLowerCase().includes('best time complexity') &&
                !res.question.toLowerCase().includes('best space complexity') &&
                !res.question
                  .toLowerCase()
                  .includes('refactored version of the code')
            )
            .map((res, index) => (
              <div className='card' key={index}>
                <h3>{res.question}</h3>
                <p>{res.answer}</p>
              </div>
            ))}
        </div>
      </section>
    </>
  );
}
