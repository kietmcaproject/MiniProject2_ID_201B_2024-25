import { useState, useEffect } from 'react';
import CodeMirror from '@uiw/react-codemirror';
import { javascript } from '@codemirror/lang-javascript';
import { oneDark } from '@codemirror/theme-one-dark';
import { useNavigate } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import './App.css';

import Navbar from './Navbar'; // make sure path is correct

const API_KEY = import.meta.env.VITE_OPENAI_API_KEY;

const questions = [
  'Explain in shortest way possible and easy to understand What does this code do?',
  'Explain in what have you changed in the code?',

  'Explain in shortest way possible and easy to understand What are the potential bugs in this code?',
  'Explain in shortest way possible and easy to understand Can this code be optimized for performance?',
  'Explain in shortest way possible and easy to understand Are there any best practices violated?',
  'Explain in shortest way possible and easy to understand Is the code secure from common vulnerabilities?',
  'Explain in shortest way possible and easy to understand How can this code be improved or refactored?',
  'Explain in shortest way possible and easy to understand What is the time and space complexity?',
  "Don't change the algorithm. Just return the code. Don't include any explanation, comments, or language specification. Here is the refactored version of the code with the best space complexity using the same algorithm.",
  "Don't change the algorithm. Just return the code. Don't include any explanation, comments, or language specification. Here is the refactored version of the code with the best time complexity improvements within the same algorithm.",
];

export default function Home() {
  const [code, setCode] = useState(
    () =>
      localStorage.getItem('userCode') || 'function sum() {\nreturn 1 + 1;\n}'
  );
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    localStorage.setItem('userCode', code);
  }, [code]);

  const handleSuccess = (msg) => toast.success(msg);

  async function reviewCode() {
    setLoading(true);
    toast.info('Review in progress...', { autoClose: 1500 });
    const responses = [];

    try {
      for (const question of questions) {
        const body = {
          model: 'gpt-3.5-turbo',
          messages: [
            {
              role: 'system',
              content:
                'You are a helpful AI code reviewer. Analyze the code and respond clearly.',
            },
            {
              role: 'user',
              content: `Here is some code:\n\n${code}\n\n${question}`,
            },
          ],
        };

        const res = await fetch('https://api.openai.com/v1/chat/completions', {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${API_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(body),
        });

        if (!res.ok) throw new Error(`API error: ${res.statusText}`);

        const data = await res.json();
        responses.push({
          question,
          answer: data.choices[0].message.content,
        });
      }

      toast.success('Review complete!', { autoClose: 1500 });
      navigate('/results', { state: { code, responses } });
    } catch (err) {
      console.error(err);
      toast.error('Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <Navbar />

      <main>
        <ToastContainer />

        <div className='left'>
          <div className='code'>
            <div
              style={{
                fontFamily: '"Fira code", "Fira Mono", monospace',
                fontSize: 16,
                border: '1px solid #ddd',
                borderRadius: '5px',
                overflow: 'auto',
                height: '530px',
                maxHeight: '550px',
                whiteSpace: 'pre-wrap',
                wordWrap: 'break-word',
              }}
            >
              <CodeMirror
                value={code}
                extensions={[javascript()]}
                onChange={(value) => setCode(value)}
                theme={oneDark}
                basicSetup={{ lineNumbers: true, highlightActiveLine: true }}
                style={{ fontSize: 16, height: '100%' }}
              />
            </div>
          </div>
          <button
            onClick={reviewCode}
            className='review-button'
            disabled={loading}
          >
            {loading ? <div className='spinner'></div> : 'Get AI Review'}
          </button>
        </div>
      </main>
    </>
  );
}
