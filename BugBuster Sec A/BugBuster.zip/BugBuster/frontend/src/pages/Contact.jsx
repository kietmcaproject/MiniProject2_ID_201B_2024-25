import React from 'react';
import Navbar from '../Navbar';
import './Contact.css';

export default function Contact() {
  return (
    <>
      <Navbar />
      <div className="contact-container">
        <h1>Contact Us</h1>
        <p>
          Have questions, feedback, or want to collaborate with us? We'd love to
          hear from you!
        </p>
        <ul>
          <li><strong>Email:</strong> support@bugbuster.dev</li>
          <li><strong>FaceBook:</strong> <a href="https://www.facebook.com/kiet.edu/" target="_blank" rel="noopener noreferrer">https://www.facebook.com/kiet.edu/</a></li>
          <li><strong>Instagram:</strong> <a href="https://www.instagram.com/kiet_edu/?utm_medium=copy_link" target="_blank" rel="noopener noreferrer">https://www.instagram.com/kiet_edu/?utm_medium=copy_link</a></li>
          <li><strong>Twitter:</strong> <a href="https://x.com/Kiet_edu" target="_blank" rel="noopener noreferrer">https://x.com/Kiet_edu</a></li>
          <li><strong>LinkedIn:</strong> <a href="https://www.linkedin.com/school/kiet-group-of-institutions/" target="_blank" rel="noopener noreferrer">https://www.linkedin.com/school/kiet-group-of-institutions/</a></li>
        </ul>
        <p>We're committed to improving the development experience—let's build better code together!</p>
      </div>
    </>
  );
}
