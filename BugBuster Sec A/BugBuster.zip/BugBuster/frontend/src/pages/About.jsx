import React from 'react';
import Navbar from '../Navbar';
import './About.css';

export default function About() {
  return (
    <>
      <Navbar />
      <div className="about-container">
        <h1>About BugBuster</h1>
        <p>
          <strong>BugBuster</strong> is an intelligent code reviewing and debugging assistant
          built to streamline the software development process. By automating
          code analysis and error detection, BugBuster provides real-time
          feedback to developers, helping them identify syntax errors, logical
          issues, and deviations from best practices early in the development
          cycle.
        </p>
        <p>
          Our goal is to reduce debugging time and promote clean, maintainable,
          and optimized code. Through the use of static code analysis
          techniques, BugBuster enables developers to write better code with
          confidence and speed.
        </p>
        <p>
          Whether you're a student, a professional developer, or a hobbyist,
          BugBuster empowers you to enhance your code quality and productivity
          through an intuitive and user-friendly interface.
        </p>
        <p>
          This project showcases the power of automated tools in improving
          software reliability and supporting a disciplined approach to software
          development.
        </p>
      </div>
    </>
  );
}
