import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
} from 'react-router-dom';
import { useState } from 'react';
import './App.css';
import './Navbar';

import Login from './pages/Login';
import Signup from './pages/Signup';
import Home from './Home';
import Results from './Results';
import RefrshHandler from './RefrshHandler';
import Home1 from './frontpage';
import Navbar from './Navbar';
import Contact from './pages/Contact';
import About from './pages/About';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const PrivateRoute = ({ element }) => {
    return isAuthenticated ? element : <Navigate to='/login' />;
  };

  return (
    <>
      <div className='App'>
        <Router>
          <RefrshHandler setIsAuthenticated={setIsAuthenticated} />

          <Routes>
            <Route path='/' element={<Navigate to='/login' />} />
            <Route path='/login' element={<Login />} />
            <Route path='/signup' element={<Signup />} />
            <Route
              path='/dashboard'
              element={<PrivateRoute element={<Home />} />}
            />

            <Route
              path='/results'
              element={<PrivateRoute element={<Results />} />}
            />
            <Route path="/contact" element={<Contact />} />

            <Route path='/home' element={<Home1 />} />
            <Route path="/about" element={<About />} />
          </Routes>
        </Router>
      </div>
    </>
  );
}

export default App;
