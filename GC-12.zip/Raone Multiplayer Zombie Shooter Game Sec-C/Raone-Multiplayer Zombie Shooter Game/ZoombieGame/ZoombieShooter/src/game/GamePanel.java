package game;

import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.ArrayList;
import java.util.Random;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class GamePanel extends JPanel implements ActionListener, KeyListener {

    Timer timer;
    Player player;
    ArrayList<Zombie> zombies = new ArrayList<>();
    ArrayList<BossZombie> bosses = new ArrayList<>();
    ArrayList<Bullet> bullets = new ArrayList<>();
    ArrayList<PowerUp> powerUps = new ArrayList<>();
    BufferedImage bgImage;
    int score = 0;

    public GamePanel() {
        setFocusable(true);
        setPreferredSize(new Dimension(800, 600));
        addKeyListener(this);

        try {
            bgImage = ImageIO.read(new File("src/game/resource/download.jpg"));
        } catch (IOException e) {
            System.out.println("Background image not found.");
        }

        player = new Player(400, 300);

        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                double angle = Math.atan2(e.getY() - (player.y + 20), e.getX() - (player.x + 20));
                bullets.add(new Bullet(player.x + 20, player.y + 20, angle));
                playSound("src/game/resource/shoot-1-81135 (1).wav");
            }
        });

        timer = new Timer(30, this);
        timer.start();
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (bgImage != null) {
            g.drawImage(bgImage, 0, 0, getWidth(), getHeight(), null);
        } else {
            g.setColor(Color.BLACK);
            g.fillRect(0, 0, getWidth(), getHeight());
        }

        player.draw(g);

        for (Zombie z : zombies) z.draw(g);
        for (BossZombie b : bosses) b.draw(g);
        for (Bullet b : bullets) b.draw(g);
        for (PowerUp p : powerUps) p.draw(g);

        g.setColor(Color.RED);
        g.fillRect(10, 10, player.health * 2, 20);
        g.setColor(Color.WHITE);
        g.drawRect(10, 10, 200, 20);

        g.setFont(new Font("Arial", Font.BOLD, 20));
        g.drawString("Score: " + score, 650, 25);

        if (player.health <= 0) {
            g.setColor(Color.RED);
            g.setFont(new Font("Arial", Font.BOLD, 50));
            g.drawString("Game Over!", 270, 300);
            timer.stop();
        }
    }

    public void actionPerformed(ActionEvent e) {
        for (Bullet b : bullets) b.move();

        if (new Random().nextInt(20) == 0) zombies.add(new Zombie());
        if (new Random().nextInt(300) == 0) bosses.add(new BossZombie());
        if (new Random().nextInt(400) == 0) powerUps.add(new PowerUp());

        for (int i = 0; i < zombies.size(); i++) {
            Zombie z = zombies.get(i);
            z.moveTowards(player.x, player.y);

            if (z.getBounds().intersects(player.getBounds())) {
                player.health -= 1;
                zombies.remove(i);
                i--;
                playSound("src/game/resource/zombie-bite-96528.wav");
                continue;
            }

            for (int j = 0; j < bullets.size(); j++) {
                Bullet bullet = bullets.get(j);
                if (z.getBounds().intersects(bullet.getBounds())) {
                    zombies.remove(i);
                    bullets.remove(j);
                    score += 10;
                    playSound("src/game/resource/zombie-bite-96528.wav");
                    i--;
                    break;
                }
            }
        }

        for (int i = 0; i < bosses.size(); i++) {
            BossZombie b = bosses.get(i);
            b.moveTowards(player.x, player.y);

            if (b.getBounds().intersects(player.getBounds())) {
                player.health -= 5;
                bosses.remove(i);
                i--;
                continue;
            }

            for (int j = 0; j < bullets.size(); j++) {
                Bullet bullet = bullets.get(j);
                if (b.getBounds().intersects(bullet.getBounds())) {
                    bullets.remove(j);
                    b.health--;
                    if (b.health <= 0) {
                        bosses.remove(i);
                        score += 50;
                        playSound("src/game/resource/zombie-bite-96528.wav");
                    }
                    break;
                }
            }
        }

        for (PowerUp p : powerUps) {
            if (p.active && p.getBounds().intersects(player.getBounds())) {
                player.health = Math.min(100, player.health + 20);
                p.active = false;
            }
        }

        repaint();
    }

    public void keyPressed(KeyEvent e) {
        int k = e.getKeyCode();
        if (k == KeyEvent.VK_W) player.move(0, -10);
        if (k == KeyEvent.VK_S) player.move(0, 10);
        if (k == KeyEvent.VK_A) player.move(-10, 0);
        if (k == KeyEvent.VK_D) player.move(10, 0);
    }

    public void keyReleased(KeyEvent e) {}
    public void keyTyped(KeyEvent e) {}

    public void playSound(String path) {
        try {
            AudioInputStream audio = AudioSystem.getAudioInputStream(new File(path));
            Clip clip = AudioSystem.getClip();
            clip.open(audio);
            clip.start();
        } catch (Exception e) {
            System.out.println("Sound error: " + e.getMessage());
        }
    }
}
