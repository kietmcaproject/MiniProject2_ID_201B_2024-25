package game;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;
import javax.imageio.ImageIO;

public class BossZombie {
    int x, y;
    int health = 5;
    static BufferedImage bossImage;

    static {
        try {
            bossImage = ImageIO.read(new File("src/game/resource/boss.png"));
        } catch (IOException | IllegalArgumentException e) {
            System.out.println("Boss zombie image not found: " + e.getMessage());
        }
    }

    public BossZombie() {
        Random r = new Random();
        x = r.nextInt(800);
        y = r.nextInt(600);
    }

    public void moveTowards(int px, int py) {
        if (x < px) x += 1;
        if (x > px) x -= 1;
        if (y < py) y += 1;
        if (y > py) y -= 1;
    }

    public void draw(Graphics g) {
        if (bossImage != null) {
            g.drawImage(bossImage, x, y, 60, 60, null);
        } else {
            g.setColor(Color.MAGENTA); // fallback if image fails
            g.fillRect(x, y, 50, 50);
        }
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, 50, 50); // adjust if needed
    }
}
