package game;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Player {
    int x, y, health = 100;
    static BufferedImage playerImage;

    static {
        try {
            playerImage = ImageIO.read(new File("src/game/resource/shooter.png"));
        } catch (IOException | IllegalArgumentException e) {
            System.out.println("Player image not found: " + e.getMessage());
        }
    }

    public Player(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public void move(int dx, int dy) {
        x += dx;
        y += dy;
    }

    public void draw(Graphics g) {
        if (playerImage != null) {
            g.drawImage(playerImage, x, y, 60, 100, null); // width=60, height=100
        } else {
            g.setColor(Color.BLUE);
            g.fillRect(x, y, 60, 100);
        }
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, 60, 100); // update collision bounds
    }
}
