package game;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;
import javax.imageio.ImageIO;

public class Zombie {
    int x, y;
    BufferedImage zombieImg;

    public Zombie() {
        x = new Random().nextInt(800);
        y = new Random().nextInt(600);
        try {
            zombieImg = ImageIO.read(new File("src/game/resource/zombie.jpg"));
        } catch (IOException e) {
            System.out.println("Zombie image not found.");
        }
    }

    public void moveTowards(int targetX, int targetY) {
        if (x < targetX) x += 1;
        else if (x > targetX) x -= 1;

        if (y < targetY) y += 1;
        else if (y > targetY) y -= 1;
    }

    public void draw(Graphics g) {
        if (zombieImg != null) {
            g.drawImage(zombieImg, x, y, 40, 40, null);
        } else {
            g.setColor(Color.GREEN);
            g.fillRect(x, y, 40, 40);
        }
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, 40, 40);
    }
}
