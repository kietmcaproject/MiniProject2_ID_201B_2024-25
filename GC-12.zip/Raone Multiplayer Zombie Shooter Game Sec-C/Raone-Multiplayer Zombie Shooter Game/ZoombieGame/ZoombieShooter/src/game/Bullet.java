package game;

import java.awt.*;

public class Bullet {
    double x, y;
    double dx, dy;
    int speed = 12;
    int width = 16;
    int height = 4;

    public Bullet(int x, int y, double angle) {
        this.x = x;
        this.y = y;
        dx = Math.cos(angle) * speed;
        dy = Math.sin(angle) * speed;
    }

    public void move() {
        x += dx;
        y += dy;
    }

    public void draw(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(Color.ORANGE);

        // Save current transform
        var old = g2d.getTransform();

        // Move and rotate the bullet
        g2d.translate(x, y);
        g2d.rotate(Math.atan2(dy, dx));
        g2d.fillRect(0, -height / 2, width, height); // draw rotated bullet

        // Restore original transform
        g2d.setTransform(old);
    }

    public Rectangle getBounds() {
        return new Rectangle((int)x, (int)y, width, height);
    }
}
