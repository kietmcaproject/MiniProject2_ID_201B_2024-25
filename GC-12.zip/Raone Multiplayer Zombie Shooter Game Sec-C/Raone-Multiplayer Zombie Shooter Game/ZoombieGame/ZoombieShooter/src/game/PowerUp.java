package game;

import java.awt.*;
import java.util.Random;

public class PowerUp {
    int x, y;
    boolean active = true;

    public PowerUp() {
        Random r = new Random();
        x = r.nextInt(700) + 50;
        y = r.nextInt(500) + 50;
    }

    public void draw(Graphics g) {
        if (active) {
            g.setColor(Color.CYAN);
            g.fillOval(x, y, 20, 20);
        }
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, 20, 20);
    }
}
