// import com.mongodb.client.*;
// import org.bson.Document;

// public class MongoDBManager {
//     private MongoClient mongoClient;
//     private MongoDatabase database;
//     private MongoCollection<Document> collection;

//     public MongoDBManager() {
//         mongoClient = MongoClients.create("mongodb://localhost:27017"); // default local MongoDB
//         database = mongoClient.getDatabase("space_invaders");
//         collection = database.getCollection("scores");
//     }

//     public void saveScore(String username, int score) {
//         Document userDoc = new Document("username", username)
//                                 .append("score", score)
//                                 .append("timestamp", System.currentTimeMillis());

//         collection.insertOne(userDoc);
//         System.out.println("Score saved to MongoDB for user: " + username);
//     }

//     public void close() {
//         mongoClient.close();
//     }
// }
