// import javax.swing.*;
// import java.awt.*;//grid layout use karne ke liye

// class LoginPage extends JFrame {//Matlab ye ek window banayegi jisme login form hoga.


//     public LoginPage(UserDatabase userDB, Runnable startGameCallback) {
//     setTitle("Login - Space Invaders");
//     setSize(350, 200);
//     setLayout(new GridLayout(4, 2, 5, 5)); // Increased from 3 to 4 rows
//     setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//     setLocationRelativeTo(null);

//     JTextField usernameField = new JTextField();
//     JPasswordField passwordField = new JPasswordField();
//     JButton loginButton = new JButton("Login");
//     JButton goToRegisterButton = new JButton("Go to Register"); // NEW BUTTON

//     add(new JLabel("Username:")); add(usernameField);
//     add(new JLabel("Password:")); add(passwordField);
//     add(loginButton); add(goToRegisterButton); // add both buttons

//     loginButton.addActionListener(e -> {
//         String user = usernameField.getText();
//         String pass = new String(passwordField.getPassword());

//         if (userDB.login(user, pass)) {
//             JOptionPane.showMessageDialog(this, "Login successful!");
//             dispose();
//             startGameCallback.run();
//         } else {
//             JOptionPane.showMessageDialog(this, "Invalid credentials!");
//         }
//     });

//     goToRegisterButton.addActionListener(e -> {
//         dispose(); // Close current Login window
//         new RegisterPage(userDB, () -> new LoginPage(userDB, startGameCallback)); // Open RegisterPage
//     });

//     setVisible(true);
// }

// }


import javax.swing.*;
import java.awt.*; // GridLayout, Dimension, Font use karne ke liye

class LoginPage extends JFrame { // Matlab ye ek window banayegi jisme login form hoga.

    public LoginPage(UserDatabase userDB, Runnable startGameCallback) {
        setTitle("Login - Space Invaders");
        setSize(350, 200);
        setLayout(new GridLayout(4, 2, 5, 5)); // 4 rows, 2 columns
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTextField usernameField = new JTextField();
        usernameField.setPreferredSize(new Dimension(200, 30));
        usernameField.setFont(new Font("Arial", Font.PLAIN, 18));

        JPasswordField passwordField = new JPasswordField();
        passwordField.setPreferredSize(new Dimension(200, 30));
        passwordField.setFont(new Font("Arial", Font.PLAIN, 18));

        JButton loginButton = new JButton("Login");
        JButton goToRegisterButton = new JButton("Go to Register");

        add(new JLabel("Username:"));
        add(usernameField);
        add(new JLabel("Password:"));
        add(passwordField);
        add(loginButton);
        add(goToRegisterButton);

        loginButton.addActionListener(e -> {
            String user = usernameField.getText();
            String pass = new String(passwordField.getPassword());

            if (userDB.login(user, pass)) {
                JOptionPane.showMessageDialog(this, "Login successful!");
                dispose();
                startGameCallback.run();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid credentials!");
            }
        });

        goToRegisterButton.addActionListener(e -> {
            dispose(); // Close current Login window
            new RegisterPage(userDB, () -> new LoginPage(userDB, startGameCallback)); // Open RegisterPage
        });

        setVisible(true);
    }
}

