
import javax.swing.*; // GUI components
import java.awt.*;    // Layout, Font, Dimension ke liye

public class RegisterPage extends JFrame {
    public RegisterPage(UserDatabase userDB, Runnable openLoginPage) {
        setTitle("Register - Space Invaders");
        setSize(500, 600);
        setLayout(new GridLayout(9, 2, 15, 5)); // 9 rows, 2 columns
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center me khulega

        Font fieldFont = new Font("Arial", Font.PLAIN, 16);
        Dimension fieldSize = new Dimension(200, 30);

        JTextField nameField = new JTextField();
        nameField.setPreferredSize(fieldSize);
        nameField.setFont(fieldFont);

        JTextField ageField = new JTextField();
        ageField.setPreferredSize(fieldSize);
        ageField.setFont(fieldFont);

        JTextField phoneField = new JTextField();
        phoneField.setPreferredSize(fieldSize);
        phoneField.setFont(fieldFont);

        JComboBox<String> genderBox = new JComboBox<>(new String[]{"Male", "Female", "Other"});
        genderBox.setFont(fieldFont);

        JTextField usernameField = new JTextField();
        usernameField.setPreferredSize(fieldSize);
        usernameField.setFont(fieldFont);

        JPasswordField passwordField = new JPasswordField();
        passwordField.setPreferredSize(fieldSize);
        passwordField.setFont(fieldFont);

        JPasswordField confirmPasswordField = new JPasswordField();
        confirmPasswordField.setPreferredSize(fieldSize);
        confirmPasswordField.setFont(fieldFont);

        JButton registerButton = new JButton("Register");
        JButton goToLoginButton = new JButton("Go to Login");

        // Add components
        add(new JLabel("Full Name:")); add(nameField);
        add(new JLabel("Age:")); add(ageField);
        add(new JLabel("Phone Number:")); add(phoneField);
        add(new JLabel("Gender:")); add(genderBox);
        add(new JLabel("Username:")); add(usernameField);
        add(new JLabel("Password:")); add(passwordField);
        add(new JLabel("Confirm Password:")); add(confirmPasswordField);
        add(registerButton); add(goToLoginButton);

        registerButton.addActionListener(e -> {
            String username = usernameField.getText();
            String pass = new String(passwordField.getPassword());
            String confirm = new String(confirmPasswordField.getPassword());

            if (username.isEmpty() || pass.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Username and Password are required.");
                return;
            }

            if (!pass.equals(confirm)) {
                JOptionPane.showMessageDialog(this, "Passwords do not match.");
                return;
            }

            if (userDB.register(username, pass)) {
                JOptionPane.showMessageDialog(this, "Registration successful! Please login.");
            } else {
                JOptionPane.showMessageDialog(this, "Username already exists.");
            }
        });

        goToLoginButton.addActionListener(e -> {
            dispose(); // Close current window
            openLoginPage.run(); // Open login page
        });

        setVisible(true);
    }
}
