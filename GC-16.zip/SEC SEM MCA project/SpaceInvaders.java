

import java.awt.*;//provides classes for GUI components like Graphics, Color, Font, etc.
import java.awt.event.*;//ActionListener, KeyListener, MouseListene
import java.util.ArrayList;
import java.util.Random;//used to generate random numbers (for example, random enemy positions).
import javax.swing.*;//GUI toolkit hai,JFrame, JPanel, JButton, JLabel, JTextField

public class SpaceInvaders extends JPanel implements ActionListener, KeyListener {

    class Block {
        int x, y, width, height;
        Image img;
        boolean alive = true;
        boolean used = false;

        Block(int x, int y, int width, int height, Image img) {
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
            this.img = img;
        }
    }

    // Board setup
    int tileSize = 32;
    int rows = 20;
    int cols = 20;
    int boardWidth = tileSize * cols;
    int boardHeight = tileSize * rows;

    Image shipImg, alienImg, alienCyanImg, alienMagentaImg, alienYellowImg;//Image = java awt
    ArrayList<Image> alienImgArray;

    // Ship
    int shipWidth = tileSize * 2;
    int shipHeight = tileSize;
    int shipX = tileSize * cols / 2 - tileSize;
    int shipY = boardHeight - tileSize * 2;
    int shipVelocityX = tileSize;
    Block ship;

    // Aliens
    ArrayList<Block> alienArray;
    int alienWidth = tileSize * 2;
    int alienHeight = tileSize;
    int alienX = tileSize;
    int alienY = tileSize;
    int alienRows = 2;
    int alienColumns = 3;
    int alienCount = 0;
    int alienVelocityX = 1;

    // Bullets
    ArrayList<Block> bulletArray;
    int bulletWidth = tileSize / 8;
    int bulletHeight = tileSize / 2;
    int bulletVelocityY = -10;

    Timer gameLoop;//call action performed() in loop
    boolean gameOver = false;
    int score = 0;

    SpaceInvaders() {
        setPreferredSize(new Dimension(boardWidth, boardHeight));//Game screen ka size set ho raha ha,setPreferredSize(java.awt) = method,Dimension = class
        setBackground(Color.black);//java.swing,color.black=java.awt.color
        setFocusable(true);//control key presses,javax.swing
        addKeyListener(this);//keyboard se conterol ki ja sake game ko 
//
        // Load images
        shipImg = new ImageIcon(getClass().getResource("./ship.png")).getImage();//javax.swing,java.awt,getClass().getResource()=joint
        alienImg = new ImageIcon(getClass().getResource("./alien.png")).getImage();
        alienCyanImg = new ImageIcon(getClass().getResource("./alien-cyan.png")).getImage();
        alienMagentaImg = new ImageIcon(getClass().getResource("./alien-magenta.png")).getImage();
        alienYellowImg = new ImageIcon(getClass().getResource("./alien-yellow.png")).getImage();

        alienImgArray = new ArrayList<>();
        alienImgArray.add(alienImg);
        alienImgArray.add(alienCyanImg);
        alienImgArray.add(alienMagentaImg);
        alienImgArray.add(alienYellowImg);

        ship = new Block(shipX, shipY, shipWidth, shipHeight, shipImg);
        alienArray = new ArrayList<>();
        bulletArray = new ArrayList<>();

        gameLoop = new Timer(1000 / 60, this);//javax.swing
        createAliens();//initialize enemy position
        gameLoop.start();//start timer.
    }

    public void paintComponent(Graphics g) {//auto call when jpanel is redrawn
        super.paintComponent(g);//clr panel before drawing new content.
        draw(g);
    }

    public void draw(Graphics g) {//draw ship 
        g.drawImage(ship.img, ship.x, ship.y, ship.width, ship.height, null);//java.awt.Graphics,draw image for ship

        // Draw aliens
        for (Block alien : alienArray) {
            if (alien.alive) {
                g.drawImage(alien.img, alien.x, alien.y, alien.width, alien.height, null);//java.awt.Graphics,if alian are alive then draw 
            }
        }

        // Draw bullets
        g.setColor(Color.white);
        for (Block bullet : bulletArray) {
            if (!bullet.used) {
                g.fillRect(bullet.x, bullet.y, bullet.width, bullet.height);//awt h,make white rectangle in bullet positions
            }
        }

        // Draw score
        g.setColor(Color.white);//java.awt.Color
        g.setFont(new Font("Arial", Font.PLAIN, 32));//java.awt
        if (gameOver) {
            g.drawString("Game Over: " + score, 10, 35);
        } else {
            g.drawString("Score: " + score, 10, 35);
        }
    }

    public void move() {
        for (Block alien : alienArray) {
            if (alien.alive) {
                alien.x += alienVelocityX;//alian move only x direction left or right

                if (alien.x + alien.width >= boardWidth || alien.x <= 0) {//alian reach board edge then direction reverse
                    alienVelocityX *= -1;
                    alien.x += alienVelocityX * 2;//during reverse alian spead slightly fast as compare to prevouse 
                    for (Block a : alienArray) {
                        a.y += alienHeight;//all alian are below board when no edge is hitted.
                    }
                }

                if (alien.y >= ship.y) {//when alian are reach at ship or below ship then game will teminated 
                    gameOver = true;
                }
            }
        }

        for (Block bullet : bulletArray) {
            bullet.y += bulletVelocityY;//bullet move up dir
            for (Block alien : alienArray) {
                if (!bullet.used && alien.alive && detectCollision(bullet, alien)) {
                    bullet.used = true;
                    alien.alive = false;
                    alienCount--;
                    score += 20;
                }
            }
        }

        bulletArray.removeIf(b -> b.used || b.y < 0);//fxnal style java 8

        if (alienCount == 0) {//all aliens are died
            score += alienColumns * alienRows * 100;//add bonus total*100
            alienColumns = Math.min(alienColumns + 1, cols / 2 - 2);//dificulty increase
            alienRows = Math.min(alienRows + 1, rows - 6);
            alienArray.clear();//old alieans remove
            bulletArray.clear();//old bullets remove
            createAliens();
        }
    }

    public void createAliens() {//new alien create then push alienArray
        Random random = new Random();//java.util.random,object
        for (int r = 0; r < alienRows; r++) {
            for (int c = 0; c < alienColumns; c++) {
                int randomImgIndex = random.nextInt(alienImgArray.size());//random.nextInt=0ton-1 random no generate,alienImgArray.size()=count total immg
                Block alien = new Block(//for each and every aliens create a new obj,block = ship bullet alien
                        alienX + c * alienWidth,//each and every alien are align horizontally
                        alienY + r * alienHeight,//same but rev
                        alienWidth,
                        alienHeight,
                        alienImgArray.get(randomImgIndex)
                );
                alienArray.add(alien);//asign above img random no generated,this list use rander and movement time.
            }
        }
        alienCount = alienArray.size();//total no of aliens say to game
    }

    public boolean detectCollision(Block a, Block b) {//Axis-Aligned Bounding Box Algorithm(AABB)
        return a.x < b.x + b.width && a.x + a.width > b.x &&//a=bulet,b=alien
               a.y < b.y + b.height && a.y + a.height > b.y;
    }

    public void actionPerformed(ActionEvent e) {
        move();
        repaint();
        if (gameOver) {
            gameLoop.stop();
        }
    }

    public void keyTyped(KeyEvent e) {}

    public void keyPressed(KeyEvent e) {
        if (!gameOver) {
            if (e.getKeyCode() == KeyEvent.VK_LEFT && ship.x - shipVelocityX >= 0) {
                ship.x -= shipVelocityX;
            } else if (e.getKeyCode() == KeyEvent.VK_RIGHT && ship.x + ship.width + shipVelocityX <= boardWidth) {
                ship.x += shipVelocityX;
            } else if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                int bulletX = ship.x + ship.width / 2 - bulletWidth / 2;
                Block bullet = new Block(bulletX, ship.y, bulletWidth, bulletHeight, null);
                bulletArray.add(bullet);
            }
        }
    }

    public void keyReleased(KeyEvent e) {
        if (gameOver) {
            ship.x = shipX;
            bulletArray.clear();
            alienArray.clear();
            gameOver = false;
            score = 0;
            alienColumns = 3;
            alienRows = 2;
            alienVelocityX = 1;
            createAliens();
            gameLoop.start();
        }
    }

    // Main method to run game
    public static void main(String[] args) {
        JFrame frame = new JFrame("Space Invaders");
        SpaceInvaders game = new SpaceInvaders();
        frame.add(game);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}

