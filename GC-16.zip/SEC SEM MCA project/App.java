
import javax.swing.*;

public class App {
    public static void main(String[] args) throws Exception {
        // Shared user database
        UserDatabase userDB = new UserDatabase();//usedb->object hai

        // Start with Register Page
        new RegisterPage(userDB, () -> new LoginPage(userDB, () -> {
            // Game setup after successful login
            int tileSize = 32;
            int rows = 16;
            int cols = 16;
            int boardWidth = tileSize * cols;
            int boardHeight = tileSize * rows;

            JFrame frame = new JFrame("Space Invaders");
            frame.setSize(boardWidth, boardHeight);
            frame.setLocationRelativeTo(null);//center me dikhega 
            frame.setResizable(false);//no resize facility
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            SpaceInvaders spaceInvaders = new SpaceInvaders();
            frame.add(spaceInvaders);//game ko frame me add kar diya
            frame.pack();
            spaceInvaders.requestFocus();
            frame.setVisible(true);
        }));
    }
}