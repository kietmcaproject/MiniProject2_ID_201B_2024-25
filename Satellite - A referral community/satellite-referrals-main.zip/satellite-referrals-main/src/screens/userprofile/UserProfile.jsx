import React from 'react';

function UserProfile() {
  return <div>UserProfile Page</div>;
}

export { UserProfile };
